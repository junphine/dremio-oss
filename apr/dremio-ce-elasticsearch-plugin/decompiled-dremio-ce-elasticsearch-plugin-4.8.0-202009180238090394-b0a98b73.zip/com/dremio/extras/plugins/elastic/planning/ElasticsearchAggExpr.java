package com.dremio.extras.plugins.elastic.planning;

import com.fasterxml.jackson.annotation.*;
import com.google.common.base.*;

public class ElasticsearchAggExpr
{
    private final String operation;
    private final Type type;
    
    public ElasticsearchAggExpr(@JsonProperty("operation") final String operation, @JsonProperty("type") final Type type) {
        this.operation = operation;
        this.type = type;
    }
    
    public String getOperation() {
        return this.operation;
    }
    
    public Type getType() {
        return this.type;
    }
    
    @Override
    public boolean equals(final Object other) {
        if (!(other instanceof ElasticsearchAggExpr)) {
            return false;
        }
        final ElasticsearchAggExpr castOther = (ElasticsearchAggExpr)other;
        return Objects.equal((Object)this.operation, (Object)castOther.operation) && Objects.equal((Object)this.type, (Object)castOther.type);
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(new Object[] { this.operation, this.type });
    }
    
    @Override
    public String toString() {
        return MoreObjects.toStringHelper((Object)this).add("operation", (Object)this.operation).add("type", (Object)this.type).toString();
    }
    
    public enum Type
    {
        NORMAL, 
        COUNT_DISTINCT, 
        COUNT_ALL;
    }
}
