package com.dremio.exec.planner.acceleration.normalization.rules;

import com.dremio.exec.planner.logical.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.util.*;
import com.google.common.base.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.sql.fun.*;
import org.apache.calcite.sql.*;
import java.math.*;
import java.util.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.tools.*;
import org.slf4j.*;

public final class ReduceCountDistinctOnDimension extends RelOptRule
{
    private static final Logger LOGGER;
    public static final ReduceCountDistinctOnDimension INSTANCE;
    
    private ReduceCountDistinctOnDimension() {
        super(operand((Class)Aggregate.class, any()), DremioRelFactories.CALCITE_LOGICAL_BUILDER, ReduceCountDistinctOnDimension.class.getSimpleName());
    }
    
    private boolean isCountDistinctDimension(final AggregateCall aggCall, final ImmutableBitSet groupSet) {
        if (aggCall.getAggregation().getKind() == SqlKind.COUNT && aggCall.isDistinct()) {
            Preconditions.checkState(aggCall.getArgList().size() == 1);
            final int aggInputIndex = aggCall.getArgList().get(0);
            if (groupSet.get(aggInputIndex)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean findCountDistinctOnDimension(final Aggregate aggregate) {
        if (aggregate.getGroupCount() == 0) {
            return false;
        }
        for (final AggregateCall aggCall : aggregate.getAggCallList()) {
            if (this.isCountDistinctDimension(aggCall, aggregate.getGroupSet())) {
                return true;
            }
        }
        return false;
    }
    
    public boolean matches(final RelOptRuleCall call) {
        if (!super.matches(call)) {
            return false;
        }
        final Aggregate aggregate = (Aggregate)call.rels[0];
        return this.findCountDistinctOnDimension(aggregate);
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rels[0];
        final RexBuilder rexBuilder = aggregate.getCluster().getRexBuilder();
        final List<RexNode> topProjectExprs = new ArrayList<RexNode>();
        for (int group = 0; group < aggregate.getGroupCount(); ++group) {
            topProjectExprs.add((RexNode)rexBuilder.makeInputRef(aggregate.getRowType().getFieldList().get(group).getType(), group));
        }
        final List<AggregateCall> newAggCalls = new ArrayList<AggregateCall>();
        for (final AggregateCall aggregateCall : aggregate.getAggCallList()) {
            if (this.isCountDistinctDimension(aggregateCall, aggregate.getGroupSet())) {
                ReduceCountDistinctOnDimension.LOGGER.debug("Found count(distinct dimension): " + aggregateCall);
                final int groupByOrdinal = aggregate.getGroupSet().indexOf((int)aggregateCall.getArgList().get(0));
                Preconditions.checkState(groupByOrdinal >= 0);
                final RexNode isNull = rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NULL, new RexNode[] { rexBuilder.makeInputRef(aggregate.getRowType().getFieldList().get(groupByOrdinal).getType(), groupByOrdinal) });
                final RexNode isNullZeroThenOne = rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.CASE, new RexNode[] { isNull, rexBuilder.makeZeroLiteral(aggregateCall.getType()), rexBuilder.makeLiteral((Object)BigDecimal.ONE, aggregateCall.getType(), false) });
                topProjectExprs.add(isNullZeroThenOne);
            }
            else {
                topProjectExprs.add((RexNode)rexBuilder.makeInputRef(aggregateCall.getType(), aggregate.getGroupCount() + newAggCalls.size()));
                newAggCalls.add(aggregateCall);
            }
            ReduceCountDistinctOnDimension.LOGGER.trace("Handled aggregateCall: " + aggregateCall + ", in " + aggregate);
            ReduceCountDistinctOnDimension.LOGGER.trace("newAggCalls: " + newAggCalls);
            ReduceCountDistinctOnDimension.LOGGER.trace("topProjects: " + topProjectExprs);
        }
        final RelBuilder relBuilder = call.builder();
        relBuilder.push(aggregate.getInput());
        relBuilder.aggregate(relBuilder.groupKey(aggregate.getGroupSet().toArray()), (List)newAggCalls);
        ReduceCountDistinctOnDimension.LOGGER.debug("New aggregate: " + aggregate.getGroupSet() + ", " + newAggCalls);
        relBuilder.project((Iterable)topProjectExprs);
        ReduceCountDistinctOnDimension.LOGGER.debug("New top project: " + topProjectExprs);
        call.transformTo(relBuilder.build());
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)ReduceCountDistinctOnDimension.class);
        INSTANCE = new ReduceCountDistinctOnDimension();
    }
}
