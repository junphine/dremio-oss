package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.core.*;
import org.apache.calcite.plan.*;

public class SortForceRemoveRule extends RelOptRule
{
    public static final SortForceRemoveRule INSTANCE;
    
    public SortForceRemoveRule() {
        super(operand((Class)Sort.class, any()), "SortForceRemoveRule");
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Sort sort = (Sort)call.rel(0);
        if (sort.offset != null || sort.fetch != null) {
            return;
        }
        call.transformTo(sort.getInput());
    }
    
    static {
        INSTANCE = new SortForceRemoveRule();
    }
}
