package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.rules.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rel.type.*;
import java.util.*;

public final class FilterIntoJoinOnlyRule extends RelOptRule
{
    private final FilterJoinRule.Predicate predicate;
    public static final RelOptRule INSTANCE;
    
    private FilterIntoJoinOnlyRule() {
        super(operand((Class)Filter.class, operand((Class)Join.class, RelOptRule.any()), new RelOptRuleOperand[0]), "FilterJoinOnlyRule");
        this.predicate = FilterJoinRulesUtil.EQUAL_IS_NOT_DISTINCT_FROM;
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Filter filter = (Filter)call.rel(0);
        final Join join = (Join)call.rel(1);
        final List<RexNode> joinFilters = (List<RexNode>)RelOptUtil.conjunctions(join.getCondition());
        final List<RexNode> origJoinFilters = (List<RexNode>)ImmutableList.copyOf((Collection)joinFilters);
        final List<RexNode> aboveFilters = (List<RexNode>)RelOptUtil.conjunctions(filter.getCondition());
        final ImmutableList<RexNode> origAboveFilters = (ImmutableList<RexNode>)ImmutableList.copyOf((Collection)aboveFilters);
        final JoinRelType joinType = join.getJoinType();
        boolean filterPushed = false;
        if (RelOptUtil.classifyFilters((RelNode)join, (List)aboveFilters, joinType, !(join instanceof EquiJoin), false, false, (List)joinFilters, (List)null, (List)null)) {
            filterPushed = true;
        }
        this.validateJoinFilters(aboveFilters, joinFilters, join, joinType);
        if (joinFilters.size() == origJoinFilters.size() && Sets.newHashSet((Iterable)joinFilters).equals(Sets.newHashSet((Iterable)origJoinFilters))) {
            filterPushed = false;
        }
        if ((!filterPushed && joinType == join.getJoinType()) || joinFilters.isEmpty()) {
            return;
        }
        final RexBuilder rexBuilder = join.getCluster().getRexBuilder();
        final RelBuilder relBuilder = call.builder();
        final RelNode leftRel = join.getLeft();
        final RelNode rightRel = join.getRight();
        final ImmutableList<RelDataType> fieldTypes = (ImmutableList<RelDataType>)ImmutableList.builder().addAll((Iterable)RelOptUtil.getFieldTypeList(leftRel.getRowType())).addAll((Iterable)RelOptUtil.getFieldTypeList(rightRel.getRowType())).build();
        final RexNode joinFilter = RexUtil.composeConjunction(rexBuilder, (Iterable)RexUtil.fixUp(rexBuilder, (List)joinFilters, (List)fieldTypes), false);
        if (joinFilter.isAlwaysTrue() && joinType == join.getJoinType()) {
            return;
        }
        final RelNode newJoinRel = (RelNode)join.copy(join.getTraitSet(), joinFilter, leftRel, rightRel, joinType, join.isSemiJoinDone());
        call.getPlanner().onCopy((RelNode)join, newJoinRel);
        relBuilder.push(newJoinRel);
        relBuilder.convert(join.getRowType(), false);
        relBuilder.filter((Iterable)RexUtil.fixUp(rexBuilder, (List)aboveFilters, RelOptUtil.getFieldTypeList(relBuilder.peek().getRowType())));
        call.transformTo(relBuilder.build());
    }
    
    protected void validateJoinFilters(final List<RexNode> aboveFilters, final List<RexNode> joinFilters, final Join join, final JoinRelType joinType) {
        final Iterator<RexNode> filterIter = joinFilters.iterator();
        while (filterIter.hasNext()) {
            final RexNode exp = filterIter.next();
            if (!this.predicate.apply(join, joinType, exp)) {
                aboveFilters.add(exp);
                filterIter.remove();
            }
        }
    }
    
    static {
        INSTANCE = new FilterIntoJoinOnlyRule();
    }
}
