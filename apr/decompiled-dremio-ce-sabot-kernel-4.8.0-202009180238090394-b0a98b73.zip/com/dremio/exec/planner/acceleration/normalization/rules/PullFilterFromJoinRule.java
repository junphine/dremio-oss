package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.plan.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rel.type.*;
import java.util.*;
import org.apache.calcite.rex.*;

public final class PullFilterFromJoinRule extends RelOptRule
{
    public static final PullFilterFromJoinRule INSTANCE;
    
    public PullFilterFromJoinRule(final RelOptRuleOperand operand, final String description) {
        super(operand, description);
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final RelNode relNode = call.rel(0);
        final Join join = (Join)call.rel(1);
        final boolean isFilter = relNode instanceof Filter;
        final List<RexNode> joinFilters = (List<RexNode>)RelOptUtil.conjunctions(join.getCondition());
        final List<RexNode> origJoinFilters = (List<RexNode>)ImmutableList.copyOf((Collection)joinFilters);
        final List<RexNode> aboveFilters = (List<RexNode>)(isFilter ? RelOptUtil.conjunctions(((Filter)relNode).getCondition()) : Lists.newArrayList());
        final JoinRelType joinType = join.getJoinType();
        this.validateJoinFilters(aboveFilters, joinFilters, join, joinType);
        if (joinFilters.size() == origJoinFilters.size() && Sets.newHashSet((Iterable)joinFilters).equals(Sets.newHashSet((Iterable)origJoinFilters))) {
            return;
        }
        final RexBuilder rexBuilder = join.getCluster().getRexBuilder();
        final RelBuilder relBuilder = call.builder();
        final RelNode leftRel = join.getLeft();
        final RelNode rightRel = join.getRight();
        final ImmutableList<RelDataType> fieldTypes = (ImmutableList<RelDataType>)ImmutableList.builder().addAll((Iterable)RelOptUtil.getFieldTypeList(leftRel.getRowType())).addAll((Iterable)RelOptUtil.getFieldTypeList(rightRel.getRowType())).build();
        final RexNode joinFilter = RexUtil.composeConjunction(rexBuilder, (Iterable)RexUtil.fixUp(rexBuilder, (List)joinFilters, (List)fieldTypes), false);
        final RelNode newJoinRel = (RelNode)join.copy(join.getTraitSet(), joinFilter, leftRel, rightRel, joinType, join.isSemiJoinDone());
        call.getPlanner().onCopy((RelNode)join, newJoinRel);
        relBuilder.push(newJoinRel);
        relBuilder.convert(join.getRowType(), false);
        relBuilder.filter((Iterable)RexUtil.fixUp(rexBuilder, (List)aboveFilters, RelOptUtil.getFieldTypeList(relBuilder.peek().getRowType())));
        call.transformTo(relBuilder.build());
    }
    
    private void validateJoinFilters(final List<RexNode> aboveFilters, final List<RexNode> joinFilters, final Join join, final JoinRelType joinType) {
        if (joinType != JoinRelType.INNER) {
            return;
        }
        final Iterator<RexNode> filterIter = joinFilters.iterator();
        while (filterIter.hasNext()) {
            final RexNode exp = filterIter.next();
            if (exp instanceof RexCall) {
                final PullFilterFromJoinShuttle shuttle = new PullFilterFromJoinShuttle(join.getLeft().getRowType().getFieldCount());
                shuttle.visitCall((RexCall)exp);
                if (!shuttle.isValid()) {
                    continue;
                }
                aboveFilters.add(exp);
                filterIter.remove();
            }
        }
    }
    
    static {
        INSTANCE = new PullFilterFromJoinRule(operand((Class)Filter.class, operand((Class)Join.class, any()), new RelOptRuleOperand[0]), "PullFilterFromJoinRule");
    }
    
    private class PullFilterFromJoinShuttle extends RexShuttle
    {
        private int leftFieldCount;
        private boolean left;
        private boolean right;
        
        public PullFilterFromJoinShuttle(final int fieldCount) {
            this.leftFieldCount = fieldCount;
            this.left = true;
            this.right = true;
        }
        
        public RexNode visitInputRef(final RexInputRef inputRef) {
            if (inputRef.getIndex() >= this.leftFieldCount) {
                this.left = false;
            }
            else {
                this.right = false;
            }
            return (RexNode)inputRef;
        }
        
        public boolean isValid() {
            return this.left || this.right;
        }
    }
}
