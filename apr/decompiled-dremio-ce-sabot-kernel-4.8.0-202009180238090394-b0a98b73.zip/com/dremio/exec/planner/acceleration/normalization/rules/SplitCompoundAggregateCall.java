package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.logical.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.core.*;
import com.google.common.base.*;
import javax.annotation.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.util.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.tools.*;
import java.util.*;
import org.slf4j.*;
import org.apache.calcite.sql.fun.*;
import org.apache.calcite.sql.*;
import org.apache.calcite.rex.*;

public final class SplitCompoundAggregateCall extends RelOptRule
{
    private static final Logger LOGGER;
    public static final SplitCompoundAggregateCall INSTANCE;
    
    private SplitCompoundAggregateCall() {
        super(operand((Class)LogicalAggregate.class, operand((Class)LogicalProject.class, any()), new RelOptRuleOperand[0]), DremioRelFactories.CALCITE_LOGICAL_BUILDER, "SplitCompoundAggregateCall");
    }
    
    public boolean matches(final RelOptRuleCall call) {
        if (!super.matches(call)) {
            return false;
        }
        final Aggregate aggregate = (Aggregate)call.rels[0];
        final Project project = (Project)call.rels[1];
        return this.containsSplittableCompoundExpressions(aggregate, project);
    }
    
    private boolean containsSplittableCompoundExpressions(final Aggregate agg, final Project proj) {
        for (final AggregateCall aggCall : agg.getAggCallList()) {
            if (this.isSplittableCompoundAggregateCall(aggCall, proj)) {
                Preconditions.checkState(aggCall.getArgList().size() == 1);
                final SplittableCompoundCallFinder visitor = new SplittableCompoundCallFinder(aggCall.getAggregation().getKind());
                final RexNode aggCallInput = proj.getProjects().get(aggCall.getArgList().get(0));
                final boolean compoundRexNodeFound = (boolean)aggCallInput.accept((RexVisitor)visitor);
                if (compoundRexNodeFound) {
                    return true;
                }
                continue;
            }
        }
        return false;
    }
    
    private boolean isSplittableCompoundAggregateCall(final AggregateCall aggCall, final Project project) {
        switch (aggCall.getAggregation().getKind()) {
            case SUM:
            case SUM0:
            case COUNT:
            case MIN:
            case MAX: {
                if (aggCall.getArgList().isEmpty()) {
                    break;
                }
                if (aggCall.isDistinct()) {
                    break;
                }
                Preconditions.checkState(aggCall.getArgList().size() == 1);
                final RexNode aggCallInput = project.getProjects().get(aggCall.getArgList().get(0));
                if (!(aggCallInput instanceof RexInputRef) && !(aggCallInput instanceof RexLiteral)) {
                    return true;
                }
                break;
            }
        }
        return false;
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rels[0];
        final Project project = (Project)call.rels[1];
        final RelNode child = project.getInput();
        SplitCompoundAggregateCall.LOGGER.debug("Split compound aggregate calls: " + aggregate);
        final BottomProjectExprsWithReference projectMapping = new BottomProjectExprsWithReference(project.getProjects());
        for (final int group : aggregate.getGroupSet()) {
            projectMapping.add(project.getProjects().get(group));
        }
        final List<RexNode> compoundAggregateInputRefs = new ArrayList<RexNode>();
        for (final AggregateCall aggCall : aggregate.getAggCallList()) {
            SplittableCompoundCallFinder visitor;
            boolean compoundRexNodeFound;
            if (this.isSplittableCompoundAggregateCall(aggCall, project)) {
                SplitCompoundAggregateCall.LOGGER.debug("Split aggregateCall: " + aggCall);
                Preconditions.checkState(aggCall.getArgList().size() == 1);
                visitor = new SplittableCompoundCallFinder(aggCall.getAggregation().getKind());
                final RexNode aggCallInput = project.getProjects().get(aggCall.getArgList().get(0));
                compoundRexNodeFound = (boolean)aggCallInput.accept((RexVisitor)visitor);
            }
            else {
                compoundRexNodeFound = false;
                visitor = null;
            }
            if (!compoundRexNodeFound) {
                SplitCompoundAggregateCall.LOGGER.debug("Not splittable aggregateCall " + aggCall);
                for (final int aggInput : aggCall.getArgList()) {
                    projectMapping.add(project.getProjects().get(aggInput));
                }
                compoundAggregateInputRefs.add(null);
            }
            else {
                Preconditions.checkNotNull((Object)visitor.splittableInputRef);
                SplitCompoundAggregateCall.LOGGER.debug("Splittable aggregateCall " + aggCall + ", inputRef " + visitor.splittableInputRef);
                projectMapping.add(visitor.splittableInputRef);
                compoundAggregateInputRefs.add(visitor.splittableInputRef);
            }
        }
        final RelBuilder relBuilder = call.builder();
        final RexBuilder rexBuilder = aggregate.getCluster().getRexBuilder();
        final Map<ComparableRexNode, Pair<RexNode, Integer>> newBottomProject = projectMapping.getBottomProjectAndIndex();
        final Set<Integer> newGroupKeySet = new HashSet<Integer>();
        final Map<AggregateCall, Integer> newAggregateCalls = new LinkedHashMap<AggregateCall, Integer>();
        final List<RexNode> topProjects = new ArrayList<RexNode>();
        for (final int key : aggregate.getGroupSet()) {
            final Pair<RexNode, Integer> pair = newBottomProject.get(new ComparableRexNode(project.getProjects().get(key)));
            newGroupKeySet.add((Integer)pair.right);
            topProjects.add((RexNode)rexBuilder.makeInputRef(((RexNode)pair.left).getType(), (int)pair.right));
        }
        final int newGroupCount = newGroupKeySet.size();
        relBuilder.push(child);
        relBuilder.project(Pair.left((Iterable)newBottomProject.values()));
        SplitCompoundAggregateCall.LOGGER.debug("New bottom project: " + Pair.left((Iterable)newBottomProject.values()));
        for (int i = 0; i < aggregate.getAggCallList().size(); ++i) {
            final AggregateCall aggregateCall = aggregate.getAggCallList().get(i);
            final RexNode compoundAggregateRexInput = compoundAggregateInputRefs.get(i);
            if (compoundAggregateRexInput == null) {
                final List<Integer> newArgsList = (List<Integer>)Lists.transform(aggregateCall.getArgList(), (Function)new Function<Integer, Integer>() {
                    @Nullable
                    public Integer apply(@Nullable final Integer input) {
                        final Pair<RexNode, Integer> pair = (Pair<RexNode, Integer>)newBottomProject.get(new ComparableRexNode(project.getProjects().get(input)));
                        return (Integer)pair.getValue();
                    }
                });
                final AggregateCall newAggCall = AggregateCall.create(aggregateCall.getAggregation(), aggregateCall.isDistinct(), (List)newArgsList, aggregateCall.filterArg, aggregate.getGroupCount(), relBuilder.peek(), (RelDataType)null, aggregateCall.getName());
                if (!newAggregateCalls.containsKey(newAggCall)) {
                    newAggregateCalls.put(newAggCall, newAggregateCalls.size() + newGroupCount);
                }
                topProjects.add((RexNode)rexBuilder.makeInputRef(newAggCall.getType(), (int)newAggregateCalls.get(newAggCall)));
            }
            else {
                Preconditions.checkState(aggregateCall.getArgList().size() == 1);
                final SplittableCompoundCallWriter compoundReplacer = new SplittableCompoundCallWriter(newBottomProject, compoundAggregateRexInput, newGroupCount, aggregateCall, rexBuilder, relBuilder.peek(), newAggregateCalls);
                final RexNode topProj = (RexNode)project.getProjects().get(aggregateCall.getArgList().get(0)).accept((RexVisitor)compoundReplacer);
                topProjects.add(rexBuilder.makeCast(aggregateCall.getType(), topProj));
            }
            if (SplitCompoundAggregateCall.LOGGER.isDebugEnabled()) {
                final String splittable = (compoundAggregateRexInput == null) ? "Unsplittable" : "Splittable";
                SplitCompoundAggregateCall.LOGGER.debug(splittable + " aggregateCall: " + aggregateCall + ", transformed to newAggregateCalls: " + newAggregateCalls.keySet());
                SplitCompoundAggregateCall.LOGGER.debug(splittable + " aggregateCall: " + aggregateCall + ", TopProjects: " + topProjects);
            }
        }
        final ImmutableBitSet newGroupSet = ImmutableBitSet.of((Iterable)newGroupKeySet);
        relBuilder.aggregate(relBuilder.groupKey(newGroupSet.toArray()), (List)Lists.newArrayList((Iterable)newAggregateCalls.keySet()));
        SplitCompoundAggregateCall.LOGGER.debug("New aggregate: " + newGroupSet + ", " + Lists.newArrayList((Iterable)newAggregateCalls.keySet()));
        relBuilder.project((Iterable)topProjects, (Iterable)aggregate.getRowType().getFieldNames());
        SplitCompoundAggregateCall.LOGGER.debug("New top project: " + topProjects);
        call.transformTo(relBuilder.build());
    }
    
    private static boolean isNonNegative(final RexNode rexNode) {
        if (!(rexNode instanceof RexLiteral)) {
            SplitCompoundAggregateCall.LOGGER.debug("RexNode is not a literal, " + rexNode);
            return true;
        }
        try {
            if ((long)((RexLiteral)rexNode).getValue2() < 0L) {
                SplitCompoundAggregateCall.LOGGER.debug("Literal has negative value, " + rexNode);
                return false;
            }
        }
        catch (ClassCastException e) {
            SplitCompoundAggregateCall.LOGGER.debug("Failed to retrieve numeric value for " + rexNode.toString(), (Object)e.getMessage());
            return false;
        }
        return true;
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)SplitCompoundAggregateCall.class);
        INSTANCE = new SplitCompoundAggregateCall();
    }
    
    private class ProjectExprWithReference
    {
        private final RexNode expr;
        private int numReference;
        
        ProjectExprWithReference(final RexNode expr, final int numReference) {
            this.expr = expr;
            this.numReference = numReference;
        }
    }
    
    private class BottomProjectExprsWithReference
    {
        private final Map<ComparableRexNode, ProjectExprWithReference> mapping;
        
        public BottomProjectExprsWithReference(final List<RexNode> project) {
            this.mapping = new LinkedHashMap<ComparableRexNode, ProjectExprWithReference>();
            for (final RexNode p : project) {
                this.mapping.put(new ComparableRexNode(p), new ProjectExprWithReference(p, 0));
            }
        }
        
        public void add(final RexNode node) {
            final ComparableRexNode key = new ComparableRexNode(node);
            if (this.mapping.containsKey(key)) {
                this.mapping.get(key).numReference++;
            }
            else {
                this.mapping.put(key, new ProjectExprWithReference(node, 1));
            }
        }
        
        public Map<ComparableRexNode, Pair<RexNode, Integer>> getBottomProjectAndIndex() {
            final Map<ComparableRexNode, Pair<RexNode, Integer>> projectMapping = new LinkedHashMap<ComparableRexNode, Pair<RexNode, Integer>>();
            for (final Map.Entry<ComparableRexNode, ProjectExprWithReference> entry : this.mapping.entrySet()) {
                if (entry.getValue().numReference == 0) {
                    continue;
                }
                projectMapping.put(entry.getKey(), (Pair<RexNode, Integer>)Pair.of((Object)entry.getValue().expr, (Object)projectMapping.size()));
            }
            return projectMapping;
        }
    }
    
    private class SplittableCompoundCallWriter extends RexShuttle
    {
        private final Map<ComparableRexNode, Pair<RexNode, Integer>> bottomProjectMapping;
        private final AggregateCall countInput;
        private final int groupCount;
        private final AggregateCall aggregateCall;
        private final RexBuilder rexBuilder;
        private final RelNode input;
        private final SqlKind aggKind;
        private boolean flipMinMax;
        private final Map<AggregateCall, Integer> aggregateCalls;
        
        SplittableCompoundCallWriter(final Map<ComparableRexNode, Pair<RexNode, Integer>> bottomProjectMapping, final RexNode inputRef, final int groupCount, final AggregateCall aggregateCall, final RexBuilder rexBuilder, final RelNode input, final Map<AggregateCall, Integer> aggregateCalls) {
            this.flipMinMax = false;
            this.bottomProjectMapping = bottomProjectMapping;
            this.groupCount = groupCount;
            this.aggregateCall = aggregateCall;
            this.rexBuilder = rexBuilder;
            this.input = input;
            this.aggregateCalls = aggregateCalls;
            this.aggKind = aggregateCall.getAggregation().getKind();
            final int inputRefInBottomProject = (int)bottomProjectMapping.get(new ComparableRexNode(inputRef)).getValue();
            this.countInput = AggregateCall.create(SqlStdOperatorTable.COUNT, false, (List)Lists.newArrayList((Object[])new Integer[] { inputRefInBottomProject }), -1, groupCount, input, (RelDataType)null, "COMPOUND_SPLIT_COUNT");
        }
        
        private RexNode addNewAggregateCall(final RexNode node) {
            SplitCompoundAggregateCall.LOGGER.debug("Adding a new AggregateCall for RexNode, " + node + ", aggregateCall " + this.aggregateCall);
            final Pair<RexNode, Integer> projIndex = this.bottomProjectMapping.get(new ComparableRexNode(node));
            Preconditions.checkNotNull((Object)projIndex);
            final int newInputIndex = (int)projIndex.getValue();
            SqlAggFunction aggFunction;
            if (this.flipMinMax) {
                SplitCompoundAggregateCall.LOGGER.debug("Flipping Min/Max query: " + this.aggKind);
                Preconditions.checkState(this.aggKind == SqlKind.MIN || this.aggKind == SqlKind.MAX);
                aggFunction = ((this.aggKind == SqlKind.MIN) ? SqlStdOperatorTable.MAX : SqlStdOperatorTable.MIN);
            }
            else {
                aggFunction = this.aggregateCall.getAggregation();
            }
            final AggregateCall newAggCall = AggregateCall.create(aggFunction, this.aggregateCall.isDistinct(), (List)Lists.newArrayList((Object[])new Integer[] { newInputIndex }), this.aggregateCall.filterArg, this.groupCount, this.input, (RelDataType)null, this.aggregateCall.getName());
            SplitCompoundAggregateCall.LOGGER.debug("Adding aggregate function: " + aggFunction + ", " + newAggCall + ", to aggregateCalls " + this.aggregateCalls);
            if (!this.aggregateCalls.containsKey(newAggCall)) {
                this.aggregateCalls.put(newAggCall, this.aggregateCalls.size() + this.groupCount);
            }
            final int newAggCallIndex = this.aggregateCalls.get(newAggCall);
            SplitCompoundAggregateCall.LOGGER.debug("Adding aggregate function: [" + aggFunction + ", " + newAggCall + "] to aggregateCalls " + this.aggregateCalls + ", at Index " + newAggCallIndex);
            return (RexNode)this.rexBuilder.makeInputRef(newAggCall.getType(), newAggCallIndex);
        }
        
        public RexNode visitCall(final RexCall call) {
            switch (this.aggKind) {
                case SUM:
                case SUM0: {
                    return this.handleSumOperand(call);
                }
                case COUNT: {
                    return this.handleCountOperand(call);
                }
                case MIN:
                case MAX: {
                    return this.handleMinMaxOperand(call);
                }
                default: {
                    return super.visitCall(call);
                }
            }
        }
        
        private RexNode handleMinMaxOperand(final RexCall call) {
            if (call.getKind() == SqlKind.MINUS && call.getOperands().get(0).getKind() == SqlKind.LITERAL && call.getOperands().get(1).getKind() != SqlKind.LITERAL) {
                SplitCompoundAggregateCall.LOGGER.debug("Negative Min/Max expression found, setting flipMinMax to " + !this.flipMinMax);
                this.flipMinMax = !this.flipMinMax;
            }
            return super.visitCall(call);
        }
        
        private RexNode handleCountOperand(final RexCall call) {
            if (!this.aggregateCalls.containsKey(this.countInput)) {
                this.aggregateCalls.put(this.countInput, this.groupCount + this.aggregateCalls.size());
            }
            SplitCompoundAggregateCall.LOGGER.debug("Adding count() aggregate function: [" + this.countInput + "] to aggregateCalls " + this.aggregateCalls);
            return (RexNode)this.rexBuilder.makeInputRef(this.countInput.getType(), (int)this.aggregateCalls.get(this.countInput));
        }
        
        private RexNode handleSumOperand(final RexCall call) {
            switch (call.getKind()) {
                case PLUS:
                case MINUS: {
                    final boolean[] updatePlusMinus = { false };
                    final List<RexNode> plusMinusChildren = (List<RexNode>)this.visitList(call.getOperands(), updatePlusMinus);
                    final List<RexNode> modifiedPlusMinusChildren = new ArrayList<RexNode>();
                    for (final RexNode plusMinusChild : plusMinusChildren) {
                        if (plusMinusChild.getKind() == SqlKind.LITERAL) {
                            if (!this.aggregateCalls.containsKey(this.countInput)) {
                                SplitCompoundAggregateCall.LOGGER.debug("For SUM of literal, adding COUNT() aggregate function: [" + this.countInput + "] to aggregateCalls " + this.aggregateCalls);
                                this.aggregateCalls.put(this.countInput, this.aggregateCalls.size() + this.groupCount);
                            }
                            final RexNode countMultiply = this.rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.MULTIPLY, new RexNode[] { plusMinusChild, this.rexBuilder.makeInputRef(this.countInput.getType(), (int)this.aggregateCalls.get(this.countInput)) });
                            SplitCompoundAggregateCall.LOGGER.debug("Adding literal * COUNT() aggregate function: [" + countMultiply + "] to RexCall " + call);
                            modifiedPlusMinusChildren.add(countMultiply);
                        }
                        else {
                            modifiedPlusMinusChildren.add(plusMinusChild);
                        }
                    }
                    final SqlOperator operatorPlusMinus = (SqlOperator)((call.getKind() == SqlKind.PLUS) ? SqlStdOperatorTable.PLUS : SqlStdOperatorTable.MINUS);
                    SplitCompoundAggregateCall.LOGGER.debug("For SUM of literal, new aggregateCall generated from [" + call + "] to [" + operatorPlusMinus + ", " + modifiedPlusMinusChildren);
                    return this.rexBuilder.makeCall(operatorPlusMinus, (List)modifiedPlusMinusChildren);
                }
                default: {
                    return super.visitCall(call);
                }
            }
        }
        
        public RexNode visitInputRef(final RexInputRef inputRef) {
            return this.addNewAggregateCall((RexNode)inputRef);
        }
    }
    
    private class SplittableCompoundCallFinder implements RexVisitor<Boolean>
    {
        private final SqlKind aggKind;
        private RexNode splittableInputRef;
        
        public SplittableCompoundCallFinder(final SqlKind aggKind) {
            this.splittableInputRef = null;
            this.aggKind = aggKind;
        }
        
        private boolean setSplittableInputRef(final RexNode node) {
            SplitCompoundAggregateCall.LOGGER.debug("Found a splittable inputRef, " + node + ", in aggregation of type " + this.aggKind + ", previously found " + this.splittableInputRef);
            if (this.splittableInputRef == null) {
                this.splittableInputRef = node;
                return true;
            }
            return this.aggKind != SqlKind.MIN && this.aggKind != SqlKind.MAX && this.splittableInputRef.toString().equals(node.toString());
        }
        
        public Boolean visitInputRef(final RexInputRef inputRef) {
            return this.setSplittableInputRef((RexNode)inputRef);
        }
        
        public Boolean visitLiteral(final RexLiteral literal) {
            SplitCompoundAggregateCall.LOGGER.debug("Found a literal, " + literal);
            return true;
        }
        
        public Boolean visitCall(final RexCall call) {
            switch (call.getKind()) {
                case PLUS:
                case MINUS:
                case DIVIDE:
                case TIMES: {
                    switch (this.aggKind) {
                        case SUM:
                        case SUM0:
                        case COUNT: {
                            return this.handleComplexOperator(call, false);
                        }
                        case MIN:
                        case MAX: {
                            return this.handleComplexOperator(call, true);
                        }
                        default: {
                            return false;
                        }
                    }
                    break;
                }
                default: {
                    SplitCompoundAggregateCall.LOGGER.debug("Found unsplittable RexCall, " + call);
                    return false;
                }
            }
        }
        
        private Boolean handleComplexOperator(final RexCall call, final boolean nonNegLiterlaRequired) {
            SplitCompoundAggregateCall.LOGGER.debug("Handling RexCall, " + call + ", in aggregate function " + this.aggKind);
            switch (call.getKind()) {
                case PLUS:
                case MINUS: {
                    return this.visitChildren(call);
                }
                case DIVIDE: {
                    return this.handleSecondOperandMustBeLiteral(call, nonNegLiterlaRequired);
                }
                case TIMES: {
                    return this.handleOneOperandMustBeLiteral(call, nonNegLiterlaRequired);
                }
                default: {
                    return false;
                }
            }
        }
        
        private boolean handleOneOperandMustBeLiteral(final RexCall call, final boolean nonNegLiteralRequired) {
            SplitCompoundAggregateCall.LOGGER.debug("Handling RexCall, " + call + ", in aggregate function " + this.aggKind + ": at least one operand must be a literal");
            switch (call.getKind()) {
                case PLUS:
                case MINUS:
                case DIVIDE:
                case TIMES: {
                    Preconditions.checkArgument(call.getOperands().size() == 2);
                    if (!(call.getOperands().get(0) instanceof RexLiteral) && !(call.getOperands().get(1) instanceof RexLiteral)) {
                        SplitCompoundAggregateCall.LOGGER.debug("Failing RexCall, " + call + ", in aggregate function " + this.aggKind + ": does not have any literal operand");
                        return false;
                    }
                    if (nonNegLiteralRequired) {
                        for (final RexNode child : call.getOperands()) {
                            if (!isNonNegative(child)) {
                                return false;
                            }
                        }
                        break;
                    }
                    break;
                }
            }
            return this.visitChildren(call);
        }
        
        private boolean handleSecondOperandMustBeLiteral(final RexCall call, final boolean nonNegLiteralRequired) {
            SplitCompoundAggregateCall.LOGGER.debug("Handling RexCall, " + call + ", in aggregate function " + this.aggKind + ": second operand must be a literal");
            Preconditions.checkArgument(call.getOperands().size() == 2);
            if (!(call.getOperands().get(1) instanceof RexLiteral)) {
                SplitCompoundAggregateCall.LOGGER.debug("Failing RexCall, " + call + ", in aggregate function " + this.aggKind + ": second operand is not a literal");
                return false;
            }
            return (!nonNegLiteralRequired || isNonNegative(call.getOperands().get(1))) && this.visitChildren(call);
        }
        
        private Boolean visitChildren(final RexCall call) {
            for (final RexNode operand : call.getOperands()) {
                final Boolean newOperandOk = (Boolean)operand.accept((RexVisitor)this);
                if (newOperandOk == null || !newOperandOk) {
                    return false;
                }
            }
            return true;
        }
        
        public Boolean visitLocalRef(final RexLocalRef localRef) {
            return false;
        }
        
        public Boolean visitPatternFieldRef(final RexPatternFieldRef fieldRef) {
            return false;
        }
        
        public Boolean visitTableInputRef(final RexTableInputRef fieldRef) {
            return false;
        }
        
        public Boolean visitOver(final RexOver over) {
            return false;
        }
        
        public Boolean visitCorrelVariable(final RexCorrelVariable correlVariable) {
            return false;
        }
        
        public Boolean visitDynamicParam(final RexDynamicParam dynamicParam) {
            return false;
        }
        
        public Boolean visitRangeRef(final RexRangeRef rangeRef) {
            return false;
        }
        
        public Boolean visitFieldAccess(final RexFieldAccess fieldAccess) {
            return false;
        }
        
        public Boolean visitSubQuery(final RexSubQuery subQuery) {
            return false;
        }
    }
}
