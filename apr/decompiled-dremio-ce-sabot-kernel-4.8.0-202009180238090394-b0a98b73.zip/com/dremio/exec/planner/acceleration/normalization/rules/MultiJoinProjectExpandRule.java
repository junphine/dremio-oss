package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.rules.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.plan.hep.*;
import org.apache.calcite.rel.type.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.util.*;
import java.util.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rex.*;

public final class MultiJoinProjectExpandRule extends RelOptRule
{
    public static final MultiJoinProjectExpandRule INSTANCE;
    
    private MultiJoinProjectExpandRule() {
        super(operand((Class)MultiJoin.class, any()), (String)null);
    }
    
    public void onMatch(final RelOptRuleCall call) {
        if (!(call.getPlanner() instanceof HepPlanner)) {
            return;
        }
        final MultiJoin multiJoin = (MultiJoin)call.rel(0);
        boolean hadReplacement = false;
        final RexBuilder rexBuilder = multiJoin.getCluster().getRexBuilder();
        final RelBuilder relBuilder = call.builder();
        for (int i = 0; i < multiJoin.getInputs().size(); ++i) {
            final RelNode child = ((HepRelVertex)multiJoin.getInput(i)).getCurrentRel();
            final Set<Integer> indexes = this.getNeededProjectIndexes(i, multiJoin);
            if (!indexes.isEmpty()) {
                final List<RexNode> projectionList = (List<RexNode>)Lists.newArrayList();
                final List<RelDataTypeField> fieldList = (List<RelDataTypeField>)child.getRowType().getFieldList();
                for (int j = 0; j < fieldList.size(); ++j) {
                    if (indexes.contains(j)) {
                        projectionList.add((RexNode)rexBuilder.makeInputRef(fieldList.get(j).getType(), j));
                    }
                    else {
                        projectionList.add(rexBuilder.makeCast(fieldList.get(j).getType(), (RexNode)rexBuilder.constantNull()));
                    }
                }
                if (this.shouldAddProject(child, projectionList)) {
                    multiJoin.replaceInput(i, relBuilder.push(child).project((Iterable)projectionList, (Iterable)ImmutableList.of(), true).build());
                    hadReplacement = true;
                }
            }
        }
        if (!hadReplacement) {
            return;
        }
        call.transformTo((RelNode)multiJoin);
    }
    
    private Set<Integer> getNeededProjectIndexes(final int childIndex, final MultiJoin multiJoin) {
        int tempIndex = 0;
        for (int i = 0; i < childIndex; ++i) {
            tempIndex += multiJoin.getInputs().get(i).getRowType().getFieldCount();
        }
        final int startFieldIndex = tempIndex;
        final int endFieldIndex = tempIndex + multiJoin.getInputs().get(childIndex).getRowType().getFieldCount() - 1;
        final Set<Integer> projections = new TreeSet<Integer>();
        final RexVisitor<Void> visitor = (RexVisitor<Void>)new RexVisitorImpl<Void>(true) {
            public Void visitInputRef(final RexInputRef inputRef) {
                final int index = inputRef.getIndex();
                if (index >= startFieldIndex && index <= endFieldIndex) {
                    projections.add(index - startFieldIndex);
                }
                return null;
            }
        };
        final ImmutableBitSet bitSet = multiJoin.getProjFields().get(childIndex);
        if (null == bitSet) {
            for (int numFields = multiJoin.getInputs().get(childIndex).getRowType().getFieldCount(), j = 0; j < numFields; ++j) {
                projections.add(j);
            }
            return projections;
        }
        projections.addAll(bitSet.toList());
        multiJoin.getJoinFilter().accept((RexVisitor)visitor);
        for (final RexNode node : multiJoin.getOuterJoinConditions()) {
            if (node != null) {
                node.accept((RexVisitor)visitor);
            }
        }
        final RexNode postJoinFilter = multiJoin.getPostJoinFilter();
        if (null != postJoinFilter) {
            postJoinFilter.accept((RexVisitor)visitor);
        }
        return projections;
    }
    
    private boolean shouldAddProject(final RelNode child, final List<RexNode> projectionList) {
        if (!(child instanceof LogicalProject)) {
            return true;
        }
        final List<RexNode> childProjections = (List<RexNode>)((LogicalProject)child).getChildExps();
        for (int j = 0; j < projectionList.size(); ++j) {
            if (RexUtil.isNull((RexNode)projectionList.get(j)) && !RexUtil.isNull((RexNode)childProjections.get(j))) {
                return true;
            }
        }
        return false;
    }
    
    static {
        INSTANCE = new MultiJoinProjectExpandRule();
    }
}
