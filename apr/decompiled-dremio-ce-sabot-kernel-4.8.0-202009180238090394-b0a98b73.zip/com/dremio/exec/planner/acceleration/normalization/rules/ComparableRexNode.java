package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.type.*;
import org.apache.calcite.rex.*;
import java.util.*;

public class ComparableRexNode implements Comparable<ComparableRexNode>
{
    private final String stringType;
    private final RelDataType dataType;
    
    public ComparableRexNode(final RexNode node) {
        this(node.toString(), node.getType());
    }
    
    public ComparableRexNode(final String stringType, final RelDataType dataType) {
        this.stringType = stringType;
        this.dataType = dataType;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.stringType, this.dataType.getFullTypeString());
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof ComparableRexNode)) {
            return false;
        }
        if (o == this) {
            return true;
        }
        final ComparableRexNode other = (ComparableRexNode)o;
        return other.stringType.equals(this.stringType) && other.dataType.getFullTypeString().equals(this.dataType.getFullTypeString());
    }
    
    @Override
    public int compareTo(final ComparableRexNode o) {
        final int stringCompareResult = this.stringType.compareTo(o.stringType);
        if (stringCompareResult != 0) {
            return stringCompareResult;
        }
        final int dataTypeCompareResult = this.dataType.getFullTypeString().compareTo(o.dataType.getFullTypeString());
        return dataTypeCompareResult;
    }
}
