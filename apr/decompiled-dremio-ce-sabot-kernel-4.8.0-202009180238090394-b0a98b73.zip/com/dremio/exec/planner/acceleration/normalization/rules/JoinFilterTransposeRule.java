package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.*;
import java.util.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rex.*;

public final class JoinFilterTransposeRule extends RelOptRule
{
    private final boolean includeOuter;
    public static final JoinFilterTransposeRule BOTH_FILTER;
    public static final JoinFilterTransposeRule LEFT_FILTER;
    public static final JoinFilterTransposeRule RIGHT_FILTER;
    public static final JoinFilterTransposeRule BOTH_FILTER_INCLUDE_OUTER;
    public static final JoinFilterTransposeRule LEFT_FILTER_INCLUDE_OUTER;
    public static final JoinFilterTransposeRule RIGHT_FILTER_INCLUDE_OUTER;
    
    public JoinFilterTransposeRule(final RelOptRuleOperand operand, final String description, final boolean includeOuter) {
        super(operand, description);
        this.includeOuter = includeOuter;
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Join joinRel = (Join)call.rel(0);
        final JoinRelType joinType = joinRel.getJoinType();
        Filter leftFilter;
        RelNode leftJoinChild;
        if (this.hasLeftChild(call) && (this.includeOuter || !joinType.generatesNullsOnLeft())) {
            leftFilter = (Filter)call.rel(1);
            leftJoinChild = this.getFilterChild(leftFilter);
        }
        else {
            leftFilter = null;
            leftJoinChild = call.rel(1);
        }
        Filter rightFilter;
        RelNode rightJoinChild;
        if (this.hasRightChild(call) && (this.includeOuter || !joinType.generatesNullsOnRight())) {
            rightFilter = this.getRightChild(call);
            rightJoinChild = this.getFilterChild(rightFilter);
        }
        else {
            rightFilter = null;
            rightJoinChild = joinRel.getRight();
        }
        if ((leftFilter == null && rightFilter == null) || (leftFilter == null && this.includeOuter && joinType == JoinRelType.LEFT) || (rightFilter == null && this.includeOuter && joinType == JoinRelType.RIGHT)) {
            return;
        }
        final Join newJoinRel = joinRel.copy(joinRel.getTraitSet(), joinRel.getCondition(), leftJoinChild, rightJoinChild, joinRel.getJoinType(), joinRel.isSemiJoinDone());
        final RelDataType joinRowType = newJoinRel.getRowType();
        final List<RelDataTypeField> joinChildrenFields = (List<RelDataTypeField>)joinRowType.getFieldList();
        final RexBuilder rexBuilderFilter = joinRel.getCluster().getRexBuilder();
        final RexProgram leftFilterProgram = this.createProgram(leftFilter, joinRowType, rexBuilderFilter, joinChildrenFields, 0);
        final int nFieldsLeft = leftJoinChild.getRowType().getFieldList().size();
        final RexProgram rightFilterProgram = this.createProgram(rightFilter, joinRowType, rexBuilderFilter, joinChildrenFields, nFieldsLeft);
        RexProgram mergedFilterProgram;
        if (leftFilter != null && rightFilter != null) {
            if (this.includeOuter && joinType == JoinRelType.LEFT) {
                mergedFilterProgram = leftFilterProgram;
            }
            else if (this.includeOuter && joinType == JoinRelType.RIGHT) {
                mergedFilterProgram = rightFilterProgram;
            }
            else {
                mergedFilterProgram = RexProgramBuilder.mergePrograms(leftFilterProgram, rightFilterProgram, rexBuilderFilter);
            }
        }
        else if (leftFilter != null) {
            mergedFilterProgram = leftFilterProgram;
        }
        else {
            mergedFilterProgram = rightFilterProgram;
        }
        final RexNode newFilterCondition = mergedFilterProgram.expandLocalRef(mergedFilterProgram.getCondition());
        final RelBuilder relBuilder = call.builder();
        relBuilder.push((RelNode)newJoinRel);
        relBuilder.filter(new RexNode[] { newFilterCondition });
        call.transformTo(relBuilder.build());
    }
    
    private boolean hasLeftChild(final RelOptRuleCall call) {
        return call.rel(1) instanceof Filter;
    }
    
    private boolean hasRightChild(final RelOptRuleCall call) {
        return call.rels.length == 3;
    }
    
    private Filter getRightChild(final RelOptRuleCall call) {
        return (Filter)call.rel(2);
    }
    
    private RelNode getFilterChild(final Filter filter) {
        return filter.getInput();
    }
    
    private RexProgram createProgram(final Filter filter, final RelDataType joinRowType, final RexBuilder rexBuilder, final List<RelDataTypeField> joinChildrenFields, final int adjustmentAmount) {
        if (filter != null) {
            final RexProgramBuilder programBuilder = new RexProgramBuilder(joinRowType, rexBuilder);
            programBuilder.addIdentity();
            RexNode filterCondition = filter.getCondition();
            if (adjustmentAmount != 0) {
                final List<RelDataTypeField> childFields = (List<RelDataTypeField>)filter.getRowType().getFieldList();
                final int nChildFields = childFields.size();
                final int[] adjustments = new int[nChildFields];
                for (int i = 0; i < nChildFields; ++i) {
                    adjustments[i] = adjustmentAmount;
                }
                filterCondition = (RexNode)filterCondition.accept((RexVisitor)new RelOptUtil.RexInputConverter(rexBuilder, (List)childFields, (List)joinChildrenFields, adjustments));
            }
            programBuilder.addCondition(filterCondition);
            return programBuilder.getProgram();
        }
        return null;
    }
    
    static {
        BOTH_FILTER = new JoinFilterTransposeRule(operand((Class)Join.class, operand((Class)Filter.class, any()), new RelOptRuleOperand[] { operand((Class)Filter.class, any()) }), "JoinFilterTransposeRule(Filter-Filter)", false);
        LEFT_FILTER = new JoinFilterTransposeRule(operand((Class)Join.class, some(operand((Class)Filter.class, any()), new RelOptRuleOperand[0])), "JoinFilterTransposeRule(Filter-Other)", false);
        RIGHT_FILTER = new JoinFilterTransposeRule(operand((Class)Join.class, operand((Class)RelNode.class, any()), new RelOptRuleOperand[] { operand((Class)Filter.class, any()) }), "JoinFilterTransposeRule(Other-Filter)", false);
        BOTH_FILTER_INCLUDE_OUTER = new JoinFilterTransposeRule(operand((Class)Join.class, operand((Class)Filter.class, any()), new RelOptRuleOperand[] { operand((Class)Filter.class, any()) }), "Join(IncludingOuter)FilterTransposeRule(Filter-Filter)", true);
        LEFT_FILTER_INCLUDE_OUTER = new JoinFilterTransposeRule(operand((Class)Join.class, some(operand((Class)Filter.class, any()), new RelOptRuleOperand[0])), "Join(IncludingOuter)FilterTransposeRule(Filter-Other)", true);
        RIGHT_FILTER_INCLUDE_OUTER = new JoinFilterTransposeRule(operand((Class)Join.class, operand((Class)RelNode.class, any()), new RelOptRuleOperand[] { operand((Class)Filter.class, any()) }), "Join(IncludingOuter)FilterTransposeRule(Other-Filter)", true);
    }
}
