package com.dremio.exec.planner.acceleration.normalization.rules;

import com.dremio.exec.planner.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.rel.core.*;

public final class ProjectOverAggregationRemover extends StatelessRelShuttleImpl
{
    private boolean truncate;
    
    private ProjectOverAggregationRemover() {
        this.truncate = false;
    }
    
    protected RelNode visitChild(final RelNode parent, final int i, final RelNode child) {
        final boolean isProject = parent instanceof Project;
        if (!isProject) {
            this.truncate = (parent instanceof Aggregate);
            return parent;
        }
        final RelNode project = super.visitChild(parent, i, child);
        if (!this.truncate) {
            return project;
        }
        return project.getInput(0);
    }
    
    public static ProjectOverAggregationRemover create() {
        return new ProjectOverAggregationRemover();
    }
}
