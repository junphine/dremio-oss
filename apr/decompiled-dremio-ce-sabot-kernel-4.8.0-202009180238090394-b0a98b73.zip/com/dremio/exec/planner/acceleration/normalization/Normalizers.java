package com.dremio.exec.planner.acceleration.normalization;

import java.util.*;
import org.apache.calcite.plan.*;
import com.google.common.collect.*;
import com.dremio.exec.expr.fn.hll.*;
import com.dremio.exec.planner.*;
import com.dremio.exec.planner.acceleration.normalization.rules.*;
import com.dremio.reflection.rules.*;
import org.apache.calcite.rel.rules.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.plan.hep.*;

public final class Normalizers
{
    private static final List<RelOptRule> PROJECT_RULES;
    private static final List<RelOptRule> COMMON_RULES;
    public static final List<RelOptRule> COMMON_RULES_FOR_VIEW;
    public static Normalizer EXTERNAL_NORMALIZER;
    public static final Normalizer RAW_VIEW_NORMALIZER;
    public static final Normalizer QUERY_NORMALIZER;
    public static final Normalizer AGG_JOIN_NORMALIZER;
    public static final Normalizer AGG_JOIN_PUSHDOWN;
    public static final Normalizer DISTINCT_AGG_NORMALIZER;
    public static final Normalizer JOIN_FILTER;
    public static final Normalizer MULTIJOIN_EXTRA_PROJECT;
    public static final Normalizer MULTIJOIN_TO_JOIN_NORMALIZER;
    public static final Normalizer PROJECT_MERGE_NORMALIZER;
    public static final Normalizer MULTIJOIN_NORMALIZER;
    
    static {
        PROJECT_RULES = (List)ImmutableList.of((Object)ProjectWithFlattenMergeRule.INSTANCE, (Object)ProjectRemoveRule.INSTANCE);
        COMMON_RULES = (List)ImmutableList.builder().add((Object[])new RelOptRule[] { ConvertCountDistinctToHll.INSTANCE, PushFilterPastProjectRule.CALCITE_NO_CHILD_CHECK, SortForceRemoveRule.INSTANCE, AggregateReduceFunctionsRule.NO_REDUCE_SUM, AggregateExpandDistinctAggregatesRule.JOIN, SplitCompoundAggregateCall.INSTANCE, ConvertToCountOne.INSTANCE, ReduceCountDistinctOnDimension.INSTANCE, AddProjectBelowAggregateRule.INSTANCE, ProjectToWindowRule.PROJECT, PlannerPhase.FILTER_MERGE_CALCITE_RULE, RewriteNdvAsHll.INSTANCE, JoinFilterCanonicalizationRule.INSTANCE }).addAll((Iterable)Normalizers.PROJECT_RULES).build();
        COMMON_RULES_FOR_VIEW = (List)ImmutableList.builder().add((Object)AggregateExpandDistinctAggregatesRule.JOIN).addAll((Iterable)Normalizers.COMMON_RULES).build();
        Normalizers.EXTERNAL_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer((List<StatelessRelShuttleImpl>)ImmutableList.of((Object)new RexNodeReducer()), (List<RelOptRule>)ImmutableList.builder().add((Object)PlannerPhase.CALC_REDUCE_EXPRESSIONS_CALCITE_RULE).add((Object)PlannerPhase.PROJECT_REDUCE_EXPRESSIONS_CALCITE_RULE).add((Object)PlannerPhase.FILTER_REDUCE_EXPRESSIONS_CALCITE_RULE).addAll((Iterable)Normalizers.COMMON_RULES_FOR_VIEW).build());
        RAW_VIEW_NORMALIZER = (Normalizer)new RawViewNormalizer();
        QUERY_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer((List<StatelessRelShuttleImpl>)ImmutableList.of((Object)new RexNodeReducer()), (List<RelOptRule>)ImmutableList.builder().add((Object)new RemoveCastBelowAggregationCall(DremioRelFactories.CALCITE_LOGICAL_BUILDER)).addAll((Iterable)Normalizers.COMMON_RULES).build());
        AGG_JOIN_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer(new RelOptRule[] { DremioAggregateFilterTransposeRule.INSTANCE, AggregateProjectMergeRule.INSTANCE, AggregateProjectPullUpConstantsRule.INSTANCE, PlannerPhase.FILTER_INTO_JOIN_CALCITE_RULE, PlannerPhase.JOIN_CONDITION_PUSH_CALCITE_RULE, JoinPushExpressionsRule.INSTANCE, AggregateReduceFunctionsRule.NO_REDUCE_SUM, TrimProjectUnderAggregate.INSTANCE, AddDummyAggFunctionRule.INSTANCE });
        AGG_JOIN_PUSHDOWN = (Normalizer)new RuleAndShuttleNormalizer(new RelOptRule[] { DremioAggregateJoinTransposeRule.INSTANCE, AggregateProjectToJoinTransposeRule.INSTANCE, ProjectMergeRule.INSTANCE, ProjectJoinTransposeRule.INSTANCE, PlannerPhase.FILTER_INTO_JOIN_CALCITE_RULE, PlannerPhase.JOIN_CONDITION_PUSH_CALCITE_RULE });
        DISTINCT_AGG_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer(new RelOptRule[] { AggregateExpandDistinctAggregatesRule.JOIN });
        JOIN_FILTER = (Normalizer)new RuleAndShuttleNormalizer(new RelOptRule[] { PushFilterPastProjectRule.CALCITE_NO_CHILD_CHECK, FilterIntoJoinOnlyRule.INSTANCE, DremioAggregateFilterTransposeRule.INSTANCE });
        MULTIJOIN_EXTRA_PROJECT = (Normalizer)new RuleAndShuttleNormalizer(new RelOptRule[] { MultiJoinProjectExpandRule.INSTANCE });
        MULTIJOIN_TO_JOIN_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer((List<StatelessRelShuttleImpl>)ImmutableList.of((Object)SwapJoinVisitor.INSTANCE), (List<RelOptRule>)ImmutableList.of((Object)LoptOptimizeJoinRule.UNOPTIMIZED));
        PROJECT_MERGE_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer(Normalizers.PROJECT_RULES);
        MULTIJOIN_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer((List<StatelessRelShuttleImpl>)ImmutableList.of(), (List<RelOptRule>)ImmutableList.of((Object)AggregateExpandDistinctAggregatesRule.JOIN, (Object)JoinFilterCanonicalizationRule.INSTANCE, (Object)MultiJoinProjectTransposeRule.MULTI_BOTH_PROJECT, (Object)MultiJoinProjectTransposeRule.MULTI_LEFT_PROJECT, (Object)MultiJoinProjectTransposeRule.MULTI_RIGHT_PROJECT, (Object)JoinToMultiJoinRule.INSTANCE, (Object)ProjectMultiJoinMergeRule.INSTANCE, (Object)FilterMultiJoinMergeRule.INSTANCE, (Object)MergeProjectRule.CALCITE_INSTANCE, (Object)PlannerPhase.FILTER_MERGE_CALCITE_RULE, (Object)ProjectRemoveRule.INSTANCE), HepMatchOrder.BOTTOM_UP);
    }
    
    public static class RawViewNormalizer extends RuleAndShuttleNormalizer
    {
        public RawViewNormalizer() {
            super((List<StatelessRelShuttleImpl>)ImmutableList.of((Object)new RexNodeReducer()), Normalizers.COMMON_RULES_FOR_VIEW);
        }
    }
}
