package com.dremio.exec.planner.acceleration.normalization;

import org.apache.calcite.plan.*;
import com.dremio.exec.planner.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.plan.hep.*;
import java.util.*;

public class RuleAndShuttleNormalizer implements Normalizer
{
    private final List<RelOptRule> rules;
    private final List<StatelessRelShuttleImpl> shuttles;
    private final HepMatchOrder matchOrder;
    
    RuleAndShuttleNormalizer(final List<RelOptRule> rules, final HepMatchOrder matchOrder) {
        this((List<StatelessRelShuttleImpl>)ImmutableList.of(), rules, matchOrder);
    }
    
    RuleAndShuttleNormalizer(final HepMatchOrder matchOrder, final RelOptRule... rules) {
        this((List<RelOptRule>)ImmutableList.copyOf((Object[])rules), matchOrder);
    }
    
    RuleAndShuttleNormalizer(final List<RelOptRule> rules) {
        this((List<StatelessRelShuttleImpl>)ImmutableList.of(), rules);
    }
    
    RuleAndShuttleNormalizer(final List<StatelessRelShuttleImpl> shuttles, final List<RelOptRule> rules) {
        this(shuttles, rules, HepMatchOrder.ARBITRARY);
    }
    
    public RuleAndShuttleNormalizer(final List<StatelessRelShuttleImpl> shuttles, final List<RelOptRule> rules, final HepMatchOrder matchOrder) {
        this.rules = rules;
        this.shuttles = shuttles;
        this.matchOrder = matchOrder;
    }
    
    public RuleAndShuttleNormalizer(final RelOptRule... rules) {
        this((List<RelOptRule>)ImmutableList.copyOf((Object[])rules));
    }
    
    public RelNode normalize(final RelNode query) {
        final HepProgramBuilder builder = HepProgram.builder();
        builder.addMatchOrder(this.matchOrder);
        builder.addRuleCollection((Collection)this.rules);
        final HepProgram program = builder.build();
        final HepPlanner planner = new HepPlanner(program);
        planner.setRoot(query);
        RelNode result;
        final RelNode plan = result = planner.findBestExp();
        for (final StatelessRelShuttleImpl shuttle : this.shuttles) {
            result = result.accept((RelShuttle)shuttle);
        }
        return result;
    }
}
