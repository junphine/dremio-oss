package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.sql.*;
import org.apache.calcite.sql.type.*;
import org.apache.calcite.linq4j.*;
import org.apache.calcite.rel.core.*;
import com.google.common.base.*;
import org.apache.calcite.rex.*;
import javax.annotation.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.util.*;
import java.util.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rel.*;
import org.slf4j.*;
import com.google.common.collect.*;

public class RemoveCastBelowAggregationCall extends RelOptRule
{
    private static final Logger LOGGER;
    private static Set<SqlKind> ALLOWED_AGGREGATIONS;
    private static Set<SqlTypeName> ALLOWED_INCOMING_TYPES;
    private static Set<SqlTypeName> ALLOWED_OUTGOING_TYPES;
    
    public RemoveCastBelowAggregationCall(final RelBuilderFactory factory) {
        super(operand((Class)Aggregate.class, operand((Class)Project.class, any()), new RelOptRuleOperand[0]), factory, RemoveCastBelowAggregationCall.class.getSimpleName());
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rel(0);
        final Project project = (Project)call.rel(1);
        final Set<Integer> casts = (Set<Integer>)Sets.newHashSet();
        for (final Ord<RexNode> pair : Ord.zip(project.getProjects())) {
            if (pair.e instanceof RexCall && ((RexCall)pair.e).getOperator().getKind() == SqlKind.CAST) {
                casts.add(pair.i);
            }
        }
        final Set<Integer> referenced = (Set<Integer>)Sets.newHashSet();
        for (final AggregateCall aggregateCall : aggregate.getAggCallList()) {
            if (!RemoveCastBelowAggregationCall.ALLOWED_AGGREGATIONS.contains(aggregateCall.getAggregation().getKind())) {
                continue;
            }
            for (final int arg : aggregateCall.getArgList()) {
                if (casts.contains(arg)) {
                    referenced.add(arg);
                }
            }
        }
        if (referenced.size() == 0) {
            return;
        }
        final boolean[] changed = { false };
        final List<RexNode> newExprs = (List<RexNode>)ImmutableList.copyOf((Collection)Lists.transform(Ord.zip(project.getProjects()), (Function)new Function<Ord<RexNode>, RexNode>() {
            @Nullable
            public RexNode apply(@Nullable final Ord<RexNode> pair) {
                if (referenced.contains(pair.i)) {
                    final RexCall cast = (RexCall)pair.e;
                    final RexNode operand = cast.getOperands().get(0);
                    if (operand.getKind() == SqlKind.INPUT_REF) {
                        final SqlTypeName incomingType = operand.getType().getSqlTypeName();
                        final SqlTypeName targetType = cast.getType().getSqlTypeName();
                        if (incomingType.equals((Object)targetType) || (RemoveCastBelowAggregationCall.ALLOWED_INCOMING_TYPES.contains(incomingType) && RemoveCastBelowAggregationCall.ALLOWED_OUTGOING_TYPES.contains(targetType))) {
                            changed[0] = true;
                            return operand;
                        }
                        RemoveCastBelowAggregationCall.LOGGER.debug("cast({}):{} is not removable. skipping...", (Object)incomingType, (Object)targetType);
                    }
                }
                return (RexNode)pair.e;
            }
        }));
        if (!changed[0]) {
            return;
        }
        final Set<RexNode> distinctExpr = (Set<RexNode>)Sets.newLinkedHashSet((Iterable)newExprs);
        final Map<String, Integer> firstSeen = (Map<String, Integer>)Maps.newHashMap();
        for (final Ord<RexNode> expr : Ord.zip((Iterable)distinctExpr)) {
            firstSeen.computeIfAbsent(((RexNode)expr.e).toString(), k -> expr.i);
        }
        final Iterable<RexNode> oldExpr = (Iterable<RexNode>)project.getProjects();
        final Map<String, Integer> positions = (Map<String, Integer>)Maps.newHashMap();
        for (final Ord<RexNode> expr2 : Ord.zip((Iterable)oldExpr)) {
            final Integer pos = firstSeen.get(newExprs.get(expr2.i).toString());
            positions.put("$" + expr2.i, pos);
        }
        final RelBuilder builder = this.relBuilderFactory.create(aggregate.getCluster(), (RelOptSchema)null);
        builder.push(project.getInput());
        final Iterable<String> distinctFieldNames = (Iterable<String>)Iterables.transform(Ord.zip((Iterable)distinctExpr), (Function)new Function<Ord<RexNode>, String>() {
            @Nullable
            public String apply(@Nullable final Ord<RexNode> expr) {
                return project.getRowType().getFieldNames().get(expr.i);
            }
        });
        builder.project((Iterable)distinctExpr, (Iterable)distinctFieldNames);
        final RelBuilder.GroupKey key = builder.groupKey(transformGroupSet(positions, aggregate.getGroupSet()), aggregate.indicator, (ImmutableList)transformGroupSets(positions, (ImmutableList<ImmutableBitSet>)aggregate.getGroupSets()));
        builder.aggregate(key, (List)transformCalls(positions, aggregate.getAggCallList()));
        final RelNode result = builder.build();
        call.transformTo(result);
    }
    
    protected static List<AggregateCall> transformCalls(final Map<String, Integer> positions, final List<AggregateCall> calls) {
        return (List<AggregateCall>)ImmutableList.copyOf(Iterables.transform((Iterable)calls, (Function)new Function<AggregateCall, AggregateCall>() {
            @Nullable
            public AggregateCall apply(@Nullable final AggregateCall call) {
                return call.copy((List)ImmutableList.copyOf((Iterable)RemoveCastBelowAggregationCall.transformReferences(positions, call.getArgList())), call.filterArg);
            }
        }));
    }
    
    protected static Iterable<Integer> transformReferences(final Map<String, Integer> positions, final Iterable<Integer> refs) {
        return (Iterable<Integer>)Iterables.transform((Iterable)refs, (Function)new Function<Integer, Integer>() {
            @Nullable
            public Integer apply(@Nullable final Integer ref) {
                final Integer newPos = positions.get("$" + ref);
                if (newPos == null) {
                    throw new IllegalStateException("unable to find reference: " + ref);
                }
                return newPos;
            }
        });
    }
    
    protected static ImmutableBitSet transformGroupSet(final Map<String, Integer> positions, final ImmutableBitSet groupSet) {
        return ImmutableBitSet.of((Iterable)transformReferences(positions, (Iterable<Integer>)groupSet));
    }
    
    protected static ImmutableList<ImmutableBitSet> transformGroupSets(final Map<String, Integer> positions, final ImmutableList<ImmutableBitSet> groupSets) {
        return (ImmutableList<ImmutableBitSet>)ImmutableList.copyOf(Iterables.transform((Iterable)groupSets, (Function)new Function<ImmutableBitSet, ImmutableBitSet>() {
            @Nullable
            public ImmutableBitSet apply(@Nullable final ImmutableBitSet groupSet) {
                return RemoveCastBelowAggregationCall.transformGroupSet(positions, groupSet);
            }
        }));
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)RemoveCastBelowAggregationCall.class);
        RemoveCastBelowAggregationCall.ALLOWED_AGGREGATIONS = (Set<SqlKind>)ImmutableSet.of((Object)SqlKind.AVG, (Object)SqlKind.STDDEV_POP, (Object)SqlKind.STDDEV_SAMP, (Object)SqlKind.VAR_POP, (Object)SqlKind.VAR_SAMP, (Object)SqlKind.COVAR_POP, (Object[])new SqlKind[] { SqlKind.COVAR_SAMP });
        RemoveCastBelowAggregationCall.ALLOWED_INCOMING_TYPES = (Set<SqlTypeName>)ImmutableSet.of((Object)SqlTypeName.INTEGER, (Object)SqlTypeName.BIGINT);
        RemoveCastBelowAggregationCall.ALLOWED_OUTGOING_TYPES = (Set<SqlTypeName>)ImmutableSet.of((Object)SqlTypeName.FLOAT, (Object)SqlTypeName.DOUBLE);
    }
}
