package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.sql.type.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rex.*;
import com.google.common.collect.*;
import com.dremio.exec.planner.logical.*;
import com.dremio.reflection.rules.*;
import org.apache.calcite.sql.fun.*;
import com.google.common.base.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.sql.*;
import org.apache.calcite.plan.*;
import org.slf4j.*;
import java.util.*;

public final class ConvertToCountOne extends RelOptRule
{
    private static final Logger LOGGER;
    public static final ConvertToCountOne INSTANCE;
    
    private ConvertToCountOne() {
        super(operand((Class)Aggregate.class, operand((Class)RelNode.class, any()), new RelOptRuleOperand[0]), DremioRelFactories.CALCITE_LOGICAL_BUILDER, ConvertToCountOne.class.getSimpleName());
    }
    
    public static boolean isIntegerLiteralOne(final RexNode node) {
        return node.getKind() == SqlKind.LITERAL && node.getType().getSqlTypeName() == SqlTypeName.INTEGER && !RexLiteral.isNullLiteral(node) && RexLiteral.intValue(node) == 1;
    }
    
    private int[] findAggCallsEquivalentToCountStar(final Aggregate aggregate, final RelNode input, final SetOfCountOneEquivalentAggregateCalls equivalentAggregateCalls) {
        final boolean inputIsProject = input instanceof Project;
        final Project inputProject = inputIsProject ? ((Project)input) : null;
        final int[] inputRefReferenceCount = new int[input.getRowType().getFieldCount()];
        for (final AggregateCall aggregateCall : aggregate.getAggCallList()) {
            final SqlKind aggKind = aggregateCall.getAggregation().getKind();
            if (aggKind == SqlKind.COUNT && !aggregateCall.isDistinct() && aggregateCall.getArgList().size() == 0) {
                equivalentAggregateCalls.addAggregateCall(aggregateCall, CountOneType.BASIC_EQUIV);
            }
            else {
                if (aggKind == SqlKind.COUNT && !aggregateCall.isDistinct() && aggregateCall.getArgList().size() == 1) {
                    final int aggCallInputIndex = aggregateCall.getArgList().get(0);
                    final boolean isCountLiteral = inputIsProject && inputProject.getProjects().get(aggCallInputIndex) instanceof RexLiteral;
                    if (isCountLiteral) {
                        final RexNode aggCallInput = inputProject.getProjects().get(aggCallInputIndex);
                        if (isIntegerLiteralOne(aggCallInput)) {
                            equivalentAggregateCalls.addAggregateCall(aggregateCall, CountOneType.EXACT);
                            continue;
                        }
                        equivalentAggregateCalls.addAggregateCall(aggregateCall, CountOneType.BASIC_EQUIV);
                        continue;
                    }
                    else if (aggregate.getGroupSet().get(aggCallInputIndex)) {
                        equivalentAggregateCalls.addAggregateCall(aggregateCall, CountOneType.COUNT_DIMENSION);
                        continue;
                    }
                }
                if ((aggKind == SqlKind.SUM || aggKind == SqlKind.SUM0) && !aggregateCall.isDistinct() && aggregateCall.getArgList().size() == 1 && inputIsProject) {
                    final RexNode aggCallInput2 = ((Project)input).getProjects().get(aggregateCall.getArgList().get(0));
                    if (aggCallInput2.getKind() == SqlKind.LITERAL && aggCallInput2.getType().getSqlTypeName().getFamily() == SqlTypeFamily.NUMERIC) {
                        if (!isIntegerLiteralOne(aggCallInput2) || aggKind == SqlKind.SUM) {
                            equivalentAggregateCalls.addAggregateCall(aggregateCall, CountOneType.SUM_OF_LITERAL);
                            continue;
                        }
                        equivalentAggregateCalls.addAggregateCall(aggregateCall, CountOneType.BASIC_EQUIV);
                        continue;
                    }
                }
                for (final int argIndex : aggregateCall.getArgList()) {
                    final int[] array = inputRefReferenceCount;
                    final int n = argIndex;
                    ++array[n];
                }
            }
        }
        if (equivalentAggregateCalls.numExactCountOne == equivalentAggregateCalls.aggCalls.size()) {
            equivalentAggregateCalls.clear();
        }
        return inputRefReferenceCount;
    }
    
    private int[] getMappings(final Aggregate aggregate, final RelNode input, final int[] inputRefReferenceCount, final List<Integer> reverseMapping) {
        final int[] newMapping = new int[input.getRowType().getFieldCount()];
        for (int size = 0; size < newMapping.length; ++size) {
            newMapping[size] = -1;
        }
        int sizeOfProject = 0;
        for (final int group : aggregate.getGroupSet()) {
            newMapping[group] = sizeOfProject;
            reverseMapping.add(group);
            inputRefReferenceCount[group] = 0;
            ++sizeOfProject;
        }
        for (int referencedInput = 0; referencedInput < inputRefReferenceCount.length; ++referencedInput) {
            final int refCount = inputRefReferenceCount[referencedInput];
            if (refCount > 0) {
                newMapping[referencedInput] = sizeOfProject;
                reverseMapping.add(referencedInput);
                ++sizeOfProject;
            }
        }
        ConvertToCountOne.LOGGER.debug("Generated newMapping: " + Arrays.toString(newMapping) + ", reverseMapping: " + reverseMapping + " for " + aggregate);
        return newMapping;
    }
    
    private void addBottomProjectWithLiteralOne(final RelNode input, final List<Integer> reverseMapping, final RelBuilder relBuilder, final RexBuilder rexBuilder, final RelDataTypeFactory typeFactory) {
        final boolean inputIsProject = input instanceof Project;
        final RelDataType intType = typeFactory.createTypeWithNullability(typeFactory.createSqlType(SqlTypeName.INTEGER), false);
        final RexNode one = rexBuilder.makeLiteral((Object)1, intType, false);
        final List<RexNode> exprs = (List<RexNode>)Lists.newArrayList();
        for (final int reverseInput : reverseMapping) {
            exprs.add((RexNode)rexBuilder.makeInputRef(input, reverseInput));
        }
        exprs.add(one);
        if (inputIsProject) {
            final Project bottomProject = (Project)input;
            final List<RexNode> newProjectExpression = (List<RexNode>)RelOptUtil.pushPastProject((List)exprs, bottomProject);
            relBuilder.push(bottomProject.getInput());
            relBuilder.project((Iterable)newProjectExpression);
        }
        else {
            relBuilder.push(input);
            relBuilder.project((Iterable)exprs);
        }
        ConvertToCountOne.LOGGER.debug("NewBottomProjectWithLiteralOne: " + exprs);
    }
    
    private void addNewAggregateWithCollapsedCountOne(final Aggregate aggregate, final RelBuilder relBuilder, final int[] newMapping, final SetOfCountOneEquivalentAggregateCalls equivalentAggregateCalls) {
        final RelNode newInput = relBuilder.peek();
        final int indexOfOne = newInput.getRowType().getFieldCount() - 1;
        final List<AggregateCall> newAggCalls = (List<AggregateCall>)Lists.newArrayList();
        for (final AggregateCall aggregateCall : aggregate.getAggCallList()) {
            if (!equivalentAggregateCalls.aggCalls.containsKey(aggregateCall)) {
                final List<Integer> newArgList = (List<Integer>)Lists.newArrayList();
                for (final int oldArg : aggregateCall.getArgList()) {
                    newArgList.add(newMapping[oldArg]);
                }
                newAggCalls.add(aggregateCall.copy((List)ImmutableList.copyOf((Collection)newArgList), aggregateCall.filterArg));
            }
            else {
                if (equivalentAggregateCalls.needProjectOnTop()) {
                    continue;
                }
                final SqlAggFunction countFunction = (aggregateCall.getAggregation() instanceof ProjectableSqlAggFunction) ? ProjectableSqlAggFunctions.PROJECTABLE_COUNT : SqlStdOperatorTable.COUNT;
                newAggCalls.add(AggregateCall.create(countFunction, false, (List)ImmutableList.of((Object)indexOfOne), aggregateCall.filterArg, aggregate.getGroupCount(), newInput, (RelDataType)null, aggregateCall.getName()));
            }
        }
        if (equivalentAggregateCalls.needProjectOnTop()) {
            newAggCalls.add(AggregateCall.create(SqlStdOperatorTable.COUNT, false, (List)ImmutableList.of((Object)indexOfOne), -1, aggregate.getGroupCount(), newInput, (RelDataType)null, "CONVERT_COUNT_STAR"));
        }
        final int[] newGroupSet = new int[aggregate.getGroupCount()];
        int i = 0;
        for (final int group : aggregate.getGroupSet()) {
            newGroupSet[i] = newMapping[group];
            ++i;
        }
        relBuilder.aggregate(relBuilder.groupKey(newGroupSet), (List)newAggCalls);
        ConvertToCountOne.LOGGER.debug("NewAggregate: " + relBuilder.groupKey(newGroupSet) + ", " + newAggCalls);
    }
    
    private void addTopProject(final Aggregate aggregate, final RelNode input, final RelBuilder relBuilder, final RexBuilder rexBuilder, final SetOfCountOneEquivalentAggregateCalls equivalentAggregateCalls) {
        int indexForTopProject = 0;
        final RelNode inputToTopProject = relBuilder.peek();
        final int indexToCount1 = inputToTopProject.getRowType().getFieldCount() - 1;
        final List<RexNode> topProjectExprs = (List<RexNode>)Lists.newArrayList();
        for (final int group : aggregate.getGroupSet()) {
            topProjectExprs.add((RexNode)rexBuilder.makeInputRef(inputToTopProject, indexForTopProject));
            ++indexForTopProject;
        }
        int indexInRowType = aggregate.getGroupCount();
        for (final AggregateCall aggregateCall : aggregate.getAggCallList()) {
            final CountOneType type = equivalentAggregateCalls.aggCalls.get(aggregateCall);
            if (type == null) {
                topProjectExprs.add((RexNode)rexBuilder.makeInputRef(inputToTopProject, indexForTopProject));
                ++indexForTopProject;
            }
            else if (type == CountOneType.SUM_OF_LITERAL) {
                Preconditions.checkState(input instanceof Project, (Object)"An aggregate relnode with sum(literal) should only occur on top of a project");
                final RexNode aggCallInput = ((Project)input).getProjects().get(aggregateCall.getArgList().get(0));
                topProjectExprs.add(rexBuilder.makeAbstractCast(aggregate.getRowType().getFieldList().get(indexInRowType).getType(), rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.MULTIPLY, new RexNode[] { aggCallInput, rexBuilder.makeInputRef(inputToTopProject, indexToCount1) })));
            }
            else if (type == CountOneType.COUNT_DIMENSION) {
                final int dimensionIndexInGroupBy = aggregate.getGroupSet().indexOf((int)aggregateCall.getArgList().get(0));
                Preconditions.checkState(dimensionIndexInGroupBy >= 0, (Object)"Cannot replace count(column) if the column is not being grouped by");
                final RexNode condition = rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NULL, new RexNode[] { rexBuilder.makeInputRef(inputToTopProject, dimensionIndexInGroupBy) });
                final RexNode count1InputRef = (RexNode)rexBuilder.makeInputRef(inputToTopProject, indexToCount1);
                topProjectExprs.add(rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.CASE, new RexNode[] { condition, rexBuilder.makeZeroLiteral(aggregateCall.getType()), count1InputRef }));
            }
            else {
                topProjectExprs.add((RexNode)rexBuilder.makeInputRef(inputToTopProject, indexToCount1));
            }
            ++indexInRowType;
        }
        relBuilder.project((Iterable)topProjectExprs, (Iterable)aggregate.getRowType().getFieldNames());
        ConvertToCountOne.LOGGER.debug("NewTopProject: " + topProjectExprs);
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rel(0);
        final RelNode input = call.rel(1);
        final SetOfCountOneEquivalentAggregateCalls equivalentAggregateCalls = new SetOfCountOneEquivalentAggregateCalls();
        final int[] inputRefReferenceCount = this.findAggCallsEquivalentToCountStar(aggregate, input, equivalentAggregateCalls);
        if (equivalentAggregateCalls.isEmpty()) {
            ConvertToCountOne.LOGGER.debug("Did not find any aggregate calls that are equivalent to count(1)");
            return;
        }
        final RelBuilder relBuilder = this.relBuilderFactory.create(aggregate.getCluster(), (RelOptSchema)null);
        final RexBuilder rexBuilder = aggregate.getCluster().getRexBuilder();
        final RelDataTypeFactory typeFactory = rexBuilder.getTypeFactory();
        final List<Integer> reverseMapping = new ArrayList<Integer>();
        final int[] newMapping = this.getMappings(aggregate, input, inputRefReferenceCount, reverseMapping);
        this.addBottomProjectWithLiteralOne(input, reverseMapping, relBuilder, rexBuilder, typeFactory);
        this.addNewAggregateWithCollapsedCountOne(aggregate, relBuilder, newMapping, equivalentAggregateCalls);
        if (equivalentAggregateCalls.needProjectOnTop()) {
            this.addTopProject(aggregate, input, relBuilder, rexBuilder, equivalentAggregateCalls);
        }
        final RelNode newRel = relBuilder.build();
        ConvertToCountOne.LOGGER.debug("Transforming to " + newRel);
        call.transformTo(newRel);
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)ConvertToCountOne.class);
        INSTANCE = new ConvertToCountOne();
    }
    
    enum CountOneType
    {
        EXACT, 
        BASIC_EQUIV, 
        SUM_OF_LITERAL, 
        COUNT_DIMENSION;
    }
    
    private class SetOfCountOneEquivalentAggregateCalls
    {
        private final Map<AggregateCall, CountOneType> aggCalls;
        private int numExactCountOne;
        private int numSumOfLiteral;
        private int numCountDimension;
        
        private SetOfCountOneEquivalentAggregateCalls() {
            this.aggCalls = new HashMap<AggregateCall, CountOneType>();
            this.numExactCountOne = 0;
            this.numSumOfLiteral = 0;
            this.numCountDimension = 0;
        }
        
        private void clear() {
            this.aggCalls.clear();
            this.numExactCountOne = 0;
            this.numSumOfLiteral = 0;
            this.numCountDimension = 0;
        }
        
        private boolean isEmpty() {
            return this.aggCalls.isEmpty();
        }
        
        private void addAggregateCall(final AggregateCall aggCall, final CountOneType type) {
            if (!this.aggCalls.containsKey(aggCall)) {
                this.aggCalls.put(aggCall, type);
                switch (type) {
                    case SUM_OF_LITERAL: {
                        ++this.numSumOfLiteral;
                        break;
                    }
                    case COUNT_DIMENSION: {
                        ++this.numCountDimension;
                        break;
                    }
                    case EXACT: {
                        ++this.numExactCountOne;
                        break;
                    }
                }
            }
        }
        
        private boolean needProjectOnTop() {
            return this.aggCalls.size() > 1 || this.numSumOfLiteral > 0 || this.numCountDimension > 0;
        }
    }
}
