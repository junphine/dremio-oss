package com.dremio.exec.planner.acceleration.normalization.rules;

import com.dremio.exec.planner.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.sql.type.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.sql.fun.*;
import org.apache.calcite.sql.*;

public class RexNodeReducer extends RoutingShuttle
{
    private RexShuttle getRexShuttle(final RelNode node) {
        return new RexNodeReducerShuttle(node.getCluster().getRexBuilder());
    }
    
    public RelNode visit(final LogicalFilter filter) {
        final RelNode childVisited = this.visitChild((RelNode)filter, 0, filter.getInput());
        return childVisited.accept(this.getRexShuttle((RelNode)filter));
    }
    
    public RelNode visit(final LogicalProject project) {
        final RelNode childVisited = this.visitChild((RelNode)project, 0, project.getInput());
        return childVisited.accept(this.getRexShuttle((RelNode)project));
    }
    
    public RelNode visit(final LogicalJoin join) {
        final RelNode childVisited = this.visitChildren((RelNode)join);
        return childVisited.accept(this.getRexShuttle((RelNode)join));
    }
    
    public RelNode visit(final RelNode other) {
        final RelNode childVisited = this.visitChildren(other);
        return childVisited.accept(this.getRexShuttle(other));
    }
    
    private class RexNodeReducerShuttle extends RexShuttle
    {
        private final RexBuilder rexBuilder;
        
        public RexNodeReducerShuttle(final RexBuilder rexBuilder) {
            this.rexBuilder = rexBuilder;
        }
        
        private boolean isBooleanLiteral(final RexNode node) {
            return node.getKind() == SqlKind.LITERAL && node.getType().getSqlTypeName() == SqlTypeName.BOOLEAN;
        }
        
        private boolean bothBooleanInputs(final RexCall call) {
            return call.getOperands().size() == 2 && call.getOperands().get(0).getType().getSqlTypeName() == SqlTypeName.BOOLEAN && call.getOperands().get(1).getType().getSqlTypeName() == SqlTypeName.BOOLEAN;
        }
        
        public RexNode visitCall(final RexCall call) {
            switch (call.getKind()) {
                case EQUALS: {
                    if (this.bothBooleanInputs(call)) {
                        final RexNode op0 = call.getOperands().get(0);
                        final RexNode op2 = call.getOperands().get(1);
                        if (this.isBooleanLiteral(op0)) {
                            if (op0.isAlwaysTrue()) {
                                final RexNode op1Reduced = (RexNode)op2.accept((RexVisitor)this);
                                return op1Reduced;
                            }
                            if (op0.isAlwaysFalse()) {
                                final RexNode op1Reduced = (RexNode)op2.accept((RexVisitor)this);
                                return this.rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.NOT, new RexNode[] { op1Reduced });
                            }
                        }
                        if (this.isBooleanLiteral(op2)) {
                            if (op2.isAlwaysTrue()) {
                                final RexNode op0Reduced = (RexNode)op0.accept((RexVisitor)this);
                                return op0Reduced;
                            }
                            if (op2.isAlwaysFalse()) {
                                final RexNode op0Reduced = (RexNode)op0.accept((RexVisitor)this);
                                return this.rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.NOT, new RexNode[] { op0Reduced });
                            }
                        }
                        break;
                    }
                    break;
                }
            }
            return super.visitCall(call);
        }
    }
}
