package com.dremio.exec.planner.acceleration.normalization;

import com.dremio.options.*;
import com.dremio.exec.proto.*;
import com.dremio.exec.planner.acceleration.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.rel.core.*;
import com.dremio.exec.planner.acceleration.normalization.rules.*;
import com.google.common.collect.*;
import com.dremio.exec.planner.*;
import java.util.*;

public class AdvancedNodeStripper implements StrippingFactory.NodeStripper
{
    private static final Normalizer NORMALIZER;
    
    public StrippingFactory.StripResult apply(final OptionManager options, final UserBitShared.ReflectionType reflectionType, final RelNode orig, final boolean isIncremental) {
        final RelNode normalized1 = AdvancedNodeStripper.NORMALIZER.normalize(orig);
        final RelNode strippedNormalize1 = ExpansionNode.removeFromTree(normalized1);
        final StripMarker sm = new StripMarker();
        strippedNormalize1.accept((RelShuttle)sm);
        final List<RelNode> nodes = sm.nodeString;
        final int stripToNode = this.findStripNodesList(nodes, isIncremental);
        final RelNode strippedRoot = nodes.get(stripToNode);
        final RelNode normalized2 = AdvancedNodeStripper.NORMALIZER.normalize(strippedRoot);
        final RelNode stripSegment = strippedNormalize1.accept((RelShuttle)new RoutingShuttle() {
            public RelNode visit(final RelNode other) {
                if (other == strippedRoot) {
                    return (RelNode)new StrippingFactory.StripLeaf(strippedRoot.getCluster(), strippedRoot.getTraitSet(), strippedRoot.getRowType());
                }
                return super.visit(other);
            }
        });
        return new StrippingFactory.StripResult(normalized2, stripSegment);
    }
    
    private int findStripNodesList(final List<RelNode> nodes, final boolean isIncremental) {
        for (int i = 0; i < nodes.size(); ++i) {
            final RelNode node = nodes.get(i);
            if (!(node instanceof Project)) {
                if (node instanceof Sort) {
                    final Sort sort = (Sort)node;
                    if (sort.fetch != null || sort.offset != null) {
                        return 0;
                    }
                }
                else {
                    if (!(node instanceof Aggregate)) {
                        return 0;
                    }
                    if (isIncremental) {
                        return i + 1;
                    }
                    return i;
                }
            }
        }
        return 0;
    }
    
    static {
        NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer((List<StatelessRelShuttleImpl>)ImmutableList.of((Object)new RexNodeReducer()), Normalizers.COMMON_RULES_FOR_VIEW);
    }
    
    private static class StripMarker extends RoutingShuttle
    {
        private final List<RelNode> nodeString;
        
        private StripMarker() {
            this.nodeString = new ArrayList<RelNode>();
        }
        
        public RelNode visit(final RelNode other) {
            this.nodeString.add(other);
            final List<RelNode> children = (List<RelNode>)other.getInputs();
            if (children.size() != 1) {
                return other;
            }
            return super.visit(other);
        }
    }
}
