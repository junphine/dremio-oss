package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rex.*;
import java.util.*;

public final class AddProjectBelowAggregateRule extends RelOptRule
{
    public static final AddProjectBelowAggregateRule INSTANCE;
    
    private AddProjectBelowAggregateRule() {
        super(operand((Class)Aggregate.class, operand((Class)RelNode.class, any()), new RelOptRuleOperand[0]), AddProjectBelowAggregateRule.class.getSimpleName());
    }
    
    public boolean matches(final RelOptRuleCall call) {
        if (!super.matches(call)) {
            return false;
        }
        final RelNode child = call.rel(1);
        return !(child instanceof Project);
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rel(0);
        final RelNode child = call.rel(1);
        if (child instanceof Project) {
            return;
        }
        final RelBuilder relBuilder = call.builder();
        final RexBuilder rexBuilder = call.builder().getRexBuilder();
        relBuilder.push(child);
        final Map<Integer, Integer> mapping = new HashMap<Integer, Integer>();
        final List<RexNode> projectExprs = new ArrayList<RexNode>();
        final List<AggregateCall> aggregateCalls = new ArrayList<AggregateCall>();
        final int[] groupKeys = new int[aggregate.getGroupCount()];
        int i = 0;
        for (final int group : aggregate.getGroupSet()) {
            if (!mapping.containsKey(group)) {
                mapping.put(group, mapping.size());
                projectExprs.add((RexNode)rexBuilder.makeInputRef(child, group));
            }
            groupKeys[i] = mapping.get(group);
            ++i;
        }
        for (final AggregateCall aggregateCall : aggregate.getAggCallList()) {
            final List<Integer> newArgList = new ArrayList<Integer>();
            for (final int argIndex : aggregateCall.getArgList()) {
                if (!mapping.containsKey(argIndex)) {
                    mapping.put(argIndex, mapping.size());
                    projectExprs.add((RexNode)rexBuilder.makeInputRef(child, argIndex));
                }
                newArgList.add(mapping.get(argIndex));
            }
            aggregateCalls.add(aggregateCall.copy((List)newArgList, aggregateCall.filterArg));
        }
        relBuilder.project((Iterable)projectExprs);
        if (relBuilder.peek() instanceof Project) {
            relBuilder.aggregate(relBuilder.groupKey(groupKeys), (List)aggregateCalls);
            call.transformTo(relBuilder.build());
        }
    }
    
    static {
        INSTANCE = new AddProjectBelowAggregateRule();
    }
}
