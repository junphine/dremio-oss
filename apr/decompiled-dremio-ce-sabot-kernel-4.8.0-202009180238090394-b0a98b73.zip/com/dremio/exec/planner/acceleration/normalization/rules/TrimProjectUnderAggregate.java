package com.dremio.exec.planner.acceleration.normalization.rules;

import org.apache.calcite.plan.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.*;
import java.util.*;
import org.apache.calcite.rex.*;

public final class TrimProjectUnderAggregate extends RelOptRule
{
    public static final RelOptRule INSTANCE;
    
    private TrimProjectUnderAggregate() {
        super(operand((Class)Aggregate.class, operand((Class)Project.class, any()), new RelOptRuleOperand[0]), "TrimProjectUnderAggrgate");
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate a = (Aggregate)call.rel(0);
        final Project p = (Project)call.rel(1);
        final RelNode input = p.getInput();
        final RelBuilder builder = call.builder();
        builder.push(input);
        final int flattens = FlattenVisitors.FlattenCounter.count(p);
        final List<RexNode> currentProjectExpressions = (List<RexNode>)p.getProjects();
        final List<RexNode> newProjectExpressions = new ArrayList<RexNode>();
        final List<Integer> groupingKeys = new ArrayList<Integer>();
        final Map<RexNode, Integer> expressions = new IdentityHashMap<RexNode, Integer>();
        for (final Integer i : a.getGroupSet()) {
            final RexNode current = currentProjectExpressions.get(i);
            Integer currentIndex = expressions.get(current);
            if (currentIndex == null) {
                currentIndex = newProjectExpressions.size();
                expressions.put(current, currentIndex);
                newProjectExpressions.add(current);
            }
            groupingKeys.add(currentIndex);
        }
        final RexBuilder rb = builder.getRexBuilder();
        final List<RelBuilder.AggCall> aggCalls = new ArrayList<RelBuilder.AggCall>();
        for (final AggregateCall aCall : a.getAggCallList()) {
            if (aCall.getArgList().size() != 1) {
                return;
            }
            final Integer index = aCall.getArgList().get(0);
            final RexNode current2 = currentProjectExpressions.get(index);
            Integer currentIndex2 = expressions.get(current2);
            if (currentIndex2 == null) {
                currentIndex2 = newProjectExpressions.size();
                expressions.put(current2, currentIndex2);
                newProjectExpressions.add(current2);
            }
            if (aCall.filterArg != -1) {
                return;
            }
            aggCalls.add(builder.aggregateCall(aCall.getAggregation(), aCall.isDistinct(), (RexNode)null, aCall.name, new RexNode[] { rb.makeInputRef(current2.getType(), (int)currentIndex2) }));
        }
        if (newProjectExpressions.size() == currentProjectExpressions.size()) {
            return;
        }
        builder.project((Iterable)newProjectExpressions);
        final RelNode project = builder.build();
        if (project instanceof Project) {
            final int finalFlattenCount = FlattenVisitors.FlattenCounter.count((Project)project);
            if (finalFlattenCount != flattens) {
                return;
            }
        }
        builder.push(project);
        final int[] fieldOrdinals = new int[groupingKeys.size()];
        for (int j = 0; j < groupingKeys.size(); ++j) {
            fieldOrdinals[j] = groupingKeys.get(j);
        }
        builder.aggregate(builder.groupKey(fieldOrdinals), (Iterable)aggCalls);
        call.transformTo(builder.build());
    }
    
    static {
        INSTANCE = new TrimProjectUnderAggregate();
    }
}
