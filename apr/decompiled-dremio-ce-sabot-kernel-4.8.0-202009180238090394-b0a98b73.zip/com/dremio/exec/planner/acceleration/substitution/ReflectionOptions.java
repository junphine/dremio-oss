package com.dremio.exec.planner.acceleration.substitution;

import com.dremio.options.*;

@Options
public interface ReflectionOptions
{
    public static final TypeValidators.BooleanValidator REFLECTION_TRACING = new TypeValidators.BooleanValidator("accelerator.matching.tracing", false);
    public static final TypeValidators.PositiveLongValidator REFLECTION_TIMEOUT = new TypeValidators.PositiveLongValidator("accelerator.matching.timeout_seconds", 100000L, 30L);
    public static final TypeValidators.BooleanValidator ACCELERATION_RAW_REMOVE_PROJECT = new TypeValidators.BooleanValidator("accelerator.raw.remove_project", true);
    public static final TypeValidators.BooleanValidator ACCELERATION_ENABLE_AGG_JOIN = new TypeValidators.BooleanValidator("accelerator.enable_agg_join", true);
    public static final TypeValidators.BooleanValidator ACCELERATION_ENABLE_MULTIJOIN = new TypeValidators.BooleanValidator("accelerator.enable_multijoin", true);
    public static final TypeValidators.BooleanValidator ACCELERATION_ENABLE_DEFAULT_RAW = new TypeValidators.BooleanValidator("accelerator.enable_default_raw", true);
    public static final TypeValidators.BooleanValidator SIMPLIFIED_MATCH = new TypeValidators.BooleanValidator("accelerator.simplified_match", false);
    public static final TypeValidators.BooleanValidator TRIM_USER_QUERY = new TypeValidators.BooleanValidator("reflections.planning.trim_query", true);
    public static final TypeValidators.BooleanValidator EXPANSION_MATCH = new TypeValidators.BooleanValidator("reflections.planning.expansion_match", true);
    public static final TypeValidators.BooleanValidator ALGEBRAIC_MATCH = new TypeValidators.BooleanValidator("reflections.planning.algebraic_match", true);
    public static final TypeValidators.BooleanValidator VAILDATE_CONSISTENCY = new TypeValidators.BooleanValidator("reflections.planning.extra_validation", true);
    public static final TypeValidators.PositiveLongValidator ACCELERATION_FILTER_THRESHOLD = new TypeValidators.PositiveLongValidator("accelerator.matching.filter_threshold", Long.MAX_VALUE, 4900L);
}
