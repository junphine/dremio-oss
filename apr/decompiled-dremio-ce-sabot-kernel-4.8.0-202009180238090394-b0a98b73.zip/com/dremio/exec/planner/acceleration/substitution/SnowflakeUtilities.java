package com.dremio.exec.planner.acceleration.substitution;

import org.apache.calcite.util.graph.*;
import java.util.function.*;
import com.dremio.exec.planner.acceleration.*;
import org.apache.calcite.rel.*;
import com.dremio.service.*;
import org.apache.calcite.rel.core.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.metadata.*;
import org.slf4j.*;
import org.apache.calcite.plan.*;
import com.dremio.exec.planner.*;
import com.dremio.exec.planner.acceleration.normalization.*;
import org.apache.calcite.rel.logical.*;
import com.dremio.exec.planner.logical.*;
import java.util.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.sql.fun.*;
import org.apache.calcite.sql.*;
import org.apache.calcite.rex.*;

public final class SnowflakeUtilities
{
    private static final Logger logger;
    private static final Normalizer SNOWFLAKE_JOIN_NORMALIZER;
    private static DirectedGraph.EdgeFactory<List<String>, DefaultEdge> factory;
    
    public static DremioMaterialization generateShadowReflection(final RelNode query, final DremioMaterialization materialization) {
        final JoinDependencyProperties snowflakeSchemaProperties = materialization.getJoinDependencyProperties();
        if (snowflakeSchemaProperties == null || hasDuplicateTables(materialization.getQueryRel())) {
            return materialization;
        }
        final Set<List<String>> queryTables = (Set<List<String>>)SubstitutionUtils.findTables(query);
        final Set<List<String>> targetTables = (Set<List<String>>)SubstitutionUtils.findTables(materialization.getQueryRel());
        final Set<List<String>> missingTables = (Set<List<String>>)Sets.difference((Set)targetTables, (Set)queryTables);
        final DirectedGraph<List<String>, DefaultEdge> graph = (DirectedGraph<List<String>, DefaultEdge>)DefaultDirectedGraph.create((DirectedGraph.EdgeFactory)SnowflakeUtilities.factory);
        final Set<List<String>> set = missingTables;
        final DirectedGraph<List<String>, DefaultEdge> directedGraph = graph;
        Objects.requireNonNull(directedGraph);
        set.forEach(directedGraph::addVertex);
        for (final JoinDependencyProperties.Dependency dependency : snowflakeSchemaProperties.getDependencies()) {
            if (targetTables.contains(dependency.foreignKeyTable) && targetTables.contains(dependency.uniqueKeyTable)) {
                graph.addVertex((Object)dependency.foreignKeyTable);
                graph.addVertex((Object)dependency.uniqueKeyTable);
                graph.addEdge((Object)dependency.foreignKeyTable, (Object)dependency.uniqueKeyTable);
            }
        }
        RelNode newQueryRel = SnowflakeUtilities.SNOWFLAKE_JOIN_NORMALIZER.normalize(materialization.getQueryRel());
        int totalRemoved = 0;
        while (true) {
            int removed = 0;
            for (final List<String> vertex : graph.vertexSet()) {
                if (missingTables.contains(vertex) && graph.getOutwardEdges((Object)vertex).size() == 0) {
                    final JoinRemover joinRemover = new JoinRemover(vertex);
                    newQueryRel = newQueryRel.accept((RelShuttle)joinRemover);
                    if (joinRemover.removed) {
                        ++removed;
                        ++totalRemoved;
                        graph.removeAllVertices((Collection)ImmutableList.of((Object)vertex));
                        break;
                    }
                    continue;
                }
            }
            if (totalRemoved != missingTables.size() && removed != 0) {
                continue;
            }
            break;
        }
        if (totalRemoved == 0) {
            return materialization;
        }
        return materialization.createSnowflakeMaterialization(newQueryRel);
    }
    
    private static boolean hasDuplicateTables(final RelNode relNode) {
        final Set<List<String>> tables = new HashSet<List<String>>();
        final Pointer<Boolean> duplicate = (Pointer<Boolean>)new Pointer((Object)false);
        relNode.accept((RelShuttle)new RoutingShuttle() {
            public RelNode visit(final TableScan scan) {
                final boolean duplicateFound = !tables.add(scan.getTable().getQualifiedName());
                if (duplicateFound) {
                    SnowflakeUtilities.logger.debug("Duplicate table found: {}", (Object)scan.getTable().getQualifiedName());
                }
                duplicate.value = ((boolean)duplicate.value || duplicateFound);
                return (RelNode)scan;
            }
        });
        return (boolean)duplicate.value;
    }
    
    private static Set<List<String>> getInputTables(final RelNode relNode) {
        final RelMetadataQuery relMetadataQuery = relNode.getCluster().getMetadataQuery();
        final Set<List<String>> inputTables = new HashSet<List<String>>();
        for (int i = 0; i < relNode.getRowType().getFieldCount(); ++i) {
            final Set<RelColumnOrigin> columnOrigins = (Set<RelColumnOrigin>)relMetadataQuery.getColumnOrigins(relNode, i);
            if (columnOrigins != null) {
                final RelColumnOrigin origin = (RelColumnOrigin)Iterables.getFirst((Iterable)columnOrigins, (Object)null);
                if (origin != null) {
                    inputTables.add(origin.getOriginTable().getQualifiedName());
                }
            }
        }
        SnowflakeUtilities.logger.debug("Input tables: {}", (Object)inputTables);
        return inputTables;
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)SnowflakeUtilities.class);
        SNOWFLAKE_JOIN_NORMALIZER = (Normalizer)new RuleAndShuttleNormalizer(new RelOptRule[] { PlannerPhase.FILTER_INTO_JOIN_CALCITE_RULE });
        SnowflakeUtilities.factory = (DirectedGraph.EdgeFactory<List<String>, DefaultEdge>)new DirectedGraph.EdgeFactory<List<String>, DefaultEdge>() {
            public DefaultEdge createEdge(final List<String> v0, final List<String> v1) {
                return new DefaultEdge(v0, v1) {
                    public String toString() {
                        return String.format("Vertex: %s, Target: %s", v0, v1);
                    }
                };
            }
        };
    }
    
    private static class JoinRemover extends RoutingShuttle
    {
        private List<String> tableToRemove;
        private boolean removed;
        
        JoinRemover(final List<String> tableToRemove) {
            this.tableToRemove = tableToRemove;
        }
        
        public RelNode visit(final LogicalJoin join) {
            final RexBuilder rexBuilder = join.getCluster().getRexBuilder();
            final RelNode left = join.getLeft();
            final Set<List<String>> leftInputs = getInputTables(left);
            if (leftInputs.size() == 1 && leftInputs.iterator().next().equals(this.tableToRemove)) {
                final org.apache.calcite.tools.RelBuilder relBuilder = RelBuilder.newCalciteRelBuilderWithoutContext(join.getCluster());
                relBuilder.push(join.getRight());
                final List<RexNode> projects = new ArrayList<RexNode>();
                for (final RelDataTypeField field : left.getRowType().getFieldList()) {
                    projects.add(rexBuilder.makeCast(field.getType(), rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.RAND, new RexNode[0])));
                }
                for (int i = 0; i < join.getRight().getRowType().getFieldCount(); ++i) {
                    projects.add((RexNode)relBuilder.field(i));
                }
                this.removed = true;
                return relBuilder.project((Iterable)projects).build();
            }
            if (leftInputs.contains(this.tableToRemove)) {
                final RelNode newLeft = left.accept((RelShuttle)this);
                return (RelNode)join.copy(join.getTraitSet(), (List)ImmutableList.of((Object)newLeft, (Object)join.getRight()));
            }
            final RelNode right = join.getRight();
            final Set<List<String>> rightInputs = getInputTables(right);
            if (rightInputs.size() == 1 && rightInputs.iterator().next().equals(this.tableToRemove)) {
                final org.apache.calcite.tools.RelBuilder relBuilder = RelBuilder.newCalciteRelBuilderWithoutContext(join.getCluster());
                relBuilder.push(join.getLeft());
                final List<RexNode> projects = new ArrayList<RexNode>();
                for (int i = 0; i < join.getLeft().getRowType().getFieldCount(); ++i) {
                    projects.add((RexNode)relBuilder.field(i));
                }
                for (final RelDataTypeField field : right.getRowType().getFieldList()) {
                    projects.add(rexBuilder.makeCast(field.getType(), rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.RAND, new RexNode[0])));
                }
                this.removed = true;
                return relBuilder.project((Iterable)projects).build();
            }
            if (rightInputs.contains(this.tableToRemove)) {
                final RelNode newLeft = right.accept((RelShuttle)this);
                return (RelNode)join.copy(join.getTraitSet(), (List)ImmutableList.of((Object)newLeft, (Object)join.getRight()));
            }
            return (RelNode)join;
        }
    }
}
