package com.dremio.exec.planner.acceleration.substitution.rules;

import org.apache.calcite.plan.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.sql.fun.*;
import java.math.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.sql.*;

public class ProjectableAggregateToProjectRule extends RelOptRule
{
    public static ProjectableAggregateToProjectRule INSTANCE;
    
    public ProjectableAggregateToProjectRule(final RelOptRuleOperand operand, final String description, final RelBuilderFactory relBuilderFactory) {
        super(operand, relBuilderFactory, description);
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final LogicalAggregate topAggregate = (LogicalAggregate)call.rel(0);
        final LogicalProject topProject = (LogicalProject)call.rel(1);
        final LogicalJoin join = (LogicalJoin)call.rel(2);
        final RelNode left = call.rel(3);
        final RelNode right = call.rel(4);
        boolean unchanged = true;
        final List<RelNode> newInputs = new ArrayList<RelNode>();
        for (final RelNode input : Arrays.asList(left, right)) {
            if (!(input instanceof LogicalAggregate)) {
                newInputs.add(input);
            }
            else {
                final LogicalAggregate aggregate = (LogicalAggregate)input;
                if (!ProjectableSqlAggFunctions.isProjectableAggregate((Aggregate)aggregate)) {
                    newInputs.add(input);
                }
                else {
                    unchanged = false;
                    final RelBuilder relBuilder = call.builder();
                    newInputs.add(this.convertAggregate(aggregate, relBuilder));
                }
            }
        }
        if (unchanged) {
            return;
        }
        final RelNode newJoin = (RelNode)join.copy(join.getTraitSet(), (List)newInputs);
        final RelNode newTopProject = topProject.copy(topProject.getTraitSet(), (List)ImmutableList.of((Object)newJoin));
        final RelNode newTopAggregate = topAggregate.copy(topAggregate.getTraitSet(), (List)ImmutableList.of((Object)newTopProject));
        call.transformTo(newTopAggregate);
    }
    
    private RelNode convertAggregate(final LogicalAggregate aggregate, final RelBuilder relBuilder) {
        final RelNode aggInput = aggregate.getInput();
        final List<RelDataTypeField> inputFieldList = (List<RelDataTypeField>)aggInput.getRowType().getFieldList();
        final List<RexNode> projects = new ArrayList<RexNode>();
        for (final Integer i : aggregate.getGroupSet()) {
            final RelDataType type = inputFieldList.get(i).getType();
            projects.add((RexNode)new RexInputRef((int)i, type));
        }
        final RexBuilder rexBuilder = aggregate.getCluster().getRexBuilder();
        for (final AggregateCall aggCall : aggregate.getAggCallList()) {
            final int index = aggCall.getArgList().get(0);
            projects.add(this.convertAggCall(aggCall, inputFieldList.get(index).getType(), rexBuilder));
        }
        return relBuilder.push(aggInput).project((Iterable)projects).build();
    }
    
    private RexNode convertAggCall(final AggregateCall call, final RelDataType type, final RexBuilder rexBuilder) {
        final int index = call.getArgList().get(0);
        final RexInputRef ref = new RexInputRef(index, type);
        switch (call.getAggregation().getKind()) {
            case COUNT: {
                if (call.getArgList().size() == 1) {
                    return rexBuilder.makeCall(rexBuilder.getTypeFactory().createTypeWithNullability(call.getType(), false), (SqlOperator)SqlStdOperatorTable.CASE, (List)ImmutableList.of((Object)rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NULL, new RexNode[] { ref }), (Object)ref, (Object)rexBuilder.makeBigintLiteral(BigDecimal.ONE)));
                }
                return (RexNode)rexBuilder.makeBigintLiteral(BigDecimal.ONE);
            }
            case SUM0: {
                return rexBuilder.makeCall(rexBuilder.getTypeFactory().createTypeWithNullability(call.getType(), false), (SqlOperator)SqlStdOperatorTable.CASE, (List)ImmutableList.of((Object)rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NULL, new RexNode[] { ref }), (Object)rexBuilder.makeBigintLiteral(BigDecimal.ZERO), (Object)ref));
            }
            case SUM: {
                return rexBuilder.makeCast(call.getType(), (RexNode)ref, true);
            }
            default: {
                return (RexNode)ref;
            }
        }
    }
    
    static {
        ProjectableAggregateToProjectRule.INSTANCE = new ProjectableAggregateToProjectRule(operand((Class)LogicalAggregate.class, operand((Class)LogicalProject.class, operand((Class)LogicalJoin.class, operand((Class)RelNode.class, any()), new RelOptRuleOperand[] { operand((Class)RelNode.class, any()) }), new RelOptRuleOperand[0]), new RelOptRuleOperand[0]), "ProjectableAggregateToProject", DremioRelFactories.CALCITE_LOGICAL_BUILDER);
    }
}
