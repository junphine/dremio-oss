package com.dremio.exec.planner.acceleration.substitution;

import com.dremio.common.config.*;
import com.dremio.options.*;

public class DremioSubstitutionProviderFactory implements SubstitutionProviderFactory
{
    public SubstitutionProvider getSubstitutionProvider(final SabotConfig config, final MaterializationProvider materializationProvider, final OptionManager options) {
        return (SubstitutionProvider)new DremioSubstitutionProvider(config, materializationProvider, options);
    }
}
