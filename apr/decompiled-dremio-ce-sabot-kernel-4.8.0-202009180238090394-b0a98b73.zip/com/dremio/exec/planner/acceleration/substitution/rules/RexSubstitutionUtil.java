package com.dremio.exec.planner.acceleration.substitution.rules;

import org.apache.calcite.rel.type.*;
import com.google.common.base.*;
import com.google.common.collect.*;
import org.slf4j.*;
import org.apache.calcite.plan.*;
import java.util.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.sql.*;

public final class RexSubstitutionUtil
{
    private static final Logger LOGGER;
    
    public static boolean implies(final List<RexNode> filterOrig, final List<RexNode> filtersToCompareTo, final RelDataType inputRowType, final RexBuilder rexBuilder, final RexExecutor rexExecutor, final List<RexNode> outputRemainingFilter) {
        Preconditions.checkArgument(outputRemainingFilter != null && outputRemainingFilter.isEmpty(), (Object)"RemainingFilter should be empty list and will be populated by implies()");
        RexSubstitutionUtil.LOGGER.debug("Check query filter conditions implies target filter conditions, query: [{}], target: [{}]", (Object)filterOrig, (Object)filtersToCompareTo);
        final List<RexNode> filterOrigCopy = (List<RexNode>)Lists.newArrayList((Iterable)filterOrig);
        final List<ClauseWrapper> filterClausePastProject = new ArrayList<ClauseWrapper>();
        for (final RexNode inputfilter : filterOrig) {
            filterClausePastProject.add(new ClauseWrapper(inputfilter, rexBuilder));
        }
        final List<ClauseWrapper> filterPossiblyImpliedClause = new ArrayList<ClauseWrapper>();
        for (final RexNode impliedfilter : filtersToCompareTo) {
            filterPossiblyImpliedClause.add(new ClauseWrapper(impliedfilter, rexBuilder));
        }
        final List<Integer> foundImpliedFilterMatch = (List<Integer>)Lists.newArrayList();
        final Set<Integer> foundOriginalFilterMatch = (Set<Integer>)Sets.newHashSet();
        for (int impliedIndex = 0; impliedIndex < filterPossiblyImpliedClause.size(); ++impliedIndex) {
            int filterIndex = 0;
            while (filterIndex < filterClausePastProject.size()) {
                final ClauseWrapper impliedClause = filterPossiblyImpliedClause.get(impliedIndex);
                final ClauseWrapper otherClause = filterClausePastProject.get(filterIndex);
                if (otherClause.satisfies(impliedClause)) {
                    foundImpliedFilterMatch.add(impliedIndex);
                    if (impliedClause.satisfies(otherClause)) {
                        foundOriginalFilterMatch.add(filterIndex);
                        break;
                    }
                    break;
                }
                else {
                    ++filterIndex;
                }
            }
        }
        final List<Integer> queryRexNodeThatMatched = (List<Integer>)Lists.newArrayList((Iterable)foundOriginalFilterMatch);
        Collections.sort(queryRexNodeThatMatched);
        for (int remove = queryRexNodeThatMatched.size() - 1; remove >= 0; --remove) {
            filterClausePastProject.remove((int)queryRexNodeThatMatched.get(remove));
            filterOrigCopy.remove((int)queryRexNodeThatMatched.get(remove));
        }
        for (int remove = foundImpliedFilterMatch.size() - 1; remove >= 0; --remove) {
            filterPossiblyImpliedClause.remove((int)foundImpliedFilterMatch.get(remove));
        }
        if (filterPossiblyImpliedClause.isEmpty()) {
            RexSubstitutionUtil.LOGGER.debug("All of  target filter conditions found in query filter conditions: [{}], target: [{}]", (Object)filterOrig, (Object)filtersToCompareTo);
            if (!filterOrigCopy.isEmpty()) {
                outputRemainingFilter.add(RexUtil.composeConjunction(rexBuilder, (Iterable)filterOrigCopy, false));
            }
            return true;
        }
        final RexImplicationChecker rexImplicationChecker = new RexImplicationChecker(rexBuilder, rexExecutor, inputRowType);
        if (rexImplicationChecker.implies(composeConditions(rexBuilder, filterClausePastProject), composeConditions(rexBuilder, filterPossiblyImpliedClause))) {
            RexSubstitutionUtil.LOGGER.debug("Query filter conditions imply target query conditions: [{}], target: [{}]", (Object)filterOrig, (Object)filtersToCompareTo);
            if (!filterOrigCopy.isEmpty()) {
                outputRemainingFilter.add(RexUtil.composeConjunction(rexBuilder, (Iterable)filterOrigCopy, false));
            }
            return true;
        }
        RexSubstitutionUtil.LOGGER.debug("Query filter conditions do not imply target filter conditions, query: [{}], target: [{}]", (Object)filterOrig, (Object)filtersToCompareTo);
        return false;
    }
    
    private static RexNode composeConditions(final RexBuilder rexBuilder, final List<ClauseWrapper> toCompose) {
        final List<RexNode> disjunctions = new ArrayList<RexNode>();
        for (final ClauseWrapper element : toCompose) {
            disjunctions.add(element.rexNode);
        }
        return RexUtil.composeConjunction(rexBuilder, (Iterable)disjunctions, false);
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)RexSubstitutionUtil.class);
    }
    
    private static final class ClauseWrapper implements Comparable<ClauseWrapper>
    {
        private final RexNode rexNode;
        private final List<RexNode> decomposed;
        private final List<String> decomposedString;
        
        private ClauseWrapper(final RexNode rexNode, final RexBuilder rexBuilder) {
            this.rexNode = rexNode;
            this.decomposed = new ArrayList<RexNode>();
            this.decomposedString = new ArrayList<String>();
            final FilterCleaner filterCleaner = new FilterCleaner(rexBuilder);
            final RexNode cleaned = (RexNode)rexNode.accept((RexVisitor)filterCleaner);
            RelOptUtil.decomposeDisjunction(cleaned, (List)this.decomposed);
            for (final RexNode node : this.decomposed) {
                this.decomposedString.add(node.toString());
            }
        }
        
        public boolean satisfies(final ClauseWrapper other) {
            return other.decomposedString.containsAll(this.decomposedString);
        }
        
        @Override
        public boolean equals(final Object o) {
            return o == this || (o instanceof ClauseWrapper && this.compareTo((ClauseWrapper)o) == 0);
        }
        
        @Override
        public int hashCode() {
            return this.rexNode.hashCode();
        }
        
        @Override
        public int compareTo(final ClauseWrapper o) {
            final String o1String = this.rexNode.toString();
            final String o2String = o.rexNode.toString();
            return o1String.compareTo(o2String);
        }
    }
    
    private static final class FilterCleaner extends RexShuttle
    {
        private final RexBuilder rexBuilder;
        
        private FilterCleaner(final RexBuilder rexBuilder) {
            this.rexBuilder = rexBuilder;
        }
        
        public RexNode visitCall(final RexCall call) {
            switch (call.getOperator().getKind()) {
                case AND:
                case OR: {
                    final List<RexNode> andOrOperands = (List<RexNode>)this.visitList((List)call.operands, new boolean[] { false });
                    final List<RexNode> andOrOperandsToSort = (List<RexNode>)Lists.newArrayList((Iterable)andOrOperands);
                    Collections.sort(andOrOperandsToSort, RexNodeComparator.INSTANCE);
                    return this.rexBuilder.makeCall(call.getOperator(), (List)andOrOperandsToSort);
                }
                case CAST: {
                    if (call.getOperands().get(0) instanceof RexInputRef) {
                        return call.getOperands().get(0);
                    }
                    break;
                }
                case GREATER_THAN:
                case GREATER_THAN_OR_EQUAL:
                case LESS_THAN:
                case LESS_THAN_OR_EQUAL:
                case EQUALS:
                case NOT_EQUALS: {
                    final List<RexNode> binaryOperands = (List<RexNode>)this.visitList(call.getOperands(), new boolean[] { false });
                    final RexNode first = binaryOperands.get(0);
                    final RexNode second = binaryOperands.get(1);
                    if (first instanceof RexInputRef && second instanceof RexLiteral) {
                        return (RexNode)call;
                    }
                    if (first instanceof RexLiteral && second instanceof RexInputRef) {
                        return this.rexBuilder.makeCall(RelOptUtil.op(call.getOperator().getKind().reverse(), call.getOperator()), new RexNode[] { second, first });
                    }
                    if (first instanceof RexInputRef && second instanceof RexInputRef) {
                        if (((RexInputRef)first).getIndex() <= ((RexInputRef)second).getIndex()) {
                            return (RexNode)call;
                        }
                        return this.rexBuilder.makeCall(RelOptUtil.op(call.getOperator().getKind().reverse(), call.getOperator()), new RexNode[] { second, first });
                    }
                    else {
                        if (first.toString().compareTo(second.toString()) <= 0) {
                            return this.rexBuilder.makeCall(call.getOperator(), new RexNode[] { first, second });
                        }
                        return this.rexBuilder.makeCall(call.getOperator(), new RexNode[] { second, first });
                    }
                    break;
                }
            }
            return super.visitCall(call);
        }
        
        private static class RexNodeComparator implements Comparator<RexNode>
        {
            public static final RexNodeComparator INSTANCE;
            
            @Override
            public int compare(final RexNode o1, final RexNode o2) {
                final String o1String = o1.toString();
                final String o2String = o2.toString();
                return o1String.compareTo(o2String);
            }
            
            static {
                INSTANCE = new RexNodeComparator();
            }
        }
    }
    
    public static class PushPastProject extends RexShuttle
    {
        final List<RexNode> projectOnTarget;
        
        public PushPastProject(final List<RexNode> projectOnTarget) {
            this.projectOnTarget = projectOnTarget;
        }
        
        public RexNode visitInputRef(final RexInputRef ref) {
            return this.projectOnTarget.get(ref.getIndex());
        }
    }
}
