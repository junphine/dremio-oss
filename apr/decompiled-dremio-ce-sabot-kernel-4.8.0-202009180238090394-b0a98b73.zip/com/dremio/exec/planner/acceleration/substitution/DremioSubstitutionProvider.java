package com.dremio.exec.planner.acceleration.substitution;

import com.dremio.common.config.*;
import com.dremio.exec.planner.observer.*;
import com.dremio.reflection.*;
import com.dremio.options.*;
import org.apache.calcite.rel.*;
import java.util.concurrent.*;
import java.util.stream.*;
import com.dremio.service.namespace.*;
import com.dremio.exec.planner.acceleration.*;
import com.dremio.service.*;
import org.apache.calcite.rel.core.*;
import com.dremio.exec.planner.physical.*;
import com.dremio.service.reflection.*;
import com.dremio.common.exceptions.*;
import org.joda.time.format.*;
import com.google.common.base.*;
import com.google.common.collect.*;
import com.dremio.exec.planner.*;
import com.dremio.exec.planner.sql.handlers.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rex.*;
import java.util.*;
import com.dremio.exec.planner.common.*;
import com.dremio.exec.proto.*;
import com.dremio.exec.planner.acceleration.normalization.*;
import org.apache.calcite.plan.*;
import com.dremio.exec.planner.logical.*;
import java.util.function.*;
import com.dremio.reflection.bup.*;
import com.dremio.reflection.rules.*;
import org.slf4j.*;
import org.apache.calcite.plan.volcano.*;
import org.apache.calcite.rel.logical.*;

public class DremioSubstitutionProvider extends UnifyingSubstitutionProvider implements Observable
{
    private static final Logger logger;
    private static final Predicate<RelNode> REPLACEMENT_NODE;
    private static final int EXPANSION_MAX_DEPTH = 2;
    private final SabotConfig config;
    private final OptionManager optionManager;
    private AttemptObserver observer;
    private final boolean enableTracing;
    private final SubstitutionErrorCollector.ListErrorCollector collector;
    private final BupTracer tracer;
    private final PlanningTerminator planningTerminator;
    private final boolean validateConsistency;
    private boolean isDefaultRawReflectionEnabled;
    
    DremioSubstitutionProvider(final SabotConfig config, final MaterializationProvider materializationProvider, final OptionManager optionManager) {
        super(materializationProvider);
        this.observer = null;
        this.collector = new SubstitutionErrorCollector.ListErrorCollector();
        this.config = config;
        this.optionManager = optionManager;
        this.enableTracing = optionManager.getOption(ReflectionOptions.REFLECTION_TRACING);
        this.tracer = new BupTracer(this.enableTracing, this.collector);
        this.planningTerminator = new PlanningTerminator(optionManager.getOption((TypeValidators.LongValidator)ReflectionOptions.REFLECTION_TIMEOUT) * 1000L);
        this.validateConsistency = optionManager.getOption(ReflectionOptions.VAILDATE_CONSISTENCY);
        this.isDefaultRawReflectionEnabled = optionManager.getOption(ReflectionOptions.ACCELERATION_ENABLE_DEFAULT_RAW);
    }
    
    public void setObserver(final AttemptObserver observer) {
        this.observer = observer;
    }
    
    public SubstitutionProvider.SubstitutionStream findSubstitutions(final RelNode query) {
        final Stopwatch normalizeStopwatch = Stopwatch.createUnstarted();
        try {
            final Stopwatch stopwatch = Stopwatch.createStarted();
            final RelNode origRoot = query.accept((RelShuttle)new OriginalSubsetRemover());
            this.tracer.log("Starting matching for query", origRoot);
            final List<DremioMaterialization> materializations = this.eliminateUsedDefaultRawMaterializations(origRoot, eliminateExtraStarflakeTables(query, SubstitutionUtils.findApplicableMaterializations(origRoot, (Collection)this.getMaterializations()))).stream().map((Function<? super Object, ?>)DremioMaterialization::uniqify).collect((Collector<? super Object, ?, List<DremioMaterialization>>)Collectors.toList());
            this.tracer.log("Found %d candidate materializations for query.", materializations.size());
            if (this.observer != null) {
                this.observer.planFindMaterializations(stopwatch.elapsed(TimeUnit.MILLISECONDS));
            }
            if (materializations.size() == 0) {
                this.tracer.log("No candidate materializations for query found. Total materializations considered: %d.", materializations.size());
                return SubstitutionProvider.SubstitutionStream.empty();
            }
            stopwatch.stop().reset();
            Stream<QueryCandidatePair> candidates = Stream.empty();
            final StrippingFactory factory = new StrippingFactory(this.optionManager, this.config);
            final List<DremioMaterialization> strippedMaterializations = new ArrayList<DremioMaterialization>();
            final List<DremioMaterialization> unexpandedMaterializations = new ArrayList<DremioMaterialization>();
            boolean requiresExtraNormalization = false;
            for (final DremioMaterialization i : materializations) {
                try {
                    if (i.isAlreadyStripped()) {
                        DremioSubstitutionProvider.logger.debug("Materialization {}.{} already stripped", (Object)i.getReflectionId(), (Object)i.getMaterializationId());
                        final DremioMaterialization materialization = i.cloneWithNewQuery(this.normalizeTarget(i.getReflectionType(), i.getQueryRel(), normalizeStopwatch));
                        strippedMaterializations.add(materialization);
                        if (!materialization.hasJoin() && !materialization.hasAgg()) {
                            continue;
                        }
                        requiresExtraNormalization = true;
                    }
                    else {
                        final RelNode appendedTable = this.getAppendedTableRel(i, factory, strippedMaterializations, normalizeStopwatch, true);
                        final DremioMaterialization materialization2 = i.cloneWithNewTableAndQuery(appendedTable, i.getQueryRel());
                        unexpandedMaterializations.add(materialization2);
                        if (!materialization2.hasJoin() && !materialization2.hasAgg()) {
                            continue;
                        }
                        requiresExtraNormalization = true;
                    }
                }
                catch (Throwable t) {
                    this.collectSubstitutionErrors(t);
                }
            }
            DremioSubstitutionProvider.logger.debug("{} unexpanded materializations", (Object)unexpandedMaterializations.size());
            final List<RelNode> normalizedQueries = new ArrayList<RelNode>();
            final Set<RelNode> matchedExpansions = new HashSet<RelNode>();
            if (this.optionManager.getOption(ReflectionOptions.EXPANSION_MATCH)) {
                candidates = Stream.concat((Stream<? extends QueryCandidatePair>)candidates, (Stream<? extends QueryCandidatePair>)this.findExpansionReplacements(origRoot, unexpandedMaterializations, normalizedQueries, normalizeStopwatch, matchedExpansions, requiresExtraNormalization));
            }
            if (this.optionManager.getOption(ReflectionOptions.ALGEBRAIC_MATCH)) {
                final boolean isReduced = this.optionManager.getOption(ReflectionOptions.SIMPLIFIED_MATCH) && this.optionManager.getOption(ReflectionOptions.EXPANSION_MATCH);
                if (isReduced) {
                    final List<QueryCandidatePair> candidateList = candidates.collect((Collector<? super QueryCandidatePair, ?, List<QueryCandidatePair>>)Collectors.toList());
                    final Set<NamespaceKey> matchedExpansionKeys = matchedExpansions.stream().map(e -> e.getPath()).collect((Collector<? super Object, ?, Set<NamespaceKey>>)Collectors.toSet());
                    if (this.foundMatchForAllMaterializations(unexpandedMaterializations, matchedExpansionKeys)) {
                        candidates = candidateList.stream();
                    }
                    else {
                        final List<RelNode> expandedAndNormalized = this.normalizeQuery(ExpansionLeafNode.terminateOrRemovePaths(origRoot, matchedExpansionKeys), normalizeStopwatch, true, requiresExtraNormalization, true);
                        normalizedQueries.addAll(expandedAndNormalized);
                        candidates = Stream.concat(candidateList.stream(), (Stream<? extends QueryCandidatePair>)this.findBupReplacements(strippedMaterializations, expandedAndNormalized.stream(), normalizeStopwatch));
                    }
                }
                else {
                    final List<RelNode> expandedAndNormalized2 = this.normalizeQuery(ExpansionNode.removeFromTree(origRoot), normalizeStopwatch, true, requiresExtraNormalization, true);
                    normalizedQueries.addAll(expandedAndNormalized2);
                    candidates = Stream.concat((Stream<? extends QueryCandidatePair>)candidates, (Stream<? extends QueryCandidatePair>)this.findBupReplacements(strippedMaterializations, expandedAndNormalized2.stream(), normalizeStopwatch));
                }
            }
            else {
                candidates = Stream.concat((Stream<? extends QueryCandidatePair>)candidates, (Stream<? extends QueryCandidatePair>)this.findPdsReplacements(origRoot, unexpandedMaterializations, normalizeStopwatch));
            }
            candidates = candidates.peek(c -> c.getCandidate().getUsedMaterializations().forEach(m -> this.observer.planSubstituted(m, (List)ImmutableList.of((Object)c.getCandidate().getReplacementPlan()), m.getQueryRel(), 0L, false)));
            final Stream<DremioMaterialization> combinedMaterializations = Stream.concat(strippedMaterializations.stream(), unexpandedMaterializations.stream());
            this.reportMaterializations(combinedMaterializations);
            final Stream<SubstitutionProvider.Substitution> substitutions = this.generateSubtreeMatches(candidates, normalizeStopwatch);
            return this.getSubstitutionStream(substitutions, normalizeStopwatch, normalizedQueries);
        }
        catch (Throwable t2) {
            this.collectSubstitutionErrors(t2);
            return this.getSubstitutionStream(Stream.empty(), normalizeStopwatch, new ArrayList<RelNode>());
        }
    }
    
    private List<DremioMaterialization> eliminateUsedDefaultRawMaterializations(final RelNode origRoot, final List<DremioMaterialization> materializations) {
        if (this.isDefaultRawReflectionEnabled()) {
            final Set<String> usedReflectionIds = new HashSet<String>();
            final Pointer<Boolean> foundDefault = (Pointer<Boolean>)new Pointer((Object)false);
            origRoot.accept((RelShuttle)new RoutingShuttle() {
                public RelNode visit(final TableScan scan) {
                    if ((boolean)foundDefault.value && scan.getTable().getQualifiedName().get(0).equals("__accelerator")) {
                        foundDefault.value = false;
                        usedReflectionIds.add(scan.getTable().getQualifiedName().get(1));
                    }
                    return (RelNode)scan;
                }
                
                public RelNode visit(final RelNode other) {
                    if (other instanceof ExpansionNode) {
                        final ExpansionNode expansionNode = (ExpansionNode)other;
                        if (expansionNode.isDefault()) {
                            foundDefault.value = true;
                        }
                    }
                    return super.visit(other);
                }
            });
            return materializations.stream().filter(m -> !usedReflectionIds.contains(m.getLayoutInfo().getReflectionId())).collect((Collector<? super Object, ?, List<DremioMaterialization>>)Collectors.toList());
        }
        return materializations;
    }
    
    private RelNode getAppendedTableRel(final DremioMaterialization m, final StrippingFactory factory, final List<DremioMaterialization> strippedMaterializations, final Stopwatch normalizeStopwatch, final boolean canAddSample) {
        final StrippingFactory.StripResult result = factory.strip(m.getQueryRel(), m.getReflectionType(), m.getIncrementalUpdateSettings().isIncremental()).transformNormalized(m.getPostStripTransformer());
        DremioSubstitutionProvider.logger.debug("Reflection {}.{}\nNormalized:\n{}\nstripped", new Object[] { m.getReflectionId(), m.getMaterializationId(), RelOptUtil.toString(result.getNormalized()) });
        final RelNode strippedTarget = this.normalizeTarget(m.getReflectionType(), result.getNormalized(), normalizeStopwatch);
        DremioSubstitutionProvider.logger.debug("Stripped target:\n{}", (Object)RelOptUtil.toString(strippedTarget));
        if (strippedMaterializations != null) {
            strippedMaterializations.add(m.cloneWithNewQuery(strippedTarget));
        }
        final boolean enableLeafLimits = this.optionManager.getOption(PlannerSettings.ENABLE_LEAF_LIMITS);
        final RelNode tableWithLeafLimitIfNecessary = (enableLeafLimits && canAddSample) ? m.getTableRel().accept((RelShuttle)new InjectSample(true)) : m.getTableRel();
        DremioSubstitutionProvider.logger.debug("RelNode - tableWithLeafLimitIfNecessary:\n{}", (Object)RelOptUtil.toString(tableWithLeafLimitIfNecessary));
        final RelNode appendedTable = result.applyStrippedNodes(ReflectionUtils.removeUpdateColumn(tableWithLeafLimitIfNecessary));
        DremioSubstitutionProvider.logger.debug("RelNode - appendedTable:\n{}", (Object)RelOptUtil.toString(appendedTable));
        return appendedTable;
    }
    
    private void collectSubstitutionErrors(final Throwable t) {
        Throwables.throwIfInstanceOf(t, (Class)PlanningTerminator.PlanningTerminationException.class);
        DremioSubstitutionProvider.logger.debug("Error during substitutions: ", t);
        this.collector.addError((Exception)UserException.planError(t).message("General failure during substitutions: " + t.getLocalizedMessage(), new Object[0]).build(DremioSubstitutionProvider.logger));
    }
    
    private boolean foundMatchForAllMaterializations(final List<DremioMaterialization> unexpandedMaterializations, final Set<NamespaceKey> matchedExpansionKeys) {
        for (final DremioMaterialization m : unexpandedMaterializations) {
            final ExpansionLeafNode.TerminationResult result = ExpansionLeafNode.terminateFirst(m.getQueryRel());
            if (result.getTerminationCount() != 1L) {
                return false;
            }
            if (!matchedExpansionKeys.contains(result.getFirstPath())) {
                return false;
            }
        }
        return true;
    }
    
    private SubstitutionProvider.SubstitutionStream getSubstitutionStream(final Stream<SubstitutionProvider.Substitution> substitutions, final Stopwatch normalizeStopwatch, final List<RelNode> normalizedQueries) {
        return new SubstitutionProvider.SubstitutionStream((Stream)substitutions, () -> {
            if (this.observer != null) {
                this.observer.planNormalized(normalizeStopwatch.elapsed(TimeUnit.MILLISECONDS), (List)normalizedQueries);
                if (this.collector.hasErrors()) {
                    this.observer.substitutionFailures((Iterable)this.collector.getErrors());
                }
                this.collector.clear();
            }
        }, t -> {
            DremioSubstitutionProvider.logger.debug("Caught error: ", (Throwable)t);
            if (t instanceof PlanningTerminator.PlanningTerminationException) {
                this.collector.addError(t);
            }
            else {
                this.collector.addError((Exception)UserException.planError((Throwable)t).message("General failure during substitutions", new Object[0]).build(DremioSubstitutionProvider.logger));
            }
            if (this.observer != null) {
                this.observer.planNormalized(normalizeStopwatch.elapsed(TimeUnit.MILLISECONDS), (List)normalizedQueries);
                if (this.collector.hasErrors()) {
                    this.observer.substitutionFailures((Iterable)this.collector.getErrors());
                }
                this.collector.clear();
            }
        });
    }
    
    private static List<DremioMaterialization> eliminateExtraStarflakeTables(final RelNode userQuery, final Collection<DremioMaterialization> initialMaterializations) {
        DremioSubstitutionProvider.logger.debug("Eliminate extra starflake tables");
        final List<DremioMaterialization> targets = (List<DremioMaterialization>)Lists.newArrayList();
        for (final DremioMaterialization materialization : initialMaterializations) {
            DremioMaterialization snowflakeMaterialization;
            try {
                snowflakeMaterialization = SnowflakeUtilities.generateShadowReflection(userQuery, materialization);
            }
            catch (Exception | AssertionError ex) {
                final Throwable t;
                final Throwable e = t;
                DremioSubstitutionProvider.logger.debug("Failed to generate shadow reflection from materialization, {}.\nReflection id: {}, Layout name: {}, Expiration: {}, \nQuery Plan:\n {}", new Object[] { materialization.getMaterializationId(), materialization.getReflectionId(), materialization.getLayoutInfo().getName(), ISODateTimeFormat.basicDateTime().print(materialization.getExpirationTimestamp()), RelOptUtil.toString(materialization.getQueryRel()), e });
                snowflakeMaterialization = materialization;
            }
            targets.add(snowflakeMaterialization);
        }
        Preconditions.checkState(targets.size() == initialMaterializations.size());
        return targets;
    }
    
    private final Stream<QueryCandidatePair> findPdsReplacements(final RelNode query, final List<DremioMaterialization> materializations, final Stopwatch normalizeStopwatch) {
        DremioSubstitutionProvider.logger.debug("Finding pds replacements");
        final ExpansionLeafNode.TerminationResult result;
        final List<DremioMaterialization> newMaterializationList = materializations.stream().filter(m -> {
            result = ExpansionLeafNode.terminateFirst(m.getQueryRel());
            return result.getTerminationCount() == 0L;
        }).map(m -> m.cloneWithNewQuery(this.normalizeTarget(m.getReflectionType(), m.getQueryRel(), normalizeStopwatch))).collect((Collector<? super Object, ?, List<DremioMaterialization>>)Collectors.toList());
        DremioSubstitutionProvider.logger.debug("New materialization list size: {}", (Object)newMaterializationList.size());
        if (newMaterializationList.isEmpty()) {
            return Stream.empty();
        }
        final Stream<RelNode> normalizedQueries = this.normalizeQuery(query, normalizeStopwatch, true, false, false).stream().map((Function<? super Object, ? extends RelNode>)ExpansionNode::removeFromTree);
        return this.findBupReplacements(newMaterializationList, normalizedQueries, normalizeStopwatch);
    }
    
    private final Stream<QueryCandidatePair> findExpansionReplacements(final RelNode query, final List<DremioMaterialization> materializations, final List<RelNode> normalizedQueriesList, final Stopwatch normalizeStopwatch, final Set<RelNode> matchedExpansions, final boolean requiresExtraNormalization) {
        DremioSubstitutionProvider.logger.debug("Finding expansion replacements for {} materializations", (Object)materializations.size());
        final Set<NamespaceKey> referencedExpansions = (Set<NamespaceKey>)ExpansionNode.findNodes(query, t -> true).stream().map(ExpansionNode::getPath).collect(Collectors.toSet());
        DremioSubstitutionProvider.logger.debug("Found {} expansion nodes", (Object)referencedExpansions.size());
        DremioSubstitutionProvider.logger.debug("Referenced expansions: {}", (Object)referencedExpansions);
        if (referencedExpansions.isEmpty()) {
            return Stream.empty();
        }
        final ListMultimap<NamespaceKey, DremioMaterialization> materializationMap = (ListMultimap<NamespaceKey, DremioMaterialization>)ArrayListMultimap.create();
        for (final DremioMaterialization m : materializations) {
            try {
                for (int depth = 0; depth < 2; ++depth) {
                    final ExpansionLeafNode.TerminationResult result = ExpansionLeafNode.terminateFirst(m.getQueryRel(), depth);
                    if (result.getTerminationCount() != 1L) {
                        break;
                    }
                    final NamespaceKey key = result.getFirstPath();
                    if (referencedExpansions.contains(key)) {
                        materializationMap.put((Object)key, (Object)m.cloneWithNewQuery(this.normalizeTarget(m.getReflectionType(), result.getResult(), normalizeStopwatch)));
                        break;
                    }
                }
            }
            catch (RuntimeException | AssertionError ex) {
                final Throwable t;
                final Throwable e = t;
                this.collectError("Failure during substitution. Materialization Impacted: %s", e, (List<DremioMaterialization>)ImmutableList.of((Object)m));
            }
        }
        if (this.optionManager.getOption(ReflectionOptions.SIMPLIFIED_MATCH)) {
            return this.simplifiedExpansionReplacements(query, materializationMap, normalizedQueriesList, normalizeStopwatch, matchedExpansions, requiresExtraNormalization);
        }
        final List<DremioMaterialization> matchingExpansions;
        RelNode terminatedQuery;
        Stream<RelNode> normalizedAndTerminated;
        final Throwable t2;
        Throwable e2;
        return referencedExpansions.stream().flatMap(k -> {
            matchingExpansions = (List<DremioMaterialization>)materializationMap.get((Object)k);
            if (matchingExpansions == null || matchingExpansions.isEmpty()) {
                DremioSubstitutionProvider.logger.debug("Matching expansions {}", (Object)((matchingExpansions == null) ? "null" : "empty"));
                return Stream.empty();
            }
            else {
                DremioSubstitutionProvider.logger.debug("{} matching expansions for {}", (Object)matchingExpansions.size(), (Object)k);
                try {
                    terminatedQuery = ExpansionNode.removeParentExpansionNodes(k, query);
                    normalizedAndTerminated = this.normalizeQuery(terminatedQuery, normalizeStopwatch, false, requiresExtraNormalization, false).stream().map(q -> ExpansionLeafNode.terminateIf(k, q)).map(q -> {
                        normalizedQueriesList.add(q);
                        return q;
                    });
                    return this.findBupReplacements(matchingExpansions, normalizedAndTerminated, normalizeStopwatch);
                }
                catch (Exception | AssertionError ex2) {
                    e2 = t2;
                    this.collectError("Failure during substitution. Materialization Impacted: %s", e2, matchingExpansions);
                    return Stream.empty();
                }
            }
        });
    }
    
    private Stream<QueryCandidatePair> simplifiedExpansionReplacements(final RelNode query, final ListMultimap<NamespaceKey, DremioMaterialization> materializationMap, final List<RelNode> normalizedQueries, final Stopwatch normalizeStopwatch, final Set<RelNode> matchedExpansions, final boolean requiresExtraNormalization) {
        return this.simplifiedExpansionReplacementsRecursive(query, Stream.of(query), materializationMap, normalizedQueries, normalizeStopwatch, matchedExpansions, requiresExtraNormalization);
    }
    
    private Stream<QueryCandidatePair> simplifiedExpansionReplacementsRecursive(final RelNode origQuery, final Stream<RelNode> subQueries, final ListMultimap<NamespaceKey, DremioMaterialization> materializationMap, final List<RelNode> normalizedQueriesList, final Stopwatch normalizeStopwatch, final Set<RelNode> matchedExpansions, final boolean normalizationRules) {
        final ExpansionFinder finder = new ExpansionFinder(materializationMap.keySet());
        final Set<RelNode> topExpansions = new HashSet<RelNode>();
        final Map<RelNode, RelNode> leafToOriginalMap = new HashMap<RelNode, RelNode>();
        final Set<NamespaceKey> topLevelPaths = new HashSet<NamespaceKey>();
        final List<ExpansionLeafNode> remaining = new ArrayList<ExpansionLeafNode>();
        final List<DremioMaterialization> materializations = new ArrayList<DremioMaterialization>();
        final ExpansionFinder expansionFinder;
        final Set set;
        final Set set2;
        subQueries.forEach(query -> {
            expansionFinder.explore(query);
            set.addAll(expansionFinder.getTopExpansionNodes());
            set2.addAll(expansionFinder.getTopPaths());
            return;
        });
        if (topLevelPaths.size() == 0) {
            return Stream.empty();
        }
        topLevelPaths.forEach(p -> materializations.addAll(materializationMap.get((Object)p)));
        if (materializations.size() == 0) {
            return Stream.empty();
        }
        final List<DremioMaterialization> list;
        final Collection<Object> collection;
        final ExpansionFinder expansionFinder2;
        NamespaceKey pathFilter;
        final Map<RelNode, RelNode> leafToOriginalMap2;
        final List<ExpansionLeafNode> remaining2;
        List<RelNode> normalizedAndTerminated;
        final List<ExpansionLeafNode> remaining3;
        final RelNode node;
        return Stream.of((Supplier[])new Supplier[] { () -> {
                try {
                    return this.findBupReplacements(list, collection.stream().flatMap(e -> {
                        pathFilter = expansionFinder2.getNodeToPath(e);
                        normalizedAndTerminated = this.normalizeQuery(origQuery, normalizeStopwatch, 0 != 0, normalizationRules, 0 != 0).stream().map(query -> this.terminate(pathFilter, query, leafToOriginalMap2, remaining2, matchedExpansions)).collect((Collector<? super Object, ?, List<RelNode>>)Collectors.toList());
                        normalizedQueriesList.addAll(normalizedAndTerminated);
                        return normalizedAndTerminated.stream();
                    }), normalizeStopwatch, remaining3);
                }
                catch (RuntimeException e2) {
                    this.collectError("Failure during substitution. Materialization Impacted: %s", e2, list);
                    return Stream.empty();
                }
            }, () -> this.simplifiedExpansionReplacementsRecursive(origQuery, remaining.stream().map(r -> {
                node = leafToOriginalMap.get(r);
                matchedExpansions.remove(node);
                return node.getInput(0);
            }), materializationMap, normalizedQueriesList, normalizeStopwatch, matchedExpansions, normalizationRules) }).flatMap((Function<? super Supplier, ? extends Stream<? extends QueryCandidatePair>>)Supplier::get);
    }
    
    private RelNode terminate(final NamespaceKey pathFilter, final RelNode node, final Map<RelNode, RelNode> leafToOriginalMap, final List<ExpansionLeafNode> remaining, final Set<RelNode> matchedExpansions) {
        return node.accept((RelShuttle)new StatelessRelShuttleImpl() {
            public RelNode visit(final RelNode other) {
                if (!(other instanceof ExpansionNode)) {
                    return super.visit(other);
                }
                final ExpansionNode en = (ExpansionNode)other;
                if (en.getPath().equals((Object)pathFilter)) {
                    final ExpansionLeafNode eln = new ExpansionLeafNode(en.getPath(), node.getCluster(), node.getTraitSet(), en.getRowType(), en.getInput(), en.isDefault());
                    leafToOriginalMap.put(eln, other);
                    remaining.add(eln);
                    matchedExpansions.add(other);
                    return (RelNode)eln;
                }
                final ExpansionNode currentEN = (ExpansionNode)this.visitChild(other, 0, en.getInput());
                if (currentEN == en) {
                    return (RelNode)en;
                }
                return currentEN.getInput();
            }
        });
    }
    
    public RelNode wrapExpansionNode(final NamespaceKey path, final RelNode query, final List<String> vdsFields, final RelDataType rowType, final boolean contextSensitive) {
        if (this.isDefaultRawReflectionEnabled() && !path.getSchemaPath().startsWith("sys.")) {
            try {
                final Optional<DremioMaterialization> defaultMaterialization = (Optional<DremioMaterialization>)this.getDefaultRawMaterialization(path, (List)vdsFields);
                if (defaultMaterialization.isPresent()) {
                    final DremioMaterialization m = defaultMaterialization.get();
                    final Stopwatch normalizeStopwatch = Stopwatch.createUnstarted();
                    final StrippingFactory factory = new StrippingFactory(this.optionManager, this.config);
                    final RelNode appendedTable = this.getAppendedTableRel(m, factory, null, normalizeStopwatch, false);
                    final RelNode projectedTable = this.addTopProject(query, appendedTable, factory.strip(query, m.getReflectionType(), m.getIncrementalUpdateSettings().isIncremental()).getNormalized());
                    final RelNode replacement = processPostSubstitution(projectedTable, normalizeStopwatch);
                    final RelNode trimmedReplacement = PrelTransformer.trimFields(replacement, false, false);
                    final RelNode transformedReplacement = this.postSubstitutionTransformer.transform(trimmedReplacement);
                    this.observer.planSubstituted((DremioMaterialization)defaultMaterialization.get(), (List)ImmutableList.of((Object)transformedReplacement), m.getQueryRel(), 0L, true);
                    return ExpansionNode.wrap(path, transformedReplacement, rowType, contextSensitive, true);
                }
            }
            catch (Throwable t) {
                final String message = "Caught exception during default reflection substitution for " + path.toString();
                DremioSubstitutionProvider.logger.debug(message, t);
                this.tracer.log(message, t);
                this.collector.addError((Exception)UserException.planError(t).message(message, new Object[0]).build(DremioSubstitutionProvider.logger));
            }
        }
        return ExpansionNode.wrap(path, query, rowType, contextSensitive, false);
    }
    
    private RelNode addTopProject(final RelNode originalQueryRel, final RelNode materializationTableRel, final RelNode normalizedOriginalQueryRel) {
        if (InvalidViewRel.equalsRowTypeDeep(originalQueryRel.getRowType(), materializationTableRel.getRowType()) || InvalidViewRel.equalsRowTypeDeep(normalizedOriginalQueryRel.getRowType(), materializationTableRel.getRowType())) {
            return materializationTableRel;
        }
        final List<RexNode> projects = new ArrayList<RexNode>();
        final List<String> unknownFields = new ArrayList<String>();
        for (final RelDataTypeField queryField : originalQueryRel.getRowType().getFieldList()) {
            final RelDataTypeField targetField = materializationTableRel.getRowType().getField(queryField.getName(), false, false);
            if (targetField != null) {
                projects.add((RexNode)new RexInputRef(targetField.getIndex(), targetField.getType()));
            }
            else {
                unknownFields.add(queryField.getName());
            }
        }
        if (!unknownFields.isEmpty()) {
            throw new RuntimeException(String.format("Cannot apply top project during default reflection substitution. Unable to resolve the following fields: %s", unknownFields));
        }
        return (RelNode)LogicalRels.createProject(originalQueryRel.getRowType(), materializationTableRel, projects);
    }
    
    public boolean isDefaultRawReflectionEnabled() {
        return this.isDefaultRawReflectionEnabled;
    }
    
    public void disableDefaultRawReflection() {
        this.isDefaultRawReflectionEnabled = false;
    }
    
    public void resetDefaultRawReflection() {
        this.isDefaultRawReflectionEnabled = this.optionManager.getOption(ReflectionOptions.ACCELERATION_ENABLE_DEFAULT_RAW);
    }
    
    private void reportMaterializations(final Stream<DremioMaterialization> targets) {
        DremioSubstitutionProvider.logger.debug("Reporting materializations");
        if (this.observer != null) {
            targets.map((Function<? super DremioMaterialization, ?>)DremioMaterialization::getOriginal).distinct().forEach(m -> {
                DremioSubstitutionProvider.logger.debug("Reporting materialization: {}.{}", (Object)m.getReflectionId(), (Object)m.getMaterializationId());
                this.observer.planSubstituted(m, (List)ImmutableList.of(), m.getQueryRel(), 0L, false);
            });
        }
    }
    
    private Stream<SubstitutionProvider.Substitution> generateSubtreeMatches(final Stream<QueryCandidatePair> unprocessedCandidates, final Stopwatch normalizeStopwatch) {
        DremioSubstitutionProvider.logger.debug("Prepare stream to generateSubtreeMatches method");
        final Set<Integer> completed = new HashSet<Integer>();
        final Throwable t;
        Throwable e;
        final Stream.Builder<SubstitutionProvider.Substitution> builder;
        final RelNode query;
        final int code;
        final Set<Integer> set;
        return unprocessedCandidates.map(qcp -> {
            try {
                return qcp.cleanse(normalizeStopwatch);
            }
            catch (Exception | AssertionError ex) {
                e = t;
                this.collectError("Failure during post-substitution processing. Used reflections: %s", e, qcp.getCandidate().getUsedMaterializations());
                this.tracer.addError((Exception)UserException.planError().message("Failure during post-substitution processing", new Object[0]).build(DremioSubstitutionProvider.logger));
                return null;
            }
        }).filter(Objects::nonNull).flatMap(qcp -> {
            builder = Stream.builder();
            query = qcp.getUserQuery();
            code = SubstitutionUtils.hash(query);
            if (set.add(code)) {
                builder.add(SubstitutionProvider.Substitution.createRootEquivalent(query));
            }
            builder.add(this.createSubstitution(qcp));
            return builder.build();
        }).filter(Objects::nonNull);
    }
    
    private SubstitutionProvider.Substitution createSubstitution(final QueryCandidatePair pair) {
        try {
            final RelNode cleansedCandidateQuery = pair.getUserQuery();
            final RelNode cleansedCandidateRoot = pair.getCandidate().getRoot();
            final RelNode cleansedReplacement = pair.getCandidate().getReplacement();
            if (this.validateConsistency) {
                pair.validateConsistency();
            }
            final RelNode trimmedReplacement = PrelTransformer.trimFields(cleansedReplacement, false, false);
            final RelNode transformedReplacement = this.postSubstitutionTransformer.transform(trimmedReplacement);
            final Iterable<Integer> pathToReplacement = (Iterable<Integer>)MoreRelOptUtil.findPathToNode(cleansedCandidateRoot, (Predicate)DremioSubstitutionProvider.REPLACEMENT_NODE);
            final RelNode equivalentNode = MoreRelOptUtil.findNodeAtPath(cleansedCandidateQuery, (Iterable)pathToReplacement);
            return new SubstitutionProvider.Substitution(transformedReplacement, equivalentNode);
        }
        catch (Exception e) {
            this.collectError("Failure during post-substitution processing. Used reflections: %s", e, pair.getCandidate().getUsedMaterializations());
            this.tracer.addError((Exception)UserException.planError().message("Failure during post-substitution processing", new Object[0]).build(DremioSubstitutionProvider.logger));
            return null;
        }
    }
    
    private void collectError(final String msg, final Throwable e, final List<DremioMaterialization> materializations) {
        DremioSubstitutionProvider.logger.debug("Error: {}", (Object)msg);
        final List<String> reflections = materializations.stream().map(dremioRelOptMaterialization -> dremioRelOptMaterialization.getLayoutInfo().getReflectionId()).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
        this.collector.addError((Exception)UserException.planError(e).message(String.format(msg, reflections), new Object[0]).build(DremioSubstitutionProvider.logger));
    }
    
    private Stream<QueryCandidatePair> findBupReplacements(final List<DremioMaterialization> targets, final Stream<RelNode> normalizedQueries, final Stopwatch normalizeStopwatch) {
        final List<ExpansionLeafNode> remaining = new ArrayList<ExpansionLeafNode>();
        return this.findBupReplacements(targets, normalizedQueries, normalizeStopwatch, remaining);
    }
    
    private Stream<QueryCandidatePair> findBupReplacements(final List<DremioMaterialization> targets, final Stream<RelNode> normalizedQueries, final Stopwatch normalizeStopwatch, final List<ExpansionLeafNode> remaining) {
        DremioSubstitutionProvider.logger.debug("Finding bup replacements");
        RelNode processedQuery;
        BupFinder bf;
        final Throwable t;
        Throwable e;
        return normalizedQueries.flatMap(query -> {
            try {
                processedQuery = ExpansionNode.removeFromTree(processPostSubstitution(query, normalizeStopwatch));
                this.tracer.log("Initial user query variation", query);
                DremioSubstitutionProvider.logger.debug("Initial user query variation:\n{}", (Object)RelOptUtil.toString(query));
                DremioSubstitutionProvider.logger.debug("Processed query variation:\n{}", (Object)RelOptUtil.toString(processedQuery));
                bf = new BupFinder(this.planningTerminator, this.tracer, query.getCluster(), query, targets, (com.google.common.base.Predicate<RelNode>)DremioSubstitutionProvider::isValidResult, remaining);
                return bf.generateAlternatives().map(c -> new QueryCandidatePair(query, processedQuery, c));
            }
            catch (RuntimeException | AssertionError ex) {
                e = t;
                this.collectError("Failure finding replacement for materializations %s", e, targets);
                return Stream.empty();
            }
        });
    }
    
    private RelNode normalizeTarget(final UserBitShared.ReflectionType type, final RelNode queryRel, final Stopwatch normalizeStopwatch) {
        normalizeStopwatch.start();
        try {
            RelNode targetRel = ExpansionNode.removeFromTree(queryRel);
            if (this.optionManager.getOption(ReflectionOptions.ACCELERATION_ENABLE_MULTIJOIN)) {
                targetRel = ChainedNormalizer.of(new Normalizer[] { Normalizers.JOIN_FILTER, Normalizers.PROJECT_MERGE_NORMALIZER, Normalizers.MULTIJOIN_NORMALIZER, Normalizers.MULTIJOIN_EXTRA_PROJECT }).normalize(targetRel);
            }
            Normalizer viewNormalizer;
            if (type == UserBitShared.ReflectionType.EXTERNAL) {
                viewNormalizer = Normalizers.EXTERNAL_NORMALIZER;
            }
            else {
                viewNormalizer = Normalizers.RAW_VIEW_NORMALIZER;
            }
            return viewNormalizer.normalize(targetRel);
        }
        finally {
            normalizeStopwatch.stop();
        }
    }
    
    private Optional<RelNode> normalizeDistinctAgg(final RelNode query) {
        final DistinctFinder queryDistinctFinder = new DistinctFinder();
        query.accept((RelShuttle)queryDistinctFinder);
        if (queryDistinctFinder.isFoundDistinct()) {
            return this.normalizeAndCollectError(Normalizers.DISTINCT_AGG_NORMALIZER, query);
        }
        return Optional.of(query);
    }
    
    private List<RelNode> normalizeQuery(final RelNode incoming, final Stopwatch stopwatch, final boolean trimFields, final boolean extraNormalization, final boolean ensureTopProject) {
        stopwatch.start();
        final int flattenCount = FlattenVisitors.FlattenCounter.countFlattensInPlan(incoming);
        try {
            RelNode query = incoming;
            RelNode correlatedQuery = null;
            final List<RelNode> queryRelsToSubstitute = new ArrayList<RelNode>();
            if (this.optionManager.getOption(PlannerSettings.RELATIONAL_PLANNING)) {
                final CorrelateFinder correlateFinder = new CorrelateFinder();
                incoming.accept((RelShuttle)correlateFinder);
                if (correlateFinder.isFoundCorrelate()) {
                    correlatedQuery = incoming;
                    query = DremioRelDecorrelator.decorrelateQuery(incoming, DremioRelFactories.CALCITE_LOGICAL_BUILDER.create(incoming.getCluster(), (RelOptSchema)null), false, false);
                }
            }
            if (correlatedQuery != null) {
                final Optional<RelNode> normalizedCorrelatedQuery = this.normalizeDistinctAgg(correlatedQuery);
                if (normalizedCorrelatedQuery.isPresent()) {
                    queryRelsToSubstitute.add(normalizedCorrelatedQuery.get());
                    final RelNode trimmed = PrelTransformer.trimFields((RelNode)normalizedCorrelatedQuery.get(), false, false);
                    queryRelsToSubstitute.add(trimmed);
                }
            }
            final Optional<RelNode> normalizedUncorrelated = this.normalizeDistinctAgg(query);
            if (normalizedUncorrelated.isPresent()) {
                query = normalizedUncorrelated.get();
            }
            final JoinFinder joinFinder = new JoinFinder();
            query.accept((RelShuttle)joinFinder);
            if (extraNormalization && this.optionManager.getOption(ReflectionOptions.ACCELERATION_ENABLE_MULTIJOIN)) {
                final Optional<RelNode> newQuery = this.normalizeAndCollectError((Normalizer)ChainedNormalizer.of(new Normalizer[] { Normalizers.JOIN_FILTER, Normalizers.PROJECT_MERGE_NORMALIZER, Normalizers.MULTIJOIN_NORMALIZER }), query);
                if (newQuery.isPresent()) {
                    final Optional<RelNode> q1 = this.normalizeAndCollectError((Normalizer)ChainedNormalizer.of(new Normalizer[] { Normalizers.MULTIJOIN_EXTRA_PROJECT }), newQuery.get());
                    if (q1.isPresent()) {
                        queryRelsToSubstitute.add(q1.get());
                        if (this.optionManager.getOption(ReflectionOptions.TRIM_USER_QUERY)) {
                            final RelNode trimmed2 = PrelTransformer.trimFields((RelNode)q1.get(), false, false);
                            queryRelsToSubstitute.add(trimmed2);
                        }
                    }
                    if (this.optionManager.getOption(ReflectionOptions.ACCELERATION_ENABLE_AGG_JOIN)) {
                        final Optional<RelNode> newQueryAggJoin = this.normalizeAndCollectError((Normalizer)ChainedNormalizer.of(new Normalizer[] { Normalizers.MULTIJOIN_TO_JOIN_NORMALIZER, Normalizers.PROJECT_MERGE_NORMALIZER }), newQuery.get());
                        if (newQueryAggJoin.isPresent()) {
                            final Optional<RelNode> normalizeAndCollectError;
                            final Optional<RelNode> newQueryAggJoin2 = normalizeAndCollectError = this.normalizeAndCollectError((Normalizer)ChainedNormalizer.of(new Normalizer[] { Normalizers.AGG_JOIN_NORMALIZER, Normalizers.AGG_JOIN_PUSHDOWN }), newQueryAggJoin.get());
                            final List<RelNode> list = queryRelsToSubstitute;
                            Objects.requireNonNull((ArrayList)list);
                            normalizeAndCollectError.ifPresent(list::add);
                        }
                    }
                }
            }
            else {
                queryRelsToSubstitute.add(query);
                if (trimFields) {
                    final RelNode trimmed3 = PrelTransformer.trimFields(query, false, false);
                    queryRelsToSubstitute.add(trimmed3);
                }
            }
            final List<RelNode> normalizedRelsToSubstitute = new ArrayList<RelNode>();
            for (final RelNode queryToNormalize : queryRelsToSubstitute) {
                final Optional<RelNode> normalized = this.normalizeAndCollectError(Normalizers.QUERY_NORMALIZER, queryToNormalize);
                if (normalized.isPresent()) {
                    final int cnt = FlattenVisitors.FlattenCounter.countFlattensInPlan((RelNode)normalized.get());
                    if (cnt != flattenCount) {
                        if (!DremioSubstitutionProvider.logger.isDebugEnabled()) {
                            continue;
                        }
                        final String message = "Normalization did not preserve flatten count. Excluding normalized query:\n" + RelOptUtil.toString((RelNode)normalized.get());
                        this.tracer.log(message);
                        DremioSubstitutionProvider.logger.debug(message);
                    }
                    else {
                        final RelNode normalizedRel = normalized.get();
                        if (ensureTopProject) {
                            normalizedRelsToSubstitute.add(LogicalRels.createIdentityProject(normalizedRel));
                        }
                        else {
                            normalizedRelsToSubstitute.add(normalizedRel);
                        }
                    }
                }
            }
            return normalizedRelsToSubstitute;
        }
        finally {
            stopwatch.stop();
        }
    }
    
    private Optional<RelNode> normalizeAndCollectError(final Normalizer normalizer, final RelNode query) {
        RelNode normalized;
        try {
            normalized = normalizer.normalize(query);
        }
        catch (Exception | AssertionError ex) {
            final Throwable t;
            final Throwable e = t;
            this.collectError("Failure during normalization.", e, (List<DremioMaterialization>)ImmutableList.of());
            return Optional.empty();
        }
        return Optional.of(normalized);
    }
    
    private static RelNode processPostSubstitution(RelNode node, final Stopwatch stopwatch) {
        stopwatch.start();
        try {
            node = ExpansionLeafNode.expand(node);
            node = ChainedNormalizer.of(new Normalizer[] { Normalizers.MULTIJOIN_TO_JOIN_NORMALIZER, Normalizers.PROJECT_MERGE_NORMALIZER }).normalize(node);
            node = ExpansionNode.removeFromTree(node);
            return node;
        }
        finally {
            stopwatch.stop();
        }
    }
    
    private static boolean isValidResult(final RelNode node) {
        final ContainsRelVisitor visitor = new ContainsRelVisitor();
        node.accept((RelShuttle)visitor);
        if (visitor.hasIllegalContains) {
            DremioSubstitutionProvider.logger.debug("Illegal contains:\n{}", (Object)node);
        }
        return !visitor.hasIllegalContains;
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)DremioSubstitutionProvider.class);
        REPLACEMENT_NODE = (input -> input instanceof ReplacementPointer);
    }
    
    private class QueryCandidatePair
    {
        private final RelNode userQuery;
        private final Candidate candidate;
        private final RelNode localUserQuery;
        
        public QueryCandidatePair(final RelNode userQuery, final RelNode localUserQuery, final Candidate candidate) {
            this.userQuery = userQuery;
            this.candidate = candidate;
            this.localUserQuery = localUserQuery;
        }
        
        public RelNode getUserQuery() {
            return this.userQuery;
        }
        
        public Candidate getCandidate() {
            return this.candidate;
        }
        
        public QueryCandidatePair cleanse(final Stopwatch normalizeWatch) {
            final RelNode candidateRoot = processPostSubstitution(this.candidate.getRoot(), normalizeWatch);
            final RelNode replacement = processPostSubstitution(this.candidate.getReplacement(), normalizeWatch);
            return new QueryCandidatePair(this.localUserQuery, this.localUserQuery, new Candidate(candidateRoot, replacement, this.candidate.getUsedMaterializations()));
        }
        
        public void validateConsistency() {
            Preconditions.checkState(SubstitutionUtils.arePlansEqualIgnoringReplacementPointer(this.userQuery, this.candidate.getRoot()), (Object)"Mismatch between cleansed user query plan and candidate plan");
        }
    }
    
    private class OriginalSubsetRemover extends StatelessRelShuttleImpl
    {
        public RelNode visit(final RelNode other) {
            if (other instanceof RelSubset) {
                return ((RelSubset)other).getOriginal().accept((RelShuttle)this);
            }
            return super.visit(other);
        }
    }
    
    private static class ContainsRelVisitor extends StatelessRelShuttleImpl
    {
        private boolean hasIllegalContains;
        
        private ContainsRelVisitor() {
            this.hasIllegalContains = false;
        }
        
        private boolean checkContainsOrigin(final RelNode node, final RexNode rexNode, final int index) {
            try {
                MoreRelOptUtil.ContainsRexVisitor.hasContainsCheckOrigin(node, rexNode, -1);
            }
            catch (UserException e) {
                return true;
            }
            return false;
        }
        
        public RelNode visit(final LogicalFilter filter) {
            if (this.checkContainsOrigin((RelNode)filter, filter.getCondition(), -1)) {
                this.hasIllegalContains = true;
                return (RelNode)filter;
            }
            return super.visit(filter);
        }
        
        public RelNode visit(final LogicalJoin join) {
            if (this.checkContainsOrigin((RelNode)join, join.getCondition(), -1)) {
                this.hasIllegalContains = true;
                return (RelNode)join;
            }
            return this.visitChildren((RelNode)join);
        }
        
        public RelNode visit(final LogicalProject project) {
            int i = 0;
            for (final RexNode expr : project.getChildExps()) {
                if (this.checkContainsOrigin((RelNode)project, expr, i)) {
                    this.hasIllegalContains = true;
                    return (RelNode)project;
                }
                ++i;
            }
            return this.visitChild((RelNode)project, 0, project.getInput());
        }
    }
    
    private class ExpansionFinder extends StatelessRelShuttleImpl
    {
        private final Set<NamespaceKey> referencedPaths;
        private final Pointer<Set<RelNode>> topExpansionNodes;
        private final Pointer<Set<NamespaceKey>> topPaths;
        private final Pointer<Map<RelNode, NamespaceKey>> nodeToPath;
        
        public ExpansionFinder(final Set<NamespaceKey> referencedPaths) {
            this.referencedPaths = referencedPaths;
            this.topExpansionNodes = (Pointer<Set<RelNode>>)new Pointer();
            this.topPaths = (Pointer<Set<NamespaceKey>>)new Pointer();
            this.nodeToPath = (Pointer<Map<RelNode, NamespaceKey>>)new Pointer();
        }
        
        public void explore(final RelNode userQuery) {
            this.topExpansionNodes.value = new HashSet();
            this.topPaths.value = new HashSet();
            this.nodeToPath.value = new HashMap();
            userQuery.accept((RelShuttle)this);
        }
        
        public Set<RelNode> getTopExpansionNodes() {
            return (Set<RelNode>)this.topExpansionNodes.value;
        }
        
        public Set<NamespaceKey> getTopPaths() {
            return (Set<NamespaceKey>)this.topPaths.value;
        }
        
        public NamespaceKey getNodeToPath(final RelNode node) {
            return ((Map)this.nodeToPath.value).get(node);
        }
        
        public RelNode visit(final RelNode other) {
            if (!(other instanceof ExpansionNode)) {
                return super.visit(other);
            }
            final ExpansionNode expansionNode = (ExpansionNode)other;
            final NamespaceKey key = expansionNode.getPath();
            if (this.referencedPaths.contains(key)) {
                ((Set)this.topExpansionNodes.value).add(other);
                ((Set)this.topPaths.value).add(key);
                ((Map)this.nodeToPath.value).put(other, key);
                return other;
            }
            return super.visit(other);
        }
    }
}
