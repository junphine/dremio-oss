package com.dremio.exec.planner.acceleration.substitution;

import com.dremio.service.namespace.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rel.metadata.*;
import org.apache.calcite.plan.*;
import com.dremio.service.*;
import com.dremio.exec.planner.acceleration.*;
import org.apache.calcite.rel.*;
import java.util.*;

public class ExpansionLeafNode extends AbstractRelNode
{
    private final NamespaceKey path;
    private final RelNode subTree;
    private final boolean isDefault;
    
    public ExpansionLeafNode(final NamespaceKey path, final RelOptCluster cluster, final RelTraitSet traitSet, final RelDataType rowType, final RelNode subTree, final boolean isDefault) {
        super(cluster, traitSet);
        this.path = path;
        this.rowType = rowType;
        this.subTree = subTree;
        this.isDefault = isDefault;
    }
    
    public RelNode getSubTree() {
        return this.subTree;
    }
    
    public String getPath() {
        return this.path.getSchemaPath();
    }
    
    public boolean isDefault() {
        return this.isDefault;
    }
    
    public RelWriter explainTerms(final RelWriter pw) {
        return super.explainTerms(pw).item("path", (Object)this.path.toUnescapedString());
    }
    
    public RelOptCost computeSelfCost(final RelOptPlanner planner, final RelMetadataQuery mq) {
        return mq.getCumulativeCost(this.subTree);
    }
    
    public double estimateRowCount(final RelMetadataQuery mq) {
        return this.subTree.estimateRowCount(mq);
    }
    
    public static TerminationResult terminateFirst(final RelNode node) {
        return terminateFirst(node, 0);
    }
    
    public static TerminationResult terminateFirst(final RelNode node, final int depth) {
        final Pointer<Integer> skip = (Pointer<Integer>)new Pointer((Object)depth);
        final Pointer<Long> terminationCount = (Pointer<Long>)new Pointer((Object)0L);
        final Pointer<NamespaceKey> firstPath = (Pointer<NamespaceKey>)new Pointer();
        final RelNode newTree = node.accept((RelShuttle)new RelShuttleImpl() {
            public RelNode visit(final RelNode other) {
                if (!(other instanceof ExpansionNode)) {
                    return super.visit(other);
                }
                if ((int)skip.value > 0) {
                    final Integer n = (Integer)skip.value;
                    skip.value = (int)skip.value - 1;
                    return super.visit(((ExpansionNode)other).getInput());
                }
                final Long n2 = (Long)terminationCount.value;
                terminationCount.value = (long)terminationCount.value + 1L;
                final ExpansionNode e = (ExpansionNode)other;
                if (firstPath.value == null) {
                    firstPath.value = e.getPath();
                }
                return (RelNode)new ExpansionLeafNode(e.getPath(), node.getCluster(), node.getTraitSet(), e.getRowType(), e.getInput(), e.isDefault());
            }
        });
        return new TerminationResult(newTree, (long)terminationCount.value, (NamespaceKey)firstPath.value);
    }
    
    public static RelNode terminateOrRemovePaths(final RelNode tree, final Set<NamespaceKey> matchedExpansionKeys) {
        return tree.accept((RelShuttle)new RelShuttleImpl() {
            public RelNode visit(final RelNode other) {
                if (!(other instanceof ExpansionNode)) {
                    return super.visit(other);
                }
                final ExpansionNode e = (ExpansionNode)other;
                if (matchedExpansionKeys.contains(e.getPath())) {
                    return (RelNode)new ExpansionLeafNode(e.getPath(), tree.getCluster(), tree.getTraitSet(), e.getRowType(), e.getInput(), e.isDefault());
                }
                return ((ExpansionNode)super.visit(other)).getInput();
            }
        });
    }
    
    public static RelNode expand(final RelNode node) {
        return node.accept((RelShuttle)new RelShuttleImpl() {
            public RelNode visit(final RelNode other) {
                if (other instanceof ExpansionLeafNode) {
                    final ExpansionLeafNode leaf = (ExpansionLeafNode)other;
                    return ExpansionNode.wrap(leaf.path, leaf.getSubTree(), leaf.getRowType(), false, leaf.isDefault());
                }
                return super.visit(other);
            }
        });
    }
    
    public static RelNode terminateIf(final NamespaceKey pathFilter, final RelNode node) {
        return node.accept((RelShuttle)new RelShuttleImpl() {
            public RelNode visit(final RelNode other) {
                if (!(other instanceof ExpansionNode)) {
                    return super.visit(other);
                }
                final ExpansionNode e = (ExpansionNode)other;
                if (e.getPath().equals((Object)pathFilter)) {
                    return (RelNode)new ExpansionLeafNode(e.getPath(), node.getCluster(), node.getTraitSet(), other.getRowType(), e.getInput(), e.isDefault());
                }
                final ExpansionNode currentNode = (ExpansionNode)this.visitChild(other, 0, e.getInput());
                if (currentNode == other) {
                    return other;
                }
                return currentNode.getInput();
            }
        });
    }
    
    public static class TerminationResult
    {
        private final RelNode result;
        private final long terminationCount;
        private final NamespaceKey firstPath;
        
        public TerminationResult(final RelNode result, final long terminationCount, final NamespaceKey firstPath) {
            this.result = result;
            this.terminationCount = terminationCount;
            this.firstPath = firstPath;
        }
        
        public RelNode getResult() {
            return this.result;
        }
        
        public long getTerminationCount() {
            return this.terminationCount;
        }
        
        public NamespaceKey getFirstPath() {
            return this.firstPath;
        }
    }
}
