package com.dremio.reflection.rules;

import org.apache.calcite.sql.fun.*;
import java.math.*;
import org.apache.calcite.util.mapping.*;
import org.apache.calcite.util.*;
import org.apache.calcite.sql.type.*;
import org.apache.calcite.rel.core.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rex.*;
import java.util.*;
import org.apache.calcite.sql.*;

public final class AggSplitters
{
    static RexNode handleNull(final RexBuilder rexBuilder, final RexNode input) {
        return rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.CASE, new RexNode[] { rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NULL, new RexNode[] { input }), rexBuilder.makeBigintLiteral(BigDecimal.ONE), input });
    }
    
    public static Splitter getSplitter(final SqlAggFunction aggFunction) {
        switch (aggFunction.getKind()) {
            case COUNT: {
                return CountSplitter.INSTANCE;
            }
            case MAX:
            case MIN: {
                return SelfSplitter.INSTANCE;
            }
            case SUM: {
                return SumSplitter.INSTANCE;
            }
            case SUM0: {
                return Sum0Splitter.INSTANCE;
            }
            default: {
                return null;
            }
        }
    }
    
    public abstract static class Registry<E>
    {
        protected final List<E> list;
        
        public Registry(final List<E> list) {
            this.list = list;
        }
        
        public abstract int register(final E p0);
    }
    
    public static class RexNodeRegistry extends Registry<RexNode>
    {
        public RexNodeRegistry(final List<RexNode> list) {
            super(list);
        }
        
        @Override
        public int register(final RexNode rexNode) {
            int i = this.list.indexOf(rexNode);
            if (i < 0) {
                i = this.list.size();
                this.list.add((E)rexNode);
            }
            return i;
        }
    }
    
    public static class AggregateCallRegistry extends Registry<AggregateCall>
    {
        public AggregateCallRegistry(final List<AggregateCall> list) {
            super(list);
        }
        
        @Override
        public int register(final AggregateCall aggregateCall) {
            int i = ProjectableSqlAggFunctions.indexOfMatchingCall(aggregateCall, (List<AggregateCall>)this.list);
            if (i < 0) {
                i = this.list.size();
                this.list.add((E)aggregateCall);
            }
            return i;
        }
    }
    
    static class CountSplitter implements Splitter
    {
        public static final CountSplitter INSTANCE;
        
        @Override
        public AggregateCall split(final AggregateCall aggregateCall, final Mappings.TargetMapping mapping) {
            return aggregateCall.transform(mapping);
        }
        
        @Override
        public AggregateCall other(final RelDataTypeFactory typeFactory, final AggregateCall e) {
            return AggregateCall.create(SqlStdOperatorTable.COUNT, false, (List)ImmutableIntList.of(), -1, typeFactory.createSqlType(SqlTypeName.BIGINT), (String)null);
        }
        
        @Override
        public AggregateCall topSplit(final RexBuilder rexBuilder, final Registry<RexNode> extra, final int offset, final RelDataType inputRowType, final AggregateCall aggregateCall, final JoinRelType joinType, final int leftSubTotal, final int rightSubTotal, final boolean handleNullOnLeft, final boolean handleNullOnRight, final boolean projectable) {
            final List<RexNode> merges = new ArrayList<RexNode>();
            if (leftSubTotal >= 0) {
                RelDataType type = aggregateCall.type;
                if (joinType == JoinRelType.RIGHT || joinType == JoinRelType.FULL) {
                    type = rexBuilder.getTypeFactory().createTypeWithNullability(type, true);
                }
                RexNode merge = (RexNode)rexBuilder.makeInputRef(type, leftSubTotal);
                if (handleNullOnLeft) {
                    merge = AggSplitters.handleNull(rexBuilder, merge);
                }
                merges.add(merge);
            }
            if (rightSubTotal >= 0) {
                RelDataType type = aggregateCall.type;
                if (joinType == JoinRelType.LEFT || joinType == JoinRelType.FULL) {
                    type = rexBuilder.getTypeFactory().createTypeWithNullability(type, true);
                }
                RexNode merge = (RexNode)rexBuilder.makeInputRef(type, rightSubTotal);
                if (handleNullOnRight) {
                    merge = AggSplitters.handleNull(rexBuilder, merge);
                }
                merges.add(merge);
            }
            RexNode node = null;
            switch (merges.size()) {
                case 1: {
                    node = merges.get(0);
                    break;
                }
                case 2: {
                    node = rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.MULTIPLY, (List)merges);
                    break;
                }
                default: {
                    throw new AssertionError((Object)("unexpected count " + merges));
                }
            }
            final int ordinal = extra.register(node);
            return AggregateCall.create((SqlAggFunction)(projectable ? ProjectableSqlAggFunctions.PROJECTABLE_SUM0 : SqlStdOperatorTable.SUM0), false, (List)ImmutableList.of((Object)ordinal), -1, aggregateCall.type, aggregateCall.name);
        }
        
        public RexNode singleton(final RexBuilder rexBuilder, final RelDataType inputRowType, final AggregateCall aggregateCall) {
            final List<RexNode> predicates = new ArrayList<RexNode>();
            for (final Integer arg : aggregateCall.getArgList()) {
                final RelDataType type = inputRowType.getFieldList().get(arg).getType();
                if (type.isNullable()) {
                    predicates.add(rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NOT_NULL, new RexNode[] { rexBuilder.makeInputRef(type, (int)arg) }));
                }
            }
            final RexNode predicate = RexUtil.composeConjunction(rexBuilder, (Iterable)predicates, true);
            if (predicate == null) {
                return (RexNode)rexBuilder.makeExactLiteral(BigDecimal.ONE);
            }
            return rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.CASE, new RexNode[] { predicate, rexBuilder.makeExactLiteral(BigDecimal.ONE), rexBuilder.makeExactLiteral(BigDecimal.ZERO) });
        }
        
        static {
            INSTANCE = new CountSplitter();
        }
    }
    
    static class SelfSplitter implements Splitter
    {
        public static final SelfSplitter INSTANCE;
        
        public RexNode singleton(final RexBuilder rexBuilder, final RelDataType inputRowType, final AggregateCall aggregateCall) {
            final int arg = aggregateCall.getArgList().get(0);
            final RelDataTypeField field = inputRowType.getFieldList().get(arg);
            return (RexNode)rexBuilder.makeInputRef(field.getType(), arg);
        }
        
        @Override
        public AggregateCall split(final AggregateCall aggregateCall, final Mappings.TargetMapping mapping) {
            return aggregateCall.transform(mapping);
        }
        
        @Override
        public AggregateCall other(final RelDataTypeFactory typeFactory, final AggregateCall e) {
            return null;
        }
        
        @Override
        public AggregateCall topSplit(final RexBuilder rexBuilder, final Registry<RexNode> extra, final int offset, final RelDataType inputRowType, final AggregateCall aggregateCall, final JoinRelType joinType, final int leftSubTotal, final int rightSubTotal, final boolean handleNullOnLeft, final boolean handleNullOnRight, final boolean projectable) {
            assert leftSubTotal >= 0 != rightSubTotal >= 0;
            final int arg = (leftSubTotal >= 0) ? leftSubTotal : rightSubTotal;
            return aggregateCall.copy((List)ImmutableIntList.of(new int[] { arg }), -1);
        }
        
        static {
            INSTANCE = new SelfSplitter();
        }
    }
    
    static class SumSplitter implements Splitter
    {
        public static final SumSplitter INSTANCE;
        
        public RexNode singleton(final RexBuilder rexBuilder, final RelDataType inputRowType, final AggregateCall aggregateCall) {
            final int arg = aggregateCall.getArgList().get(0);
            final RelDataTypeField field = inputRowType.getFieldList().get(arg);
            return (RexNode)rexBuilder.makeInputRef(field.getType(), arg);
        }
        
        @Override
        public AggregateCall split(final AggregateCall aggregateCall, final Mappings.TargetMapping mapping) {
            return aggregateCall.transform(mapping);
        }
        
        @Override
        public AggregateCall other(final RelDataTypeFactory typeFactory, final AggregateCall e) {
            return AggregateCall.create(SqlStdOperatorTable.COUNT, false, (List)ImmutableIntList.of(), -1, typeFactory.createSqlType(SqlTypeName.BIGINT), (String)null);
        }
        
        @Override
        public AggregateCall topSplit(final RexBuilder rexBuilder, final Registry<RexNode> extra, final int offset, final RelDataType inputRowType, final AggregateCall aggregateCall, final JoinRelType joinType, final int leftSubTotal, final int rightSubTotal, final boolean handleNullOnLeft, final boolean handleNullOnRight, final boolean projectable) {
            final List<RexNode> merges = new ArrayList<RexNode>();
            final List<RelDataTypeField> fieldList = (List<RelDataTypeField>)inputRowType.getFieldList();
            if (leftSubTotal >= 0) {
                RelDataType type = fieldList.get(leftSubTotal).getType();
                if (joinType == JoinRelType.RIGHT || joinType == JoinRelType.FULL) {
                    type = rexBuilder.getTypeFactory().createTypeWithNullability(type, true);
                }
                RexNode merge = (RexNode)rexBuilder.makeInputRef(type, leftSubTotal);
                if (handleNullOnLeft) {
                    merge = AggSplitters.handleNull(rexBuilder, merge);
                }
                merges.add(merge);
            }
            if (rightSubTotal >= 0) {
                RelDataType type = fieldList.get(rightSubTotal).getType();
                if (joinType == JoinRelType.LEFT || joinType == JoinRelType.FULL) {
                    type = rexBuilder.getTypeFactory().createTypeWithNullability(type, true);
                }
                RexNode merge = (RexNode)rexBuilder.makeInputRef(type, rightSubTotal);
                if (handleNullOnRight) {
                    merge = AggSplitters.handleNull(rexBuilder, merge);
                }
                merges.add(merge);
            }
            RexNode node = null;
            switch (merges.size()) {
                case 1: {
                    node = merges.get(0);
                    break;
                }
                case 2: {
                    node = rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.MULTIPLY, (List)merges);
                    node = rexBuilder.makeAbstractCast(aggregateCall.type, node);
                    break;
                }
                default: {
                    throw new AssertionError((Object)("unexpected count " + merges));
                }
            }
            final int ordinal = extra.register(node);
            return AggregateCall.create((SqlAggFunction)(projectable ? ProjectableSqlAggFunctions.PROJECTABLE_SUM : SqlStdOperatorTable.SUM), false, (List)ImmutableList.of((Object)ordinal), -1, aggregateCall.type, aggregateCall.name);
        }
        
        static {
            INSTANCE = new SumSplitter();
        }
    }
    
    static class Sum0Splitter implements Splitter
    {
        public static final Sum0Splitter INSTANCE;
        
        public RexNode singleton(final RexBuilder rexBuilder, final RelDataType inputRowType, final AggregateCall aggregateCall) {
            final int arg = aggregateCall.getArgList().get(0);
            final RelDataTypeField field = inputRowType.getFieldList().get(arg);
            return (RexNode)rexBuilder.makeInputRef(field.getType(), arg);
        }
        
        @Override
        public AggregateCall split(final AggregateCall aggregateCall, final Mappings.TargetMapping mapping) {
            return aggregateCall.transform(mapping);
        }
        
        @Override
        public AggregateCall other(final RelDataTypeFactory typeFactory, final AggregateCall e) {
            return AggregateCall.create(SqlStdOperatorTable.COUNT, false, (List)ImmutableIntList.of(), -1, typeFactory.createSqlType(SqlTypeName.BIGINT), (String)null);
        }
        
        @Override
        public AggregateCall topSplit(final RexBuilder rexBuilder, final Registry<RexNode> extra, final int offset, final RelDataType inputRowType, final AggregateCall aggregateCall, final JoinRelType joinType, final int leftSubTotal, final int rightSubTotal, final boolean handleNullOnLeft, final boolean handleNullOnRight, final boolean projectable) {
            final List<RexNode> merges = new ArrayList<RexNode>();
            final List<RelDataTypeField> fieldList = (List<RelDataTypeField>)inputRowType.getFieldList();
            if (leftSubTotal >= 0) {
                RelDataType type = fieldList.get(leftSubTotal).getType();
                if (joinType == JoinRelType.RIGHT || joinType == JoinRelType.FULL) {
                    type = rexBuilder.getTypeFactory().createTypeWithNullability(type, true);
                }
                RexNode merge = (RexNode)rexBuilder.makeInputRef(type, leftSubTotal);
                if (handleNullOnLeft) {
                    merge = AggSplitters.handleNull(rexBuilder, merge);
                }
                merges.add(merge);
            }
            if (rightSubTotal >= 0) {
                RelDataType type = fieldList.get(rightSubTotal).getType();
                if (joinType == JoinRelType.LEFT || joinType == JoinRelType.FULL) {
                    type = rexBuilder.getTypeFactory().createTypeWithNullability(type, true);
                }
                RexNode merge = (RexNode)rexBuilder.makeInputRef(type, rightSubTotal);
                if (handleNullOnRight) {
                    merge = AggSplitters.handleNull(rexBuilder, merge);
                }
                merges.add(merge);
            }
            RexNode node = null;
            switch (merges.size()) {
                case 1: {
                    node = merges.get(0);
                    break;
                }
                case 2: {
                    node = rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.MULTIPLY, (List)merges);
                    node = rexBuilder.makeAbstractCast(aggregateCall.type, node);
                    break;
                }
                default: {
                    throw new AssertionError((Object)("unexpected count " + merges));
                }
            }
            final int ordinal = extra.register(node);
            return AggregateCall.create((SqlAggFunction)(projectable ? ProjectableSqlAggFunctions.PROJECTABLE_SUM0 : SqlStdOperatorTable.SUM0), false, (List)ImmutableList.of((Object)ordinal), -1, aggregateCall.type, aggregateCall.name);
        }
        
        static {
            INSTANCE = new Sum0Splitter();
        }
    }
    
    public interface Splitter
    {
        AggregateCall split(final AggregateCall p0, final Mappings.TargetMapping p1);
        
        AggregateCall other(final RelDataTypeFactory p0, final AggregateCall p1);
        
        AggregateCall topSplit(final RexBuilder p0, final Registry<RexNode> p1, final int p2, final RelDataType p3, final AggregateCall p4, final JoinRelType p5, final int p6, final int p7, final boolean p8, final boolean p9, final boolean p10);
    }
}
