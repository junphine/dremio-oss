package com.dremio.reflection.rules;

import com.google.common.collect.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.rel.core.*;
import java.util.*;
import org.apache.calcite.sql.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.sql.fun.*;

public final class ProjectableSqlAggFunctions
{
    public static final ProjectableSqlMinMaxAggFunction PROJECTABLE_MIN;
    public static final ProjectableSqlMinMaxAggFunction PROJECTABLE_MAX;
    public static final ProjectableSqlCountAggFunction PROJECTABLE_COUNT;
    public static final ProjectableSqlSumAggFunction PROJECTABLE_SUM;
    public static final ProjectableSqlSumEmptyIsZeroAggFunction PROJECTABLE_SUM0;
    private static final ImmutableMap<SqlAggFunction, SqlAggFunction> MAP;
    
    public static SqlAggFunction toProjectableFunction(final SqlAggFunction function) {
        if (function instanceof ProjectableSqlAggFunction) {
            return function;
        }
        return (SqlAggFunction)ProjectableSqlAggFunctions.MAP.get((Object)function);
    }
    
    public static int indexOfMatchingCall(final AggregateCall call, final List<AggregateCall> list) {
        final ListIterator<AggregateCall> iter = list.listIterator();
        while (iter.hasNext()) {
            if (matches(call, iter.next())) {
                return iter.previousIndex();
            }
        }
        return -1;
    }
    
    public static boolean matches(final AggregateCall call1, final AggregateCall call2) {
        return call1.getAggregation().getKind() == call2.getAggregation().getKind() && call1.isDistinct() == call2.isDistinct() && call1.getArgList().equals(call2.getArgList()) && call1.filterArg == call2.filterArg;
    }
    
    public static AggregateCall convertToRegularSum(final AggregateCall call) {
        if (call.getAggregation() == SqlStdOperatorTable.SUM0) {
            return AggregateCall.create(SqlStdOperatorTable.SUM, call.isDistinct(), call.isApproximate(), call.getArgList(), call.filterArg, call.getType(), call.getName());
        }
        if (call.getAggregation() == ProjectableSqlAggFunctions.PROJECTABLE_SUM0) {
            return AggregateCall.create((SqlAggFunction)ProjectableSqlAggFunctions.PROJECTABLE_SUM, call.isDistinct(), call.isApproximate(), call.getArgList(), call.filterArg, call.getType(), call.getName());
        }
        throw new UnsupportedOperationException();
    }
    
    static {
        PROJECTABLE_MIN = new ProjectableSqlMinMaxAggFunction(SqlKind.MIN);
        PROJECTABLE_MAX = new ProjectableSqlMinMaxAggFunction(SqlKind.MAX);
        PROJECTABLE_COUNT = new ProjectableSqlCountAggFunction();
        PROJECTABLE_SUM = new ProjectableSqlSumAggFunction();
        PROJECTABLE_SUM0 = new ProjectableSqlSumEmptyIsZeroAggFunction();
        MAP = ImmutableMap.of((Object)SqlStdOperatorTable.COUNT, (Object)ProjectableSqlAggFunctions.PROJECTABLE_COUNT, (Object)SqlStdOperatorTable.MIN, (Object)ProjectableSqlAggFunctions.PROJECTABLE_MIN, (Object)SqlStdOperatorTable.MAX, (Object)ProjectableSqlAggFunctions.PROJECTABLE_MAX, (Object)SqlStdOperatorTable.SUM, (Object)ProjectableSqlAggFunctions.PROJECTABLE_SUM, (Object)SqlStdOperatorTable.SUM0, (Object)ProjectableSqlAggFunctions.PROJECTABLE_SUM0);
    }
    
    static class ProjectableSqlCountAggFunction extends SqlCountAggFunction implements ProjectableSqlAggFunction
    {
        public ProjectableSqlCountAggFunction() {
            super("COUNT");
        }
        
        public String getName() {
            return "Projectable" + super.getName();
        }
    }
    
    static class ProjectableSqlMinMaxAggFunction extends SqlMinMaxAggFunction implements ProjectableSqlAggFunction
    {
        public ProjectableSqlMinMaxAggFunction(final SqlKind kind) {
            super(kind);
        }
        
        public String getName() {
            return "Projectable" + super.getName();
        }
    }
    
    static class ProjectableSqlSumAggFunction extends SqlSumAggFunction implements ProjectableSqlAggFunction
    {
        public ProjectableSqlSumAggFunction() {
            super((RelDataType)null);
        }
        
        public String getName() {
            return "Projectable" + super.getName();
        }
    }
    
    static class ProjectableSqlSumEmptyIsZeroAggFunction extends SqlSumEmptyIsZeroAggFunction implements ProjectableSqlAggFunction
    {
        public String getName() {
            return "Projectable" + super.getName();
        }
    }
}
