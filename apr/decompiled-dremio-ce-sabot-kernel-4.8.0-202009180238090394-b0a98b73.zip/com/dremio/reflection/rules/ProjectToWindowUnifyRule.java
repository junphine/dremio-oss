package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.rel.logical.*;
import com.google.common.collect.*;
import java.util.*;

public final class ProjectToWindowUnifyRule extends AbstractUnifyRule
{
    public static final ProjectToWindowUnifyRule INSTANCE;
    
    private ProjectToWindowUnifyRule() {
        super("P => W", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalWindow.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalProject query = (LogicalProject)call.query;
        final RelNode newProject = query.copy(query.getTraitSet(), (List)ImmutableList.of((Object)call.reflection));
        return call.result(newProject);
    }
    
    static {
        INSTANCE = new ProjectToWindowUnifyRule();
    }
}
