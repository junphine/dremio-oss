package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.linq4j.*;
import org.apache.calcite.sql.*;
import java.util.stream.*;
import org.apache.calcite.util.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.core.*;
import java.util.*;
import com.google.common.collect.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rel.*;

public final class WindowOnProjectToWindowUnifyRule extends AbstractUnifyRule
{
    public static final WindowOnProjectToWindowUnifyRule INSTANCE;
    
    private WindowOnProjectToWindowUnifyRule() {
        super("W.P. => W", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalWindow.class, AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class)), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalWindow.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalWindow target = (LogicalWindow)call.target;
        final LogicalWindow query = (LogicalWindow)call.query;
        final LogicalProject project = (LogicalProject)query.getInput();
        final List<Window.Group> newGroups = new ArrayList<Window.Group>();
        final Integer[] mapping = new Integer[project.getProjects().size()];
        for (final Ord<RexNode> proj : Ord.zip(project.getProjects())) {
            if (proj.e instanceof RexInputRef) {
                mapping[proj.i] = ((RexInputRef)proj.e).getIndex();
            }
        }
        final RexShuttle shuttle = new RexShuttle() {
            public RexNode visitInputRef(final RexInputRef ref) {
                if (ref.getIndex() < project.getRowType().getFieldCount()) {
                    return project.getProjects().get(ref.getIndex());
                }
                return (RexNode)new RexInputRef(ref.getIndex() - project.getRowType().getFieldCount() + project.getInput().getRowType().getFieldCount(), ref.getType());
            }
        };
        for (final Window.Group g : query.groups) {
            final RexCall rexCall;
            final List<Window.RexWinAggCall> newAggCalls = g.aggCalls.stream().map(aggCall -> {
                rexCall = (RexCall)aggCall.accept((RexVisitor)shuttle);
                return new Window.RexWinAggCall((SqlAggFunction)rexCall.getOperator(), rexCall.getType(), rexCall.getOperands(), aggCall.ordinal, aggCall.distinct);
            }).collect((Collector<? super Object, ?, List<Window.RexWinAggCall>>)Collectors.toList());
            final ImmutableBitSet.Builder keyBuilder = ImmutableBitSet.builder();
            for (final int i : g.keys) {
                if (mapping[i] == null) {
                    call.getTracer().log(String.format("Could not push Window past Project, because %s is not a simple reference", project.getProjects().get(i)));
                    return null;
                }
                keyBuilder.set((int)mapping[i]);
            }
            final ImmutableBitSet newKeys = keyBuilder.build();
            final RexWindowBound lowerBound = g.lowerBound.accept((RexVisitor)shuttle);
            final RexWindowBound upperBound = g.upperBound.accept((RexVisitor)shuttle);
            try {
                final Object o;
                final LogicalProject logicalProject;
                final RelCollation orderKeys = RelCollations.of((List)g.orderKeys.getFieldCollations().stream().map(collation -> {
                    if (o[collation.getFieldIndex()] == null) {
                        call.getTracer().log(String.format("Could not push Window past Project, because %s is not a simple reference", logicalProject.getProjects().get(collation.getFieldIndex())));
                        throw MatchFailed.INSTANCE;
                    }
                    else {
                        return collation.copy((int)o[collation.getFieldIndex()]);
                    }
                }).collect(Collectors.toList()));
                newGroups.add(new Window.Group(newKeys, g.isRows, lowerBound, upperBound, orderKeys, (List)newAggCalls));
            }
            catch (MatchFailed m) {
                return null;
            }
        }
        final RelDataTypeFactory.FieldInfoBuilder outputFieldBuilder = query.getCluster().getTypeFactory().builder();
        outputFieldBuilder.addAll((Iterable)project.getInput().getRowType().getFieldList());
        outputFieldBuilder.addAll((Iterable)Util.skip(query.getRowType().getFieldList(), project.getRowType().getFieldCount()));
        final LogicalWindow newWindow = LogicalWindow.create(query.getTraitSet(), project.getInput(), query.getConstants(), outputFieldBuilder.build(), (List)newGroups);
        final org.apache.calcite.tools.RelBuilder relBuilder = RelBuilder.newCalciteRelBuilderWithoutContext(query.getCluster());
        relBuilder.push((RelNode)newWindow);
        final List<RexNode> newProjects = new ArrayList<RexNode>(project.getProjects());
        final int offset = query.getRowType().getFieldCount() - newWindow.getRowType().getFieldCount();
        for (int i = project.getRowType().getFieldCount(); i < query.getRowType().getFieldCount(); ++i) {
            newProjects.add((RexNode)relBuilder.field(i - offset));
        }
        final LogicalProject topProject = (LogicalProject)relBuilder.project((Iterable)newProjects, (Iterable)query.getRowType().getFieldNames(), true).build();
        final RelNode unified = WindowToWindowUnifyRule.unify(target, newWindow, call.reflection);
        if (unified == null) {
            return null;
        }
        if (unified instanceof LogicalProject) {
            final LogicalProject middleProject = (LogicalProject)unified;
            final List<RexNode> finalProjects = (List<RexNode>)RelOptUtil.pushPastProject(topProject.getProjects(), (Project)middleProject);
            return call.result((RelNode)LogicalProject.create(middleProject.getInput(), (List)finalProjects, query.getRowType()));
        }
        if (RexUtil.isIdentity(topProject.getProjects(), unified.getRowType())) {
            return call.result(unified);
        }
        topProject.replaceInput(0, unified);
        return call.result((RelNode)topProject);
    }
    
    static {
        INSTANCE = new WindowOnProjectToWindowUnifyRule();
    }
}
