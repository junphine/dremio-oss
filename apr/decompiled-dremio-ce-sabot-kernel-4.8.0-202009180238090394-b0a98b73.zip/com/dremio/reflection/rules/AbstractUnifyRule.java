package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import java.util.*;

public abstract class AbstractUnifyRule extends UnifyRule
{
    static final Operand ANY;
    
    public AbstractUnifyRule(final String name, final Operand queryOperand, final Operand targetOperand) {
        super(name, queryOperand, targetOperand);
    }
    
    public static Operand operand(final Class<? extends RelNode> clazz) {
        return any(clazz);
    }
    
    public static Operand operand(final Class<? extends RelNode> clazz, final Operand o2) {
        return new InternalOperand(clazz, o2);
    }
    
    public static Operand any(final Class<? extends RelNode> clazz) {
        return new AnyOperand(clazz);
    }
    
    static {
        ANY = new AllOperand();
    }
    
    public abstract static class Operand
    {
        protected final Class<? extends RelNode> clazz;
        
        protected Operand(final Class<? extends RelNode> clazz) {
            this.clazz = clazz;
        }
        
        public Class<? extends RelNode> getClazz() {
            return this.clazz;
        }
        
        public abstract boolean matches(final RelNode p0);
        
        public abstract int getHorizon();
    }
    
    private static final class AllOperand extends Operand
    {
        private AllOperand() {
            super(RelNode.class);
        }
        
        @Override
        public boolean matches(final RelNode rel) {
            return true;
        }
        
        @Override
        public int getHorizon() {
            return 1;
        }
    }
    
    private static class InternalOperand extends Operand
    {
        private final Operand input;
        private final int horizon;
        
        InternalOperand(final Class<? extends RelNode> clazz, final Operand input) {
            super(clazz);
            this.horizon = input.getHorizon() + 1;
            this.input = input;
        }
        
        @Override
        public boolean matches(final RelNode rel) {
            if (!this.clazz.isInstance(rel)) {
                return false;
            }
            final List<RelNode> nodes = (List<RelNode>)rel.getInputs();
            return nodes.size() == 1 && this.input.matches(nodes.get(0));
        }
        
        @Override
        public int getHorizon() {
            return this.horizon;
        }
    }
    
    private static class AnyOperand extends Operand
    {
        AnyOperand(final Class<? extends RelNode> clazz) {
            super(clazz);
        }
        
        @Override
        public boolean matches(final RelNode rel) {
            return this.clazz.isInstance(rel);
        }
        
        @Override
        public int getHorizon() {
            return 1;
        }
    }
}
