package com.dremio.reflection.rules;

import org.apache.calcite.plan.*;
import com.google.common.base.*;
import org.apache.calcite.util.*;
import org.apache.calcite.util.mapping.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.metadata.*;
import org.apache.calcite.rex.*;
import java.util.*;
import com.google.common.collect.*;
import org.apache.calcite.sql.*;

public final class DremioAggregateFilterTransposeRule extends RelOptRule
{
    public static final DremioAggregateFilterTransposeRule INSTANCE;
    
    private DremioAggregateFilterTransposeRule() {
        super(operand((Class)Aggregate.class, operand((Class)Filter.class, any()), new RelOptRuleOperand[0]));
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rel(0);
        final Filter filter = (Filter)call.rel(1);
        final ImmutableBitSet filterColumns = RelOptUtil.InputFinder.bits(filter.getCondition());
        final ImmutableBitSet newGroupSet = aggregate.getGroupSet().union(filterColumns);
        final RelNode input = filter.getInput();
        final RelMetadataQuery mq = aggregate.getCluster().getMetadataQuery();
        final Boolean unique = mq.areColumnsUnique(input, newGroupSet);
        if (unique != null && unique) {
            return;
        }
        final boolean allColumnsInAggregate = aggregate.getGroupSet().contains(filterColumns);
        final Aggregate newAggregate = aggregate.copy(aggregate.getTraitSet(), input, false, newGroupSet, (List)null, aggregate.getAggCallList());
        final Mappings.TargetMapping mapping = Mappings.target((Function)new Function<Integer, Integer>() {
            public Integer apply(final Integer a0) {
                return newGroupSet.indexOf((int)a0);
            }
        }, input.getRowType().getFieldCount(), newGroupSet.cardinality());
        final RexNode newCondition = RexUtil.apply(mapping, filter.getCondition());
        final Filter newFilter = filter.copy(filter.getTraitSet(), (RelNode)newAggregate, newCondition);
        if (allColumnsInAggregate && !aggregate.indicator) {
            assert newGroupSet.equals((Object)aggregate.getGroupSet());
            call.transformTo((RelNode)newFilter);
        }
        else {
            final ImmutableBitSet.Builder topGroupSet = ImmutableBitSet.builder();
            for (final int c : aggregate.getGroupSet()) {
                topGroupSet.set(newGroupSet.indexOf(c));
            }
            ImmutableList<ImmutableBitSet> newGroupingSets = null;
            if (aggregate.indicator) {
                final ImmutableList.Builder<ImmutableBitSet> newGroupingSetsBuilder = (ImmutableList.Builder<ImmutableBitSet>)ImmutableList.builder();
                for (final ImmutableBitSet groupingSet : aggregate.getGroupSets()) {
                    final ImmutableBitSet.Builder newGroupingSet = ImmutableBitSet.builder();
                    for (final int c2 : groupingSet) {
                        newGroupingSet.set(newGroupSet.indexOf(c2));
                    }
                    newGroupingSetsBuilder.add((Object)newGroupingSet.build());
                }
                newGroupingSets = (ImmutableList<ImmutableBitSet>)newGroupingSetsBuilder.build();
            }
            final List<AggregateCall> topAggCallList = (List<AggregateCall>)Lists.newArrayList();
            int i = newGroupSet.cardinality();
            for (final AggregateCall aggregateCall : aggregate.getAggCallList()) {
                final SqlAggFunction rollup = AggregateToAggregateUnifyRule.getRollup(aggregateCall.getAggregation());
                if (rollup == null) {
                    return;
                }
                if (aggregateCall.isDistinct()) {
                    return;
                }
                topAggCallList.add(AggregateCall.create(rollup, aggregateCall.isDistinct(), (List)ImmutableList.of((Object)(i++)), -1, aggregateCall.type, aggregateCall.name));
            }
            final Aggregate topAggregate = aggregate.copy(aggregate.getTraitSet(), (RelNode)newFilter, aggregate.indicator, topGroupSet.build(), (List)newGroupingSets, (List)topAggCallList);
            call.transformTo((RelNode)topAggregate);
        }
    }
    
    static {
        INSTANCE = new DremioAggregateFilterTransposeRule();
    }
}
