package com.dremio.reflection.rules;

import org.apache.calcite.rel.rules.*;
import org.apache.calcite.rel.*;
import com.dremio.exec.planner.logical.*;
import com.dremio.exec.planner.physical.*;
import com.dremio.exec.planner.acceleration.substitution.*;
import com.dremio.options.*;
import org.apache.calcite.tools.*;
import java.util.*;
import com.dremio.reflection.bup.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.plan.*;
import com.google.common.base.*;
import javax.annotation.*;
import org.slf4j.*;
import java.util.stream.*;
import org.apache.calcite.util.mapping.*;
import org.apache.calcite.rex.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.util.*;
import org.apache.calcite.linq4j.*;

public final class MultiJoinToMultiJoinMunifyRule extends MunifyRule
{
    private static final Logger LOGGER;
    public static final MultiJoinToMultiJoinMunifyRule INSTANCE;
    public static final MappingResult NO_MATCH;
    
    public MultiJoinToMultiJoinMunifyRule() {
        super("J => J", (Class<? extends RelNode>)MultiJoin.class);
    }
    
    @Override
    public MunifyResult apply(final MunifyRuleCall call) {
        if (!(call.getQuery() instanceof MultiJoin)) {
            call.getTracer().log("User input is not multijoin.");
            return null;
        }
        if (TrivialMunifyRule.isTrivialMatch(call)) {
            return null;
        }
        final MultiJoin query = (MultiJoin)call.getQuery();
        final MultiJoin target = (MultiJoin)call.getTarget();
        if (!this.supported(query, target)) {
            call.getTracer().log("Join match failed since join type not supported.");
            return null;
        }
        final RelBuilder relBuilder = DremioRelFactories.CALCITE_LOGICAL_BUILDER.create(call.getQuery().getCluster(), (RelOptSchema)null);
        final MappingResult mappingResult = this.findQueryToTargetInputMapping(call, query, target, relBuilder);
        if (!mappingResult.matched) {
            call.getTracer().log("Unable map reflection inputs to user query.");
            return null;
        }
        final RexBuilder rexBuilder = query.getCluster().getRexBuilder();
        final RexExecutor rexExecutor = query.getCluster().getPlanner().getExecutor();
        final List<RexNode> queryFilters = mappingResult.collectJoinConditions(query);
        final List<RexNode> targetFilters = MultiJoinToMultiJoinMunifyRule.NO_MATCH.collectJoinConditions(target);
        final List<RexNode> remainingFilter = new ArrayList<RexNode>();
        final long limit = PrelUtil.getPlannerSettings(query.getCluster()).getOptions().getOption((TypeValidators.LongValidator)ReflectionOptions.ACCELERATION_FILTER_THRESHOLD);
        if (!RexSubstitutionUtil.implies(queryFilters, targetFilters, target.getRowType(), rexBuilder, rexExecutor, remainingFilter, limit)) {
            call.getTracer().log(String.format("The reflection filters [%s] are more constrained than the query filters [%s].", targetFilters, queryFilters));
            return null;
        }
        RelNode newInputRelNode;
        if (mappingResult.hasUnusedInputs()) {
            newInputRelNode = mappingResult.createSubMultiJoin(query, call.getReflection(), rexBuilder, relBuilder, (RexNode)Iterables.getFirst((Iterable)remainingFilter, (Object)null));
        }
        else {
            newInputRelNode = (RelNode)call.getReflection();
        }
        RelNode withFilter;
        if (!remainingFilter.isEmpty()) {
            if (target.isFullOuterJoin()) {
                call.getTracer().log("The target is full outer join, but the join conditions are not exact");
                return null;
            }
            Preconditions.checkState(remainingFilter.size() == 1, (Object)"implies() should return a single RexNode for the remaining filters");
            RexNode filter = remainingFilter.get(0);
            if (mappingResult.finalPermutation != null) {
                filter = RexPermuteInputsShuttle.of((Mappings.TargetMapping)mappingResult.finalPermutation).apply(filter);
            }
            withFilter = RelOptUtil.createFilter(newInputRelNode, filter);
        }
        else {
            withFilter = newInputRelNode;
        }
        int columnOffset = 0;
        for (int inputIndex = 0; inputIndex < query.getInputs().size(); ++inputIndex) {
            final ImmutableBitSet projFields = query.getProjFields().get(inputIndex);
            final RelNode inputAtIndex = query.getInput(inputIndex);
            if (projFields != null) {
                for (int columnIndex = 0; columnIndex < inputAtIndex.getRowType().getFieldCount(); ++columnIndex) {
                    if (!projFields.get(columnIndex)) {
                        mappingResult.cast(columnOffset + columnIndex, rexBuilder);
                    }
                }
            }
            columnOffset += inputAtIndex.getRowType().getFieldCount();
        }
        return mappingResult.getResult(call, (RelNode)query, newInputRelNode, withFilter);
    }
    
    private boolean canBeAboveJoin(final BupTracer tracer, final JoinRelType qType, final int qIndex, final boolean isFullOuter, final int inputRowSize, final OutputProjectAndFilterToOffset outputOffset) {
        if (qType == JoinRelType.INNER && !isFullOuter) {
            return true;
        }
        if ((qType == JoinRelType.LEFT && qIndex == 0) || (qType == JoinRelType.RIGHT && qIndex == 1)) {
            return true;
        }
        if (outputOffset.filter != null) {
            tracer.log(String.format("Cannot push a filter above an outer join, %s.", outputOffset.filter));
            return false;
        }
        if (outputOffset.projects != null) {
            final ImmutableBitSet nullColumns = ImmutableBitSet.range(inputRowSize);
            final Strong strongChecker = Strong.of(nullColumns);
            for (final RexNode expr : outputOffset.projects) {
                if (!strongChecker.isNull(expr)) {
                    tracer.log(String.format("Cannot push a weak expression above an outer join, %s.", expr));
                    return false;
                }
            }
        }
        return true;
    }
    
    private MappingResult findQueryToTargetInputMapping(final MunifyRuleCall call, final MultiJoin query, final MultiJoin target, final RelBuilder relBuilder) {
        final MappingResult result = new MappingResult();
        final int queryMultiJoinInputSize = query.getInputs().size();
        final int targetMultiJoinInputSize = target.getInputs().size();
        final MunifyRuleCall.MunifyInput[] expectedInputs = new MunifyRuleCall.MunifyInput[query.getInputs().size()];
        final List<MunifyRuleCall.MunifyInput> legs = call.getInputs();
        for (final MunifyRuleCall.MunifyInput leg : legs) {
            expectedInputs[leg.getQueryPosition()] = leg;
        }
        final BiMap<Integer, Integer> actualToTarget = (BiMap<Integer, Integer>)HashBiMap.create();
        for (int qIndex = 0; qIndex < expectedInputs.length; ++qIndex) {
            if (expectedInputs[qIndex] != null) {
                actualToTarget.put((Object)qIndex, (Object)expectedInputs[qIndex].getTargetPosition());
            }
        }
        result.actualToTarget = actualToTarget;
        int sumFieldCountOfQueryInputsThatDidNotMatch = 0;
        final RelDataTypeFactory factory = query.getCluster().getTypeFactory();
        final OutputProjectAndFilterToOffset[] offsets = new OutputProjectAndFilterToOffset[expectedInputs.length];
        for (int qIndex2 = 0; qIndex2 < expectedInputs.length; ++qIndex2) {
            int offset = 0;
            boolean match = false;
            for (int tIndex = 0; tIndex < target.getInputs().size(); ++tIndex) {
                final MunifyRuleCall.MunifyInput leg2 = call.getInputs().get(tIndex);
                if (leg2.getQueryPosition() == qIndex2) {
                    offsets[qIndex2] = new OutputProjectAndFilterToOffset(offset, factory);
                    match = true;
                    break;
                }
                offset += leg2.getReflection().getRowType().getFieldCount();
            }
            if (!match) {
                offsets[qIndex2] = new OutputProjectAndFilterToOffset(offset + sumFieldCountOfQueryInputsThatDidNotMatch, factory);
                sumFieldCountOfQueryInputsThatDidNotMatch += query.getInput(qIndex2).getRowType().getFieldCount();
            }
        }
        final ImmutableBitSet.Builder belowProjectFields = ImmutableBitSet.builder();
        final List<Integer> matchedOuterJoins = new ArrayList<Integer>();
        for (int qIndex3 = 0; qIndex3 < expectedInputs.length; ++qIndex3) {
            final RelNode qRel = query.getInputs().get(qIndex3);
            final JoinRelType qType = query.getJoinTypes().get(qIndex3);
            final boolean nullableQRel = query.isFullOuterJoin() || (qType == JoinRelType.RIGHT && qIndex3 != 0) || (qType == JoinRelType.LEFT && qIndex3 != queryMultiJoinInputSize);
            final OutputProjectAndFilterToOffset outputOffset = offsets[qIndex3];
            final MunifyRuleCall.MunifyInput leg3 = expectedInputs[qIndex3];
            if (leg3 == null) {
                outputOffset.setProjects(createIdentityAbove(qRel));
                result.projectAboveTarget.addAll(outputOffset.getProjectsWithOffset());
                result.queryInputIndicesThatDidNotMatch.add(qIndex3);
                call.getTracer().log("Did not find a match for subtree", qRel);
            }
            else {
                final int tIndex2 = leg3.getTargetPosition();
                final RelNode tRel = target.getInputs().get(tIndex2);
                final JoinRelType tType = target.getJoinTypes().get(tIndex2);
                if (!compatibleJoinType(qType, tType, qIndex3, queryMultiJoinInputSize - 1, tIndex2, targetMultiJoinInputSize - 1)) {
                    call.getTracer().log("Join match failed as individual join types are not compatible.");
                    return MultiJoinToMultiJoinMunifyRule.NO_MATCH;
                }
                final RelNode legRel = leg3.getInput();
                outputOffset.setNullable(nullableQRel);
                if (legRel instanceof ReflectionPtr) {
                    outputOffset.setProjects(createIdentityAbove(tRel));
                }
                else if (legRel instanceof Filter && ((Filter)legRel).getInput() instanceof ReflectionPtr) {
                    outputOffset.setProjects(createIdentityAbove(tRel));
                    outputOffset.setFilter(((Filter)legRel).getCondition());
                }
                else if (legRel instanceof Project && ((Project)legRel).getInput() instanceof ReflectionPtr) {
                    outputOffset.setProjects(((Project)legRel).getProjects());
                }
                else {
                    if (!(legRel instanceof Project) || !(((Project)legRel).getInput() instanceof Filter) || !(((Filter)((Project)legRel).getInput()).getInput() instanceof ReflectionPtr)) {
                        call.getTracer().log("Under join pattern residue pattern didn't match Project? > Filter? > ReflectionPtr.");
                        return MultiJoinToMultiJoinMunifyRule.NO_MATCH;
                    }
                    final Project subRemovedProject = (Project)legRel;
                    final Filter subRemovedFilter = (Filter)subRemovedProject.getInput();
                    outputOffset.setProjects(subRemovedProject.getProjects());
                    outputOffset.setFilter(subRemovedFilter.getCondition());
                }
                if (!this.canBeAboveJoin(call.getTracer(), qType, qIndex3, query.isFullOuterJoin(), tRel.getRowType().getFieldCount(), outputOffset)) {
                    return MultiJoinToMultiJoinMunifyRule.NO_MATCH;
                }
                result.projectAboveTarget.addAll(outputOffset.getProjectsWithOffset());
                if (outputOffset.filter != null) {
                    result.filtersAboveTarget.add(outputOffset.getFilterWithOffset());
                }
                if (qType != JoinRelType.INNER) {
                    matchedOuterJoins.add(qIndex3);
                }
                final RelOptUtil.InputFinder inputFinder = new RelOptUtil.InputFinder();
                if (query.getProjFields().get(qIndex3) == null) {
                    final Void void1;
                    outputOffset.getProjectsWithOffset().forEach(rexNode -> void1 = (Void)rexNode.accept((RexVisitor)inputFinder));
                }
                else {
                    for (final int i : query.getProjFields().get(qIndex3)) {
                        outputOffset.getProjectsWithOffset().get(i).accept((RexVisitor)inputFinder);
                    }
                }
                final ImmutableBitSet bitSet = inputFinder.inputBitSet.build();
                belowProjectFields.addAll(bitSet);
            }
        }
        result.belowProjectFields = belowProjectFields.build();
        for (final Integer qIndex4 : matchedOuterJoins) {
            final RexNode remappedQueryCondition = (RexNode)query.getOuterJoinConditions().get(qIndex4).accept((RexVisitor)new com.dremio.exec.planner.acceleration.substitution.rules.RexSubstitutionUtil.PushPastProject(result.projectAboveTarget));
            final RexNode targetCondition = target.getOuterJoinConditions().get((int)result.actualToTarget.get((Object)qIndex4));
            if (!RexSubstitutionUtil.equivalent(remappedQueryCondition, targetCondition, query.getCluster().getRexBuilder())) {
                call.getTracer().log("Join match failed as outer join conditions are not equivalent.");
                return MultiJoinToMultiJoinMunifyRule.NO_MATCH;
            }
        }
        result.matched = true;
        return result;
    }
    
    private boolean supported(final MultiJoin query, final MultiJoin target) {
        if (!this.supportedJoinTypes(query.getJoinTypes()) || !this.supportedJoinTypes(target.getJoinTypes()) || target.isFullOuterJoin() != query.isFullOuterJoin()) {
            MultiJoinToMultiJoinMunifyRule.LOGGER.debug("Unsupported multi-join match, query: [{}], target: [{}]", (Object)query, (Object)target);
            return false;
        }
        if (query.getInputs().size() < target.getInputs().size() || (query.getInputs().size() == target.getInputs().size() && !this.haveSameTables(RelOptUtil.findAllTables((RelNode)query), RelOptUtil.findAllTables((RelNode)target)))) {
            MultiJoinToMultiJoinMunifyRule.LOGGER.debug("Unsupported multi-join match, not same table, query: [{}], target: [{}]", (Object)query, (Object)target);
            return false;
        }
        return true;
    }
    
    private boolean supportedJoinTypes(final List<JoinRelType> joinTypes) {
        int numLeft = 0;
        int numRight = 0;
        int numFull = 0;
        int indexLeft = -1;
        int indexRight = -1;
        int index = 0;
        for (final JoinRelType type : joinTypes) {
            switch (type) {
                case LEFT: {
                    indexLeft = index;
                    ++numLeft;
                    break;
                }
                case RIGHT: {
                    indexRight = index;
                    ++numRight;
                    break;
                }
                case FULL: {
                    ++numFull;
                    break;
                }
            }
            ++index;
        }
        return numFull == 0 && ((numLeft == 1 && numRight == 0 && indexLeft == joinTypes.size() - 1) || (numLeft == 0 && numRight == 1 && indexRight == 0) || (numLeft == 0 && numRight == 0));
    }
    
    private boolean haveSameTables(final List<RelOptTable> queryTablesOrig, final List<RelOptTable> targetTablesOrig) {
        final List<List<String>> targetTables = (List<List<String>>)Lists.transform((List)targetTablesOrig, (Function)new Function<RelOptTable, List<String>>() {
            @Nullable
            public List<String> apply(@Nullable final RelOptTable input) {
                return (List<String>)input.getQualifiedName();
            }
        });
        final List<List<String>> queryTables = (List<List<String>>)Lists.transform((List)queryTablesOrig, (Function)new Function<RelOptTable, List<String>>() {
            @Nullable
            public List<String> apply(@Nullable final RelOptTable input) {
                return (List<String>)input.getQualifiedName();
            }
        });
        if (queryTables.size() != targetTables.size() || !queryTables.containsAll(targetTables)) {
            return false;
        }
        for (final List<String> qt : queryTables) {
            if (!targetTables.remove(qt)) {
                return false;
            }
        }
        return true;
    }
    
    private static boolean compatibleJoinType(final JoinRelType qType, final JoinRelType tType, final int qIndex, final int qMaxIndex, final int tIndex, final int tMaxIndex) {
        return (qType == JoinRelType.INNER && tType == JoinRelType.INNER) || (qType == JoinRelType.LEFT && tType == JoinRelType.LEFT && qIndex == qMaxIndex && tIndex == tMaxIndex) || (qType == JoinRelType.RIGHT && tType == JoinRelType.RIGHT && qIndex == 0 && tIndex == 0) || (qType == JoinRelType.LEFT && tType == JoinRelType.RIGHT && qIndex == qMaxIndex && tIndex == 0) || (qType == JoinRelType.RIGHT && tType == JoinRelType.LEFT && qIndex == 0 && tIndex == tMaxIndex);
    }
    
    private static List<RexNode> createIdentityAbove(final RelNode rel) {
        final List<RexNode> identityProject = new ArrayList<RexNode>();
        for (int i = 0; i < rel.getRowType().getFieldCount(); ++i) {
            identityProject.add((RexNode)new RexInputRef(i, rel.getRowType().getFieldList().get(i).getType()));
        }
        return identityProject;
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)MultiJoinToMultiJoinMunifyRule.class);
        INSTANCE = new MultiJoinToMultiJoinMunifyRule();
        NO_MATCH = new MappingResult(false);
    }
    
    private class OutputProjectAndFilterToOffset
    {
        private boolean nullable;
        private List<RexNode> projects;
        private RexNode filter;
        private final int offset;
        private final RelDataTypeFactory typeFactory;
        
        OutputProjectAndFilterToOffset(final int offset, final RelDataTypeFactory typeFactory) {
            this.nullable = false;
            this.projects = null;
            this.filter = null;
            this.typeFactory = typeFactory;
            this.offset = offset;
        }
        
        void setProjects(final List<RexNode> projects) {
            Preconditions.checkArgument(projects != null);
            this.projects = projects;
        }
        
        void setFilter(final RexNode filter) {
            this.filter = filter;
        }
        
        void setNullable(final boolean nullable) {
            this.nullable = nullable;
        }
        
        boolean found() {
            return this.projects != null;
        }
        
        List<RexNode> getProjectsWithOffset() {
            final InputShifter inputShifter = new InputShifter(this.offset, this.nullable, this.typeFactory);
            return this.projects.stream().map(input -> (RexNode)input.accept((RexVisitor)inputShifter)).collect((Collector<? super Object, ?, List<RexNode>>)Collectors.toList());
        }
        
        RexNode getFilterWithOffset() {
            final InputShifter inputShifter = new InputShifter(this.offset, this.nullable, this.typeFactory);
            return (RexNode)this.filter.accept((RexVisitor)inputShifter);
        }
    }
    
    private static final class InputShifter extends RexShuttle
    {
        private final int shift;
        private final boolean nullable;
        private final RelDataTypeFactory factory;
        
        private InputShifter(final int shift, final boolean nullable, final RelDataTypeFactory factory) {
            this.shift = shift;
            this.nullable = nullable;
            this.factory = factory;
        }
        
        public RexNode visitInputRef(final RexInputRef inputRef) {
            return (RexNode)new RexInputRef(inputRef.getIndex() + this.shift, this.nullable ? this.factory.createTypeWithNullability(inputRef.getType(), true) : inputRef.getType());
        }
    }
    
    private static class MappingResult
    {
        final List<RexNode> projectAboveTarget;
        final List<RexNode> filtersAboveTarget;
        final List<Integer> queryInputIndicesThatDidNotMatch;
        BiMap<Integer, Integer> actualToTarget;
        ImmutableBitSet belowProjectFields;
        boolean matched;
        private Mapping finalPermutation;
        
        public MappingResult(final boolean matched) {
            this.projectAboveTarget = (List<RexNode>)Lists.newArrayList();
            this.filtersAboveTarget = (List<RexNode>)Lists.newArrayList();
            this.queryInputIndicesThatDidNotMatch = (List<Integer>)Lists.newArrayList();
            this.matched = matched;
        }
        
        public MappingResult() {
            this.projectAboveTarget = (List<RexNode>)Lists.newArrayList();
            this.filtersAboveTarget = (List<RexNode>)Lists.newArrayList();
            this.queryInputIndicesThatDidNotMatch = (List<Integer>)Lists.newArrayList();
        }
        
        public MunifyResult getResult(final MunifyRuleCall call, final RelNode query, final RelNode newInputRelNode, final RelNode withFilter) {
            final List<RexNode> finalProject = (this.finalPermutation == null) ? this.projectAboveTarget : RexPermuteInputsShuttle.of((Mappings.TargetMapping)this.finalPermutation).apply((List)this.projectAboveTarget);
            RelNode result;
            if (RexUtil.isIdentity((List)finalProject, newInputRelNode.getRowType()) && withFilter.getRowType().equals(query.getRowType())) {
                result = withFilter;
            }
            else {
                result = (RelNode)LogicalRels.createProject(query.getRowType(), withFilter, finalProject);
            }
            return call.result(result);
        }
        
        public void cast(final int index, final RexBuilder rexBuilder) {
            final RexNode projExpr = this.projectAboveTarget.get(index);
            this.projectAboveTarget.set(index, rexBuilder.makeCast(projExpr.getType(), (RexNode)rexBuilder.constantNull()));
        }
        
        public boolean hasUnusedInputs() {
            return !this.queryInputIndicesThatDidNotMatch.isEmpty();
        }
        
        private List<RexNode> collectJoinConditions(final MultiJoin multiJoin) {
            final List<RexNode> filtersCollected = (List<RexNode>)Lists.newArrayList();
            if (multiJoin.getJoinFilter() != null) {
                RelOptUtil.decomposeConjunction(multiJoin.getJoinFilter(), (List)filtersCollected);
            }
            if (multiJoin.getPostJoinFilter() != null) {
                RelOptUtil.decomposeConjunction(multiJoin.getPostJoinFilter(), (List)filtersCollected);
            }
            List<RexNode> filtersCollectedAndPushed;
            if (this.projectAboveTarget != null && !this.projectAboveTarget.isEmpty()) {
                final com.dremio.exec.planner.acceleration.substitution.rules.RexSubstitutionUtil.PushPastProject pusher = new com.dremio.exec.planner.acceleration.substitution.rules.RexSubstitutionUtil.PushPastProject(this.projectAboveTarget);
                filtersCollectedAndPushed = new ArrayList<RexNode>();
                for (final RexNode toPush : filtersCollected) {
                    filtersCollectedAndPushed.add((RexNode)toPush.accept((RexVisitor)pusher));
                }
            }
            else {
                filtersCollectedAndPushed = filtersCollected;
            }
            if (this.filtersAboveTarget != null && !this.filtersAboveTarget.isEmpty()) {
                for (final RexNode addFilter : this.filtersAboveTarget) {
                    if (addFilter != null) {
                        RelOptUtil.decomposeConjunction(addFilter, (List)filtersCollectedAndPushed);
                    }
                }
            }
            return filtersCollectedAndPushed;
        }
        
        private void addQueryMultiJoinInput(final MultiJoin query, final int qRelIndex, final int newInputIndex, final List<RelNode> mutableRelInputs, final List<RelNode> inputs, final List<JoinRelType> joinTypes, final List<RelDataTypeField> fields, final List<RexNode> outerJoinConditions, final List<ImmutableBitSet> projFields, final ImmutableMap.Builder<Integer, ImmutableIntList> builder) {
            mutableRelInputs.add(query.getInputs().get(qRelIndex));
            final RelNode qRelNode = query.getInput(qRelIndex);
            inputs.add(qRelNode);
            joinTypes.add(query.getJoinTypes().get(qRelIndex));
            fields.addAll(qRelNode.getRowType().getFieldList());
            RexNode outerJoinCondition = query.getOuterJoinConditions().get(qRelIndex);
            if (outerJoinCondition != null) {
                outerJoinCondition = (RexNode)outerJoinCondition.accept((RexVisitor)new com.dremio.exec.planner.acceleration.substitution.rules.RexSubstitutionUtil.PushPastProject(this.projectAboveTarget));
            }
            outerJoinConditions.add(outerJoinCondition);
            projFields.add(null);
            builder.put((Object)newInputIndex, (Object)ImmutableIntList.of());
        }
        
        private RelNode createSubMultiJoin(final MultiJoin query, final ReflectionPtr target, final RexBuilder rexBuilder, final RelBuilder relBuilder, final RexNode remainingFilter) {
            final List<RexNode> identityProject = new ArrayList<RexNode>();
            if (remainingFilter != null) {
                this.belowProjectFields = this.belowProjectFields.union(RelOptUtil.InputFinder.bits(remainingFilter));
            }
            final com.dremio.exec.planner.acceleration.substitution.rules.RexSubstitutionUtil.PushPastProject pusher = new com.dremio.exec.planner.acceleration.substitution.rules.RexSubstitutionUtil.PushPastProject(this.projectAboveTarget);
            final RexVisitor rexVisitor;
            final List<RexNode> pushedOuterJoinConditions = (List<RexNode>)query.getOuterJoinConditions().stream().map(rexNode -> (rexNode == null) ? null : ((RexNode)rexNode.accept(rexVisitor))).collect(Collectors.toList());
            final ImmutableBitSet outJoinInputs = RelOptUtil.InputFinder.bits(RexUtil.composeConjunction(query.getCluster().getRexBuilder(), (Iterable)pushedOuterJoinConditions, false));
            this.belowProjectFields = this.belowProjectFields.union(outJoinInputs);
            for (int i = 0; i < target.getRowType().getFieldCount(); ++i) {
                if (this.belowProjectFields.get(i)) {
                    identityProject.add((RexNode)rexBuilder.makeInputRef((RelNode)target, i));
                }
                else {
                    final RelDataType type = target.getRowType().getFieldList().get(i).getType();
                    identityProject.add(rexBuilder.makeCast(type, (RexNode)rexBuilder.constantNull()));
                }
            }
            final RelNode targetWithIdentityProject = (RelNode)LogicalRels.createProject(target.getRowType(), (RelNode)target, identityProject);
            final List<RelNode> inputRels = (List<RelNode>)Lists.newArrayList();
            final List<RelNode> inputs = (List<RelNode>)Lists.newArrayList();
            final List<JoinRelType> joinTypes = (List<JoinRelType>)Lists.newArrayList();
            final List<RelDataTypeField> fields = (List<RelDataTypeField>)Lists.newArrayList();
            final List<RexNode> outerJoinConditions = (List<RexNode>)Lists.newArrayList();
            final List<ImmutableBitSet> projFields = (List<ImmutableBitSet>)Lists.newArrayList();
            final ImmutableMap.Builder<Integer, ImmutableIntList> builder = (ImmutableMap.Builder<Integer, ImmutableIntList>)ImmutableMap.builder();
            int newInputIndex = 0;
            boolean alreadyAddedZerothQueryInput = false;
            if (this.queryInputIndicesThatDidNotMatch.contains(0) && query.getJoinTypes().get(0) != JoinRelType.INNER) {
                this.addQueryMultiJoinInput(query, 0, newInputIndex, inputRels, inputs, joinTypes, fields, outerJoinConditions, projFields, builder);
                ++newInputIndex;
                alreadyAddedZerothQueryInput = true;
            }
            inputRels.add((RelNode)new MunifyCreatedLateBlock.InputPointer(targetWithIdentityProject));
            inputs.add(relBuilder.push((RelNode)target).project((Iterable)identityProject).build());
            joinTypes.add(JoinRelType.INNER);
            fields.addAll(target.getRowType().getFieldList());
            outerJoinConditions.add(null);
            builder.put((Object)newInputIndex, (Object)ImmutableIntList.of());
            projFields.add(null);
            ++newInputIndex;
            for (final int qRelIndex : this.queryInputIndicesThatDidNotMatch) {
                if (qRelIndex == 0 && alreadyAddedZerothQueryInput) {
                    continue;
                }
                this.addQueryMultiJoinInput(query, qRelIndex, newInputIndex, inputRels, inputs, joinTypes, fields, outerJoinConditions, projFields, builder);
                ++newInputIndex;
            }
            if (alreadyAddedZerothQueryInput) {
                this.buildFinalPermutation(query, (RelNode)target);
            }
            else {
                this.finalPermutation = (Mapping)Mappings.createIdentity(fields.size());
            }
            final MultiJoin newMultiJoin = new MultiJoin(query.getCluster(), (List)inputRels, (RexNode)rexBuilder.makeLiteral(true), (RelDataType)new RelRecordType((List)fields), query.isFullOuterJoin(), RexPermuteInputsShuttle.of((Mappings.TargetMapping)this.finalPermutation).apply((List)outerJoinConditions), (List)joinTypes, (List)projFields, builder.build(), (RexNode)null);
            return (RelNode)new MunifyCreatedLateBlock(targetWithIdentityProject, newMultiJoin);
        }
        
        private void buildFinalPermutation(final MultiJoin query, final RelNode target) {
            final List<Integer> mapping = new ArrayList<Integer>();
            for (int i = 0; i < query.getInput(0).getRowType().getFieldCount(); ++i) {
                mapping.add(i + target.getRowType().getFieldCount());
            }
            for (int i = 0; i < target.getRowType().getFieldCount(); ++i) {
                mapping.add(i);
            }
            int index = mapping.size();
            for (final int qRelIndex : this.queryInputIndicesThatDidNotMatch) {
                if (qRelIndex == 0) {
                    continue;
                }
                for (int j = 0; j < query.getInput(qRelIndex).getRowType().getFieldCount(); ++j) {
                    mapping.add(index);
                    ++index;
                }
            }
            final Permutation permutation = new Permutation(mapping.size());
            Ord.zip((List)mapping).forEach(ord -> permutation.set((int)ord.e, ord.i, true));
            this.finalPermutation = (Mapping)permutation;
        }
    }
}
