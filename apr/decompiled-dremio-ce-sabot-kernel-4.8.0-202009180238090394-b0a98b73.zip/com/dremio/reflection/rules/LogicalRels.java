package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import java.util.*;
import org.apache.calcite.util.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.rules.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.sql.validate.*;
import org.apache.calcite.rex.*;
import java.util.stream.*;
import org.apache.calcite.rel.type.*;

public final class LogicalRels
{
    public static List<RelNode> descendants(final RelNode query) {
        final List<RelNode> list = new ArrayList<RelNode>();
        descendantsRecurse(list, query);
        return list;
    }
    
    private static void descendantsRecurse(final List<RelNode> list, final RelNode rel) {
        list.add(rel);
        for (final RelNode input : rel.getInputs()) {
            descendantsRecurse(list, input);
        }
    }
    
    public static boolean equalType(final String desc0, final RelNode rel0, final String desc1, final RelNode rel1, final Litmus litmus) {
        return RelOptUtil.equal(desc0, rel0.getRowType(), desc1, rel1.getRowType(), litmus);
    }
    
    public static RelNode strip(final LogicalProject project) {
        return ProjectRemoveRule.strip((Project)project);
    }
    
    private static boolean isTrivial(final LogicalProject project) {
        return ProjectRemoveRule.isTrivial((Project)project);
    }
    
    public static LogicalProject createProject(final RelNode child, final List<RexNode> exprList, final List<String> fieldNameList) {
        final RelDataType rowType = RexUtil.createStructType(child.getCluster().getTypeFactory(), (List)exprList, (List)fieldNameList, SqlValidatorUtil.F_SUGGESTER);
        return createProject(rowType, child, exprList);
    }
    
    public static RelNode createProject(final RelNode child, final List<Integer> posList) {
        return RelOptUtil.createProject(child, (List)posList);
    }
    
    public static RelNode createIdentityProject(final RelNode child) {
        final List<RexNode> projects = (List<RexNode>)child.getRowType().getFieldList().stream().map(f -> new RexInputRef(f.getIndex(), f.getType())).collect(Collectors.toList());
        return (RelNode)LogicalProject.create(child, (List)projects, child.getRowType());
    }
    
    public static RelNode createCastRel(final RelNode rel, final RelDataType castRowType, final boolean rename) {
        final RelDataType rowType = rel.getRowType();
        if (RelOptUtil.areRowTypesEqual(rowType, castRowType, rename)) {
            return rel;
        }
        final List<RexNode> castExps = (List<RexNode>)RexUtil.generateCastExpressions(rel.getCluster().getRexBuilder(), castRowType, rowType);
        final List<String> fieldNames = (List<String>)(rename ? castRowType.getFieldNames() : rowType.getFieldNames());
        return RelOptUtil.createProject(rel, (List)castExps, (List)fieldNames);
    }
    
    public static LogicalProject createProject(final RelDataType rowType, final RelNode input, final List<RexNode> expressions) {
        return new LogicalProject(input.getCluster(), input.getTraitSet(), input, (List)expressions, rowType);
    }
}
