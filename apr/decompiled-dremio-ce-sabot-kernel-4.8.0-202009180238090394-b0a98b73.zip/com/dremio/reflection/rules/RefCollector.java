package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rex.*;
import java.util.*;
import com.google.common.collect.*;
import com.google.common.base.*;
import javax.annotation.*;

public class RefCollector extends RexShuttle
{
    private final RelNode input;
    private final Set<RexInputRef> refs;
    private final Set<RexInputRef> literalRefs;
    
    public RefCollector(final RelNode input) {
        this.refs = (Set<RexInputRef>)Sets.newHashSet();
        this.literalRefs = (Set<RexInputRef>)Sets.newHashSet();
        this.input = input;
    }
    
    public RexNode visitInputRef(final RexInputRef inputRef) {
        if (this.input == null || !(this.input instanceof LogicalProject) || (this.input instanceof LogicalProject && !(((LogicalProject)this.input).getProjects().get(inputRef.getIndex()) instanceof RexLiteral))) {
            this.refs.add(inputRef);
        }
        else if (this.input instanceof LogicalProject && ((LogicalProject)this.input).getProjects().get(inputRef.getIndex()) instanceof RexLiteral) {
            this.literalRefs.add(inputRef);
        }
        return super.visitInputRef(inputRef);
    }
    
    public Map<Integer, RexNode> getLiteralInputReferences() {
        final ImmutableMap.Builder<Integer, RexNode> inputMap = (ImmutableMap.Builder<Integer, RexNode>)ImmutableMap.builder();
        if (this.input instanceof LogicalProject) {
            final LogicalProject projectInput = (LogicalProject)this.input;
            for (final RexInputRef inputRef : this.literalRefs) {
                inputMap.put((Object)inputRef.getIndex(), (Object)projectInput.getProjects().get(inputRef.getIndex()));
            }
        }
        return (Map<Integer, RexNode>)inputMap.build();
    }
    
    public Set<RexInputRef> getReferences() {
        return (Set<RexInputRef>)ImmutableSet.copyOf((Collection)this.refs);
    }
    
    public Set<Integer> getReferenceIndices() {
        final Set<Integer> groupRefs = (Set<Integer>)FluentIterable.from((Iterable)this.getReferences()).transform((Function)new Function<RexInputRef, Integer>() {
            @Nullable
            public Integer apply(@Nullable final RexInputRef input) {
                return input.getIndex();
            }
        }).toSet();
        return groupRefs;
    }
}
