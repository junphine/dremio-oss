package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.plan.*;
import com.dremio.reflection.bup.*;
import org.apache.calcite.rel.core.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.rel.type.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.calcite.sql.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.util.*;
import org.apache.calcite.rel.*;

public final class WindowToWindowUnifyRule extends AbstractUnifyRule
{
    public static final WindowToWindowUnifyRule INSTANCE;
    
    private WindowToWindowUnifyRule() {
        super("W => W", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalWindow.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalWindow.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalWindow target = (LogicalWindow)call.target;
        final LogicalWindow query = (LogicalWindow)call.query;
        if (RelOptUtil.areRowTypesEqual(target.getRowType(), query.getRowType(), false) && query.getDigest().equals(target.getDigest())) {
            return null;
        }
        final RelNode unified = unify(target, query, call.reflection);
        if (unified != null) {
            return call.result(unified);
        }
        return null;
    }
    
    static RelNode unify(final LogicalWindow target, final LogicalWindow query, final ReflectionPtr reflection) {
        final Map<String, Integer> targetAggCallMap = new HashMap<String, Integer>();
        int cnt = 0;
        for (final Window.Group group : target.groups) {
            for (final Window.RexWinAggCall aggCall : group.aggCalls) {
                final GroupKey key = getGroupKey(group, aggCall, target);
                targetAggCallMap.put(key.toString(), cnt++);
            }
        }
        final org.apache.calcite.tools.RelBuilder relBuilder = RelBuilder.newCalciteRelBuilderWithoutContext(query.getCluster());
        relBuilder.push((RelNode)reflection);
        final List<RexNode> projects = new ArrayList<RexNode>();
        final List<String> fieldNames = new ArrayList<String>();
        for (final RelDataTypeField field : query.getInput().getRowType().getFieldList()) {
            projects.add((RexNode)relBuilder.field(field.getIndex()));
            fieldNames.add(field.getName());
        }
        final int inputFieldCount = query.getInput().getRowType().getFieldCount();
        for (final Window.Group group2 : query.groups) {
            for (final Window.RexWinAggCall aggCall2 : group2.aggCalls) {
                final GroupKey key2 = getGroupKey(group2, aggCall2, query);
                final Integer targetIndex = targetAggCallMap.get(key2.toString());
                if (targetIndex == null) {
                    return null;
                }
                projects.add((RexNode)relBuilder.field(inputFieldCount + targetIndex));
                fieldNames.add(query.getRowType().getFieldList().get(inputFieldCount + targetIndex).getName());
            }
        }
        return relBuilder.project((Iterable)projects, (Iterable)fieldNames).build();
    }
    
    private static GroupKey getGroupKey(final Window.Group group, final Window.RexWinAggCall aggCall, final LogicalWindow window) {
        final int inputFieldCount = window.getInput().getRowType().getFieldCount();
        final RexShuttle shuttle = new RexShuttle() {
            public RexNode visitInputRef(final RexInputRef inputRef) {
                return (RexNode)((inputRef.getIndex() < inputFieldCount) ? inputRef : ((RexNode)window.constants.get(inputRef.getIndex() - inputFieldCount)));
            }
        };
        final RexWindowBound lowerBound = group.lowerBound.accept((RexVisitor)shuttle);
        final RexWindowBound upperBound = group.upperBound.accept((RexVisitor)shuttle);
        final RexCall rexCall = (RexCall)aggCall.accept((RexVisitor)shuttle);
        final Window.RexWinAggCall newAggCall = new Window.RexWinAggCall((SqlAggFunction)rexCall.getOperator(), rexCall.getType(), rexCall.getOperands(), aggCall.ordinal, aggCall.distinct);
        return new GroupKey(group.keys, group.isRows, lowerBound, upperBound, group.orderKeys, newAggCall);
    }
    
    static {
        INSTANCE = new WindowToWindowUnifyRule();
    }
    
    private static class GroupKey
    {
        private final ImmutableBitSet keys;
        private final boolean isRows;
        private final RexWindowBound lowerBound;
        private final RexWindowBound upperBound;
        private final RelCollation orderKeys;
        private final Window.RexWinAggCall aggCall;
        
        public GroupKey(final ImmutableBitSet keys, final boolean isRows, final RexWindowBound lowerBound, final RexWindowBound upperBound, final RelCollation orderKeys, final Window.RexWinAggCall aggCall) {
            this.keys = keys;
            this.isRows = isRows;
            this.lowerBound = lowerBound;
            this.upperBound = upperBound;
            this.orderKeys = orderKeys;
            this.aggCall = aggCall;
        }
        
        @Override
        public String toString() {
            final StringBuilder buf = new StringBuilder();
            buf.append("window(partition ");
            buf.append(this.keys);
            buf.append(" order by ");
            buf.append(this.orderKeys);
            buf.append(this.isRows ? " rows " : " range ");
            if (this.lowerBound != null) {
                if (this.upperBound != null) {
                    buf.append("between ");
                    buf.append(this.lowerBound);
                    buf.append(" and ");
                    buf.append(this.upperBound);
                }
                else {
                    buf.append(this.lowerBound);
                }
            }
            else if (this.upperBound != null) {
                buf.append(this.upperBound);
            }
            buf.append(" agg ");
            buf.append(this.aggCall);
            buf.append(")");
            return buf.toString();
        }
    }
}
