package com.dremio.reflection.rules;

import org.apache.calcite.rel.rules.*;
import org.apache.calcite.plan.*;
import java.util.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rel.*;
import com.dremio.exec.planner.*;

public class MunifyCreatedLateBlock extends SingleRel
{
    public static final Resolver MUNIFY_LATE_BLOCK_RESOLVER;
    private final MultiJoin multiJoin;
    
    public MunifyCreatedLateBlock(final RelNode child, final MultiJoin multiJoin) {
        super(child.getCluster(), child.getTraitSet(), child);
        this.multiJoin = multiJoin;
    }
    
    public RelNode copy(final RelTraitSet traitSet, final List<RelNode> inputs) {
        return (RelNode)new MunifyCreatedLateBlock(inputs.get(0), this.multiJoin);
    }
    
    protected RelDataType deriveRowType() {
        return this.multiJoin.getRowType();
    }
    
    public RelNode resolve() {
        return this.multiJoin.accept((RelShuttle)new InputPointerResolver());
    }
    
    static {
        MUNIFY_LATE_BLOCK_RESOLVER = new Resolver();
    }
    
    public static class InputPointer extends AbstractRelNode
    {
        public InputPointer(final RelNode node) {
            super(node.getCluster(), node.getTraitSet());
        }
    }
    
    public static class Resolver extends RoutingShuttle
    {
        public RelNode visit(final RelNode other) {
            if (other instanceof MunifyCreatedLateBlock) {
                return ((MunifyCreatedLateBlock)other).resolve();
            }
            return super.visit(other);
        }
    }
    
    public class InputPointerResolver extends RoutingShuttle
    {
        public RelNode visit(final RelNode other) {
            if (other instanceof InputPointer) {
                return MunifyCreatedLateBlock.this.getInput();
            }
            return super.visit(other);
        }
    }
}
