package com.dremio.reflection.rules;

import com.dremio.exec.calcite.logical.*;
import org.apache.calcite.rel.*;
import com.dremio.service.namespace.*;
import org.apache.calcite.util.mapping.*;
import org.apache.calcite.linq4j.*;
import org.apache.calcite.plan.*;
import java.util.*;
import com.dremio.common.expression.*;

public final class ScanToScanUnifyRule extends AbstractUnifyRule
{
    public static final ScanToScanUnifyRule INSTANCE;
    
    private ScanToScanUnifyRule() {
        super("S => S", AbstractUnifyRule.operand((Class<? extends RelNode>)ScanCrel.class), AbstractUnifyRule.operand((Class<? extends RelNode>)ScanCrel.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final ScanCrel target = (ScanCrel)call.target;
        final ScanCrel query = (ScanCrel)call.query;
        try {
            final boolean unifiable = query.getTableMetadata().getName().equals((Object)target.getTableMetadata().getName()) && !query.getProjectedSchema().equals((Object)target.getProjectedSchema()) && !query.getTableMetadata().isPruned() && !target.getTableMetadata().isPruned();
            if (!unifiable) {
                return null;
            }
        }
        catch (NamespaceException e) {
            return null;
        }
        final Mappings.TargetMapping mapping = (Mappings.TargetMapping)Mappings.create(MappingType.SURJECTION, target.getRowType().getFieldCount(), query.getRowType().getFieldCount());
        for (final Ord<SchemaPath> queryColumn : Ord.zip(query.getProjectedColumns())) {
            final int indexOf = target.getProjectedColumns().indexOf(queryColumn.e);
            if (indexOf < 0) {
                return null;
            }
            mapping.set(indexOf, queryColumn.i);
        }
        final RelNode newProject = RelOptUtil.createProject((RelNode)call.reflection, mapping);
        return call.result(newProject);
    }
    
    static {
        INSTANCE = new ScanToScanUnifyRule();
    }
}
