package com.dremio.reflection.rules;

import org.apache.calcite.plan.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.sql.fun.*;
import com.google.common.collect.*;
import org.apache.calcite.sql.type.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import java.util.*;

public final class AddDummyAggFunctionRule extends RelOptRule
{
    public static final AddDummyAggFunctionRule INSTANCE;
    
    private AddDummyAggFunctionRule() {
        super(operand((Class)Aggregate.class, any()));
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rel(0);
        if (aggregate.getAggCallList().size() > 0) {
            return;
        }
        final org.apache.calcite.tools.RelBuilder relBuilder = RelBuilder.newCalciteRelBuilderWithoutContext(aggregate.getCluster());
        relBuilder.push(aggregate.getInput());
        final org.apache.calcite.tools.RelBuilder.GroupKey groupKey = relBuilder.groupKey(aggregate.getGroupSet(), aggregate.getGroupSets());
        final List<AggregateCall> newAggCallList = new ArrayList<AggregateCall>();
        newAggCallList.add(AggregateCall.create(SqlStdOperatorTable.COUNT, false, false, (List)ImmutableList.of(), -1, aggregate.getCluster().getTypeFactory().createSqlType(SqlTypeName.BIGINT), "COUNT"));
        relBuilder.aggregate(groupKey, (List)newAggCallList);
        final RelNode newAggregate = relBuilder.build();
        final List<RexInputRef> inputRefs = new ArrayList<RexInputRef>();
        for (final RelDataTypeField field : aggregate.getRowType().getFieldList()) {
            inputRefs.add(new RexInputRef(field.getIndex(), field.getType()));
        }
        final LogicalProject topProject = LogicalProject.create(newAggregate, (List)inputRefs, aggregate.getRowType());
        call.transformTo((RelNode)topProject);
    }
    
    static {
        INSTANCE = new AddDummyAggFunctionRule();
    }
}
