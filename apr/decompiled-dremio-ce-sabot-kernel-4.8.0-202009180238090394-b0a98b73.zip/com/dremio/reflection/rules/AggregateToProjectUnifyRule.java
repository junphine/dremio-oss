package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.rel.logical.*;
import com.google.common.collect.*;
import java.util.*;

public final class AggregateToProjectUnifyRule extends AbstractUnifyRule
{
    public static final AggregateToProjectUnifyRule INSTANCE;
    
    private AggregateToProjectUnifyRule() {
        super("A => P", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalAggregate.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalAggregate query = (LogicalAggregate)call.query;
        final LogicalProject target = (LogicalProject)call.target;
        final LogicalProject dummy = (LogicalProject)LogicalRels.createIdentityProject(query.getInput());
        final UnifyRule projectRule = ProjectToProjectUnifyRule.INSTANCE;
        final UnifyResult r1 = projectRule.apply(UnifyRuleCall.createCall(call.getTracer(), projectRule, (RelNode)dummy, (RelNode)target, call.reflection));
        if (r1 == null) {
            return null;
        }
        if (!(r1.result instanceof LogicalProject)) {
            return null;
        }
        final LogicalProject newProject = (LogicalProject)r1.result;
        return call.result(query.copy(query.getTraitSet(), (List)ImmutableList.of((Object)newProject)));
    }
    
    static {
        INSTANCE = new AggregateToProjectUnifyRule();
    }
}
