package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.plan.*;
import com.dremio.reflection.bup.*;
import org.apache.calcite.rex.*;
import com.dremio.exec.planner.acceleration.normalization.rules.*;
import org.apache.calcite.rel.core.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.calcite.rel.type.*;

public final class AggregateOnProjectOnFilterToAggregateUnifyRule extends AbstractUnifyRule
{
    public static final AggregateOnProjectOnFilterToAggregateUnifyRule INSTANCE;
    
    private AggregateOnProjectOnFilterToAggregateUnifyRule() {
        super("A.P.F => A", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalAggregate.class, AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class, AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalFilter.class))), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalAggregate.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalAggregate query = (LogicalAggregate)call.query;
        final LogicalProject project = (LogicalProject)query.getInput();
        final LogicalFilter filter = (LogicalFilter)project.getInput();
        final LogicalAggregate target = (LogicalAggregate)call.target;
        final RexShuttle shuttle = getRexShuttle(target);
        try {
            final RexNode newCondition = shuttle.apply(filter.getCondition());
            final LogicalProject newProject = LogicalRels.createProject(project.getRowType(), target.getInput(), project.getProjects());
            final LogicalAggregate newAggregate = new LogicalAggregate(newProject.getCluster(), (RelNode)newProject, query.indicator, query.getGroupSet(), (List)query.getGroupSets(), query.getAggCallList());
            final UnifyRule rule = AggregateOnProjectToAggregateUnifyRule.INSTANCE;
            final UnifyResult unified = rule.apply(UnifyRuleCall.createCall(call.getTracer(), rule, (RelNode)newAggregate, (RelNode)target, call.reflection));
            if (unified == null) {
                return null;
            }
            final RelNode newFilter = RelOptUtil.createFilter((RelNode)call.reflection, newCondition);
            final RelNode finalResult = ReplacementShuttle.replace(unified.result, (RelNode)call.reflection, newFilter);
            return call.result(finalResult);
        }
        catch (MatchFailed e) {
            return null;
        }
    }
    
    private static RexShuttle getRexShuttle(final LogicalAggregate target) {
        final Multimap<ComparableRexNode, Integer> mappings = (Multimap<ComparableRexNode, Integer>)ArrayListMultimap.create();
        int groupCount = 0;
        for (final Integer ref : target.getGroupSet()) {
            final String key = String.format("$%s", ref.toString());
            final RelDataType keyType = target.getRowType().getFieldList().get(groupCount).getType();
            mappings.put((Object)new ComparableRexNode(key, keyType), (Object)mappings.size());
            ++groupCount;
        }
        for (final AggregateCall call : target.getAggCallList()) {
            mappings.put((Object)new ComparableRexNode(call.toString(), call.getType()), (Object)mappings.size());
        }
        return new TargetMapper(mappings, (List<RexNode>)ImmutableList.of(), false);
    }
    
    static {
        INSTANCE = new AggregateOnProjectOnFilterToAggregateUnifyRule();
    }
}
