package com.dremio.reflection.rules;

import org.apache.calcite.util.*;

public class MatchFailed extends ControlFlowException
{
    public static final MatchFailed INSTANCE;
    
    static {
        INSTANCE = new MatchFailed();
    }
}
