package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.util.*;

public class UnifyResult
{
    public final UnifyRuleCall call;
    public final RelNode result;
    
    public UnifyResult(final UnifyRuleCall call, final RelNode result) {
        this.call = call;
        assert LogicalRels.equalType("query", call.query, "result", result, Litmus.THROW);
        this.result = result;
    }
}
