package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.plan.*;
import java.util.*;
import org.apache.calcite.rex.*;

public final class ProjectToProjectUnifyRule extends AbstractUnifyRule
{
    public static final ProjectToProjectUnifyRule INSTANCE;
    
    private ProjectToProjectUnifyRule() {
        super("P => P", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalProject target = (LogicalProject)call.target;
        final LogicalProject query = (LogicalProject)call.query;
        if (RelOptUtil.areRowTypesEqual(target.getRowType(), query.getRowType(), false) && target.getProjects().toString().equals(query.getProjects().toString())) {
            return null;
        }
        RexShuttle shuttle = TargetMapper.getRexShuttle(target, true);
        List<RexNode> newProjects;
        try {
            newProjects = (List<RexNode>)shuttle.apply(query.getProjects());
        }
        catch (MatchFailed e) {
            return null;
        }
        LogicalProject newProject = LogicalRels.createProject(query.getRowType(), (RelNode)call.reflection, newProjects);
        final RelNode newProject2 = LogicalRels.strip(newProject);
        if (newProject2 == newProject.getInput()) {
            return call.result(newProject2);
        }
        shuttle = TargetMapper.getRexShuttle(target, false);
        try {
            newProjects = (List<RexNode>)shuttle.apply(query.getProjects());
        }
        catch (MatchFailed e) {
            return null;
        }
        newProject = LogicalRels.createProject(query.getRowType(), (RelNode)call.reflection, newProjects);
        return call.result((RelNode)newProject);
    }
    
    static {
        INSTANCE = new ProjectToProjectUnifyRule();
    }
}
