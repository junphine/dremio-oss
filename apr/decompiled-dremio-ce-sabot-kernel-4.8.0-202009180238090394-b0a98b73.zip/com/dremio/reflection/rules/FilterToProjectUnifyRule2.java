package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.util.*;
import org.apache.calcite.linq4j.*;
import java.util.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.rex.*;

public final class FilterToProjectUnifyRule2 extends AbstractUnifyRule
{
    public static final FilterToProjectUnifyRule2 INSTANCE;
    
    private FilterToProjectUnifyRule2() {
        super("F > P", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalFilter.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        try {
            final LogicalProject target = (LogicalProject)call.target;
            final RexShuttle shuttle = TargetMapper.getRexShuttle(target);
            final LogicalFilter query = (LogicalFilter)call.query;
            RexNode newCondition;
            try {
                newCondition = (RexNode)query.getCondition().accept((RexVisitor)shuttle);
            }
            catch (MatchFailed e) {
                return null;
            }
            final LogicalFilter newFilter = (LogicalFilter)RelOptUtil.createFilter((RelNode)call.reflection, newCondition);
            final RelNode inverse = this.invert((RelNode)query, newFilter, target);
            return call.result(inverse);
        }
        catch (MatchFailed e2) {
            return null;
        }
    }
    
    private static RexNode makeZeroLiteral(final RexBuilder rexBuilder, final RelDataType dataType) {
        try {
            return rexBuilder.makeCast(dataType, (RexNode)rexBuilder.constantNull());
        }
        catch (AssertionError | RuntimeException assertionError) {
            final Throwable t;
            final Throwable e = t;
            throw MatchFailed.INSTANCE;
        }
    }
    
    protected RelNode invert(final List<Pair<RexNode, String>> namedProjects, final RelNode input, final RexShuttle shuttle) {
        final List<RexNode> exprList = new ArrayList<RexNode>();
        final RexBuilder rexBuilder = input.getCluster().getRexBuilder();
        final List<RexNode> projects = (List<RexNode>)Pair.left((List)namedProjects);
        for (final RexNode expr : projects) {
            exprList.add(makeZeroLiteral(rexBuilder, expr.getType()));
        }
        for (final Ord<RexNode> expr2 : Ord.zip((List)projects)) {
            final RexNode node = (RexNode)((RexNode)expr2.e).accept((RexVisitor)shuttle);
            if (node == null) {
                throw MatchFailed.INSTANCE;
            }
            exprList.set(expr2.i, node);
        }
        return RelOptUtil.createProject(input, (List)exprList, Pair.right((List)namedProjects));
    }
    
    protected RelNode invert(final RelNode model, final LogicalFilter input, final LogicalProject project) {
        if (project.getProjects().size() < model.getRowType().getFieldCount()) {
            throw MatchFailed.INSTANCE;
        }
        final List<RexNode> exprList = new ArrayList<RexNode>();
        final RexBuilder rexBuilder = model.getCluster().getRexBuilder();
        for (final RelDataTypeField field : model.getRowType().getFieldList()) {
            exprList.add(makeZeroLiteral(rexBuilder, field.getType()));
        }
        for (final Ord<RexNode> expr : Ord.zip(project.getProjects())) {
            if (!(expr.e instanceof RexInputRef)) {
                throw MatchFailed.INSTANCE;
            }
            final int target = ((RexInputRef)expr.e).getIndex();
            exprList.set(target, rexBuilder.ensureType(((RexNode)expr.e).getType(), (RexNode)RexInputRef.of(expr.i, input.getRowType()), false));
        }
        return (RelNode)LogicalRels.createProject(model.getRowType(), (RelNode)input, exprList);
    }
    
    static {
        INSTANCE = new FilterToProjectUnifyRule2();
    }
}
