package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.util.*;
import org.apache.calcite.linq4j.*;
import org.apache.calcite.util.mapping.*;
import com.google.common.base.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rel.metadata.*;
import java.util.*;
import com.google.common.collect.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.sql.*;

public final class DremioAggregateJoinTransposeRule extends RelOptRule
{
    public static final DremioAggregateJoinTransposeRule INSTANCE;
    
    private DremioAggregateJoinTransposeRule(final Class<? extends Aggregate> aggregateClass, final Class<? extends Join> joinClass, final RelBuilderFactory relBuilderFactory) {
        super(operand((Class)aggregateClass, (RelTrait)null, Aggregate.IS_SIMPLE, operand((Class)joinClass, any()), new RelOptRuleOperand[0]), relBuilderFactory, (String)null);
    }
    
    public static boolean supportsSplitting(final AggregateCall aggregateCall) {
        switch (aggregateCall.getAggregation().getKind()) {
            case SUM:
            case SUM0:
            case COUNT:
            case MAX:
            case MIN: {
                return aggregateCall.filterArg < 0;
            }
            default: {
                return false;
            }
        }
    }
    
    public static boolean supportsSplitting(final Iterable<AggregateCall> calls) {
        for (final AggregateCall call : calls) {
            if (!supportsSplitting(call)) {
                return false;
            }
        }
        return true;
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate aggregate = (Aggregate)call.rel(0);
        final Join join = (Join)call.rel(1);
        final RexBuilder rexBuilder = aggregate.getCluster().getRexBuilder();
        final RelBuilder relBuilder = call.builder();
        if (!supportsSplitting(aggregate.getAggCallList())) {
            return;
        }
        final ImmutableBitSet aggregateColumns = aggregate.getGroupSet();
        final RelMetadataQuery mq = aggregate.getCluster().getMetadataQuery();
        final ImmutableBitSet keyColumns = keyColumns(aggregateColumns, (ImmutableList<RexNode>)mq.getPulledUpPredicates((RelNode)join).pulledUpPredicates);
        final ImmutableBitSet joinColumns = RelOptUtil.InputFinder.bits(join.getCondition());
        final boolean allColumnsInAggregate = keyColumns.contains(joinColumns);
        final ImmutableBitSet belowAggregateColumns = aggregateColumns.union(joinColumns);
        final List<Integer> leftKeys = (List<Integer>)Lists.newArrayList();
        final List<Integer> rightKeys = (List<Integer>)Lists.newArrayList();
        final List<Boolean> filterNulls = (List<Boolean>)Lists.newArrayList();
        final RexNode nonEquiConj = RelOptUtil.splitJoinCondition(join.getLeft(), join.getRight(), join.getCondition(), (List)leftKeys, (List)rightKeys, (List)filterNulls);
        if (!nonEquiConj.isAlwaysTrue()) {
            return;
        }
        final Map<Integer, Integer> map = new HashMap<Integer, Integer>();
        final List<Side> sides = new ArrayList<Side>();
        int uniqueCount = 0;
        int offset = 0;
        int belowOffset = 0;
        for (int s = 0; s < 2; ++s) {
            final Side side = new Side();
            final RelNode joinInput = join.getInput(s);
            final int fieldCount = joinInput.getRowType().getFieldCount();
            final ImmutableBitSet fieldSet = ImmutableBitSet.range(offset, offset + fieldCount);
            final ImmutableBitSet belowAggregateKeyNotShifted = belowAggregateColumns.intersect(fieldSet);
            for (final Ord<Integer> c : Ord.zip((Iterable)belowAggregateKeyNotShifted)) {
                map.put((Integer)c.e, belowOffset + c.i);
            }
            final ImmutableBitSet belowAggregateKey = belowAggregateKeyNotShifted.shift(-offset);
            final Boolean unique0 = mq.areColumnsUnique(joinInput, belowAggregateKey);
            final boolean unique2 = unique0 != null && unique0;
            if (unique2) {
                ++uniqueCount;
            }
            side.aggregate = true;
            final List<AggregateCall> belowAggCalls = new ArrayList<AggregateCall>();
            final AggSplitters.Registry<AggregateCall> belowAggCallRegistry = aggregateCallRegistry(belowAggCalls);
            final Mappings.TargetMapping mapping = (Mappings.TargetMapping)((s == 0) ? Mappings.createIdentity(fieldCount) : Mappings.createShiftMapping(fieldCount + offset, new int[] { 0, offset, fieldCount }));
            for (final Ord<AggregateCall> aggCall : Ord.zip(aggregate.getAggCallList())) {
                final SqlAggFunction aggregation = ((AggregateCall)aggCall.e).getAggregation();
                final AggSplitters.Splitter splitter = (AggSplitters.Splitter)Preconditions.checkNotNull((Object)AggSplitters.getSplitter(aggregation));
                AggregateCall call2;
                if (fieldSet.contains(ImmutableBitSet.of((Iterable)((AggregateCall)aggCall.e).getArgList()))) {
                    call2 = splitter.split((AggregateCall)aggCall.e, mapping);
                }
                else {
                    call2 = splitter.other(rexBuilder.getTypeFactory(), (AggregateCall)aggCall.e);
                    if (call2 != null) {
                        side.other = true;
                    }
                }
                if (call2 != null) {
                    final SqlAggFunction projectableFunction = ProjectableSqlAggFunctions.toProjectableFunction(call2.getAggregation());
                    if (projectableFunction == null) {
                        return;
                    }
                    final AggregateCall projectableCall = AggregateCall.create(projectableFunction, call2.isDistinct(), call2.getArgList(), call2.filterArg, call2.getType(), call2.getName());
                    side.split.put(aggCall.i, belowAggregateKey.cardinality() + belowAggCallRegistry.register(projectableCall));
                }
            }
            side.newInput = relBuilder.push(joinInput).aggregate(relBuilder.groupKey(belowAggregateKey, false, (ImmutableList)null), (List)belowAggCalls).build();
            offset += fieldCount;
            belowOffset += side.newInput.getRowType().getFieldCount();
            sides.add(side);
        }
        if (uniqueCount == 2) {
            return;
        }
        final Mapping mapping2 = (Mapping)Mappings.target((Function)new Function<Integer, Integer>() {
            public Integer apply(final Integer a0) {
                return map.get(a0);
            }
        }, join.getRowType().getFieldCount(), belowOffset);
        final RexNode newCondition = RexUtil.apply((Mappings.TargetMapping)mapping2, join.getCondition());
        relBuilder.push(sides.get(0).newInput).push(sides.get(1).newInput).join(join.getJoinType(), newCondition);
        final List<AggregateCall> newAggCalls = new ArrayList<AggregateCall>();
        final int groupIndicatorCount = aggregate.getGroupCount() + aggregate.getIndicatorCount();
        final int newLeftWidth = sides.get(0).newInput.getRowType().getFieldCount();
        final List<RexNode> projects = new ArrayList<RexNode>(rexBuilder.identityProjects(relBuilder.peek().getRowType()));
        for (final Ord<AggregateCall> aggCall2 : Ord.zip(aggregate.getAggCallList())) {
            final SqlAggFunction aggregation2 = ((AggregateCall)aggCall2.e).getAggregation();
            final AggSplitters.Splitter splitter2 = (AggSplitters.Splitter)Preconditions.checkNotNull((Object)AggSplitters.getSplitter(aggregation2));
            final Integer leftSubTotal = sides.get(0).split.get(aggCall2.i);
            final Integer rightSubTotal = sides.get(1).split.get(aggCall2.i);
            final boolean handleNullOnLeft = sides.get(0).other && (join.getJoinType() == JoinRelType.RIGHT || join.getJoinType() == JoinRelType.FULL);
            final boolean handleNullOnRight = sides.get(1).other && (join.getJoinType() == JoinRelType.LEFT || join.getJoinType() == JoinRelType.FULL);
            newAggCalls.add(splitter2.topSplit(rexBuilder, rexNodeRegistry(projects), groupIndicatorCount, relBuilder.peek().getRowType(), (AggregateCall)aggCall2.e, join.getJoinType(), (leftSubTotal == null) ? -1 : ((int)leftSubTotal), (rightSubTotal == null) ? -1 : (rightSubTotal + newLeftWidth), handleNullOnLeft, handleNullOnRight, ((AggregateCall)aggCall2.e).getAggregation() instanceof ProjectableSqlAggFunction));
        }
        relBuilder.project((Iterable)projects);
        final RelNode newProject = relBuilder.build();
        final LogicalAggregate aggregate2 = LogicalAggregate.create(newProject, aggregate.indicator, Mappings.apply(mapping2, aggregate.getGroupSet()), (List)Mappings.apply2(mapping2, (Iterable)aggregate.getGroupSets()), (List)newAggCalls);
        call.transformTo((RelNode)aggregate2);
    }
    
    private static ImmutableBitSet keyColumns(final ImmutableBitSet aggregateColumns, final ImmutableList<RexNode> predicates) {
        final SortedMap<Integer, BitSet> equivalence = new TreeMap<Integer, BitSet>();
        for (final RexNode predicate : predicates) {
            populateEquivalences(equivalence, predicate);
        }
        ImmutableBitSet keyColumns = aggregateColumns;
        for (final Integer aggregateColumn : aggregateColumns) {
            final BitSet bitSet = equivalence.get(aggregateColumn);
            if (bitSet != null) {
                keyColumns = keyColumns.union(bitSet);
            }
        }
        return keyColumns;
    }
    
    private static void populateEquivalences(final Map<Integer, BitSet> equivalence, final RexNode predicate) {
        switch (predicate.getKind()) {
            case EQUALS: {
                final RexCall call = (RexCall)predicate;
                final List<RexNode> operands = (List<RexNode>)call.getOperands();
                if (operands.get(0) instanceof RexInputRef) {
                    final RexInputRef ref0 = (RexInputRef)operands.get(0);
                    if (operands.get(1) instanceof RexInputRef) {
                        final RexInputRef ref2 = (RexInputRef)operands.get(1);
                        populateEquivalence(equivalence, ref0.getIndex(), ref2.getIndex());
                        populateEquivalence(equivalence, ref2.getIndex(), ref0.getIndex());
                    }
                    break;
                }
                break;
            }
        }
    }
    
    private static void populateEquivalence(final Map<Integer, BitSet> equivalence, final int i0, final int i1) {
        BitSet bitSet = equivalence.get(i0);
        if (bitSet == null) {
            bitSet = new BitSet();
            equivalence.put(i0, bitSet);
        }
        bitSet.set(i1);
    }
    
    private static AggSplitters.Registry<RexNode> rexNodeRegistry(final List<RexNode> list) {
        return new AggSplitters.RexNodeRegistry(list);
    }
    
    private static AggSplitters.Registry<AggregateCall> aggregateCallRegistry(final List<AggregateCall> list) {
        return new AggSplitters.AggregateCallRegistry(list);
    }
    
    static {
        INSTANCE = new DremioAggregateJoinTransposeRule((Class<? extends Aggregate>)LogicalAggregate.class, (Class<? extends Join>)LogicalJoin.class, RelFactories.LOGICAL_BUILDER);
    }
    
    private static class Side
    {
        final Map<Integer, Integer> split;
        RelNode newInput;
        boolean aggregate;
        boolean other;
        
        private Side() {
            this.split = new HashMap<Integer, Integer>();
        }
    }
}
