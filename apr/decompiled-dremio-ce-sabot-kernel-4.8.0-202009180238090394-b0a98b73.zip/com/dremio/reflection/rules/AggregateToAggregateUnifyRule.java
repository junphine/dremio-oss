package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.type.*;
import com.dremio.reflection.bup.*;
import org.apache.calcite.rel.core.*;
import com.dremio.exec.planner.acceleration.normalization.rules.*;
import org.apache.calcite.util.*;
import org.apache.calcite.sql.fun.*;
import com.google.common.collect.*;
import org.apache.calcite.plan.*;
import java.util.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.sql.*;
import com.dremio.exec.expr.fn.hll.*;

public final class AggregateToAggregateUnifyRule extends AbstractUnifyRule
{
    public static final AggregateToAggregateUnifyRule INSTANCE;
    
    private AggregateToAggregateUnifyRule() {
        super("A => A", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalAggregate.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalAggregate.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalAggregate query = (LogicalAggregate)call.query;
        final LogicalAggregate target = (LogicalAggregate)call.target;
        assert query != target;
        if (query.groupSets.equals((Object)target.groupSets) && query.getAggCallList().toString().equals(target.getAggCallList().toString())) {
            return null;
        }
        if (!target.getGroupSet().contains(query.getGroupSet())) {
            return null;
        }
        final RelNode result = unifyAggregates(query, target, call.reflection);
        if (result == null) {
            return null;
        }
        return call.result(result);
    }
    
    private static Pair<Integer, RelDataType> getCountLiteral(final LogicalAggregate target) {
        int countLiteral = -1;
        RelDataType countLiteralType = null;
        for (int index = 0; index < target.getAggCallList().size(); ++index) {
            final AggregateCall aggregateCall = target.getAggCallList().get(index);
            if (aggregateCall.getAggregation().getKind() == SqlKind.COUNT && aggregateCall.getArgList().size() == 1 && target.getInput() instanceof LogicalProject && ((LogicalProject)target.getInput()).getProjects().get(aggregateCall.getArgList().get(0)).getKind() == SqlKind.LITERAL) {
                countLiteral = target.getGroupSet().cardinality() + index;
                countLiteralType = target.getRowType().getFieldList().get(countLiteral).getType();
                break;
            }
        }
        if (countLiteral != -1 && countLiteralType != null) {
            return (Pair<Integer, RelDataType>)Pair.of((Object)countLiteral, (Object)countLiteralType);
        }
        return (Pair<Integer, RelDataType>)Pair.of((Object)(-1), (Object)null);
    }
    
    public static RelNode unifyAggregates(final LogicalAggregate query, final LogicalAggregate target, final ReflectionPtr reflection) {
        if (query.getGroupType() != Aggregate.Group.SIMPLE || target.getGroupType() != Aggregate.Group.SIMPLE) {
            throw new AssertionError(false);
        }
        RelNode result;
        if (query.getGroupSet().equals((Object)target.getGroupSet())) {
            final List<Integer> projects = (List<Integer>)Lists.newArrayList();
            final int groupCount = query.getGroupSet().cardinality();
            for (int i = 0; i < groupCount; ++i) {
                projects.add(i);
            }
            for (final AggregateCall aggregateCall : query.getAggCallList()) {
                final int j = ProjectableSqlAggFunctions.indexOfMatchingCall(aggregateCall, target.getAggCallList());
                if (j < 0) {
                    return null;
                }
                projects.add(groupCount + j);
            }
            result = LogicalRels.createProject((RelNode)reflection, projects);
        }
        else {
            final Map<ComparableRexNode, Integer> rollUpAggInputMap = new HashMap<ComparableRexNode, Integer>();
            final ImmutableBitSet.Builder groupSet = ImmutableBitSet.builder();
            final List<Integer> targetGroupList = (List<Integer>)target.getGroupSet().asList();
            final List<RexNode> projectBelowRollUp = (List<RexNode>)Lists.newArrayList();
            for (final int c : query.getGroupSet()) {
                final int c2 = targetGroupList.indexOf(c);
                RexNode groupRexNode;
                if (c2 < 0) {
                    if (!(query.getInput() instanceof LogicalProject)) {
                        return null;
                    }
                    final RexNode literalRexNode = ((LogicalProject)query.getInput()).getProjects().get(c);
                    if (literalRexNode.getKind() != SqlKind.LITERAL) {
                        return null;
                    }
                    groupRexNode = literalRexNode;
                }
                else {
                    groupRexNode = (RexNode)RexInputRef.of(c2, target.getRowType());
                }
                final ComparableRexNode groupRexNodeComparable = new ComparableRexNode(groupRexNode);
                if (!rollUpAggInputMap.containsKey(groupRexNodeComparable)) {
                    rollUpAggInputMap.put(groupRexNodeComparable, projectBelowRollUp.size());
                    projectBelowRollUp.add(groupRexNode);
                }
                final int groupInput = rollUpAggInputMap.get(groupRexNodeComparable);
                groupSet.set(groupInput);
            }
            final List<AggregateCall> aggregateCalls = (List<AggregateCall>)Lists.newArrayList();
            final Pair<Integer, RelDataType> countLiteralInfo = getCountLiteral(target);
            final int countLiteral = (int)countLiteralInfo.getKey();
            final RelDataType countLiteralType = (RelDataType)countLiteralInfo.getValue();
            for (final AggregateCall aggregateCall2 : query.getAggCallList()) {
                if (aggregateCall2.isDistinct()) {
                    return null;
                }
                final int k = ProjectableSqlAggFunctions.indexOfMatchingCall(aggregateCall2, target.getAggCallList());
                RexNode aggCallInput;
                if (k < 0) {
                    if (countLiteral == -1 || aggregateCall2.getAggregation().getKind() != SqlKind.COUNT || aggregateCall2.getArgList().size() != 1) {
                        return null;
                    }
                    final int countInputArg = aggregateCall2.getArgList().get(0);
                    if (!target.getGroupSet().get(countInputArg)) {
                        return null;
                    }
                    final int ordinal = target.getGroupSet().indexOf(countInputArg);
                    final RelDataType relDataType = target.getRowType().getFieldList().get(ordinal).getType();
                    final RexBuilder rexbuilder = target.getCluster().getRexBuilder();
                    final RexNode condition = rexbuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NULL, new RexNode[] { rexbuilder.makeInputRef(relDataType, countInputArg) });
                    final RexNode countOneRef = (RexNode)rexbuilder.makeInputRef(countLiteralType, countLiteral);
                    aggCallInput = rexbuilder.makeCall((SqlOperator)SqlStdOperatorTable.CASE, new RexNode[] { condition, rexbuilder.makeZeroLiteral(countLiteralType), countOneRef });
                }
                else {
                    aggCallInput = (RexNode)RexInputRef.of(targetGroupList.size() + k, target.getRowType());
                }
                final ComparableRexNode aggCallInputComparable = new ComparableRexNode(aggCallInput);
                if (!rollUpAggInputMap.containsKey(aggCallInputComparable)) {
                    rollUpAggInputMap.put(aggCallInputComparable, projectBelowRollUp.size());
                    projectBelowRollUp.add(aggCallInput);
                }
                final int rollUpAggInput = rollUpAggInputMap.get(aggCallInputComparable);
                final SqlAggFunction rollup = getRollup(aggregateCall2.getAggregation());
                if (rollup == null) {
                    return null;
                }
                aggregateCalls.add(AggregateCall.create(rollup, aggregateCall2.isDistinct(), (List)ImmutableList.of((Object)rollUpAggInput), -1, aggregateCall2.type, aggregateCall2.name));
            }
            final RelNode belowRollUp = RelOptUtil.createProject((RelNode)reflection, (List)projectBelowRollUp, query.getRowType().getFieldNames());
            result = (RelNode)new LogicalAggregate(belowRollUp.getCluster(), belowRollUp, false, groupSet.build(), (List)null, (List)aggregateCalls);
        }
        return LogicalRels.createCastRel(result, query.getRowType(), true);
    }
    
    public static SqlAggFunction getRollup(final SqlAggFunction aggregation) {
        final SqlKind kind = aggregation.getKind();
        if (kind == SqlKind.SUM || kind == SqlKind.SUM0 || kind == SqlKind.MIN || kind == SqlKind.MAX) {
            return aggregation;
        }
        if (kind == SqlKind.COUNT) {
            if (aggregation == ProjectableSqlAggFunctions.PROJECTABLE_COUNT) {
                return (SqlAggFunction)ProjectableSqlAggFunctions.PROJECTABLE_SUM0;
            }
            return SqlStdOperatorTable.SUM0;
        }
        else {
            if (HyperLogLog.HLL.getName().equals(aggregation.getName())) {
                return HyperLogLog.HLL_MERGE;
            }
            return null;
        }
    }
    
    static {
        INSTANCE = new AggregateToAggregateUnifyRule();
    }
}
