package com.dremio.reflection.rules;

import org.apache.calcite.rel.rules.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.core.*;
import com.dremio.exec.planner.common.*;
import org.apache.calcite.linq4j.*;
import org.apache.calcite.rex.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.util.*;
import java.util.*;

public final class ProjectWithFlattenMergeRule extends ProjectMergeRule
{
    public static ProjectWithFlattenMergeRule INSTANCE;
    
    private ProjectWithFlattenMergeRule() {
        super(true, RelFactories.LOGICAL_BUILDER);
    }
    
    public boolean matches(final RelOptRuleCall call) {
        final Project topProject = call.getRelList().get(0);
        final Project bottomProject = call.getRelList().get(1);
        final ImmutableBitSet topProjectInputRefs = new MoreRelOptUtil.InputRefFinder().getInputRefs(topProject.getProjects());
        for (final Ord<RexNode> rexNode : Ord.zip(bottomProject.getProjects())) {
            if (FlattenVisitors.hasFlatten((RexNode)rexNode.e) && !topProjectInputRefs.get(rexNode.i)) {
                return false;
            }
        }
        return true;
    }
    
    static {
        ProjectWithFlattenMergeRule.INSTANCE = new ProjectWithFlattenMergeRule();
    }
}
