package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import com.dremio.reflection.bup.*;
import com.google.common.base.*;
import java.util.*;
import com.google.common.collect.*;
import org.apache.calcite.util.*;

public class MunifyRuleCall
{
    private final BupTracer tracer;
    private final MunifyRule rule;
    private final RelNode query;
    private final ReflectionPtr reflection;
    private final List<MunifyInput> inputs;
    private final RelNode target;
    
    public MunifyRuleCall(final BupTracer tracer, final MunifyRule rule, final RelNode query, final RelNode target, final ReflectionPtr reflection, final List<MunifyInput> inputs) {
        this.tracer = tracer;
        this.rule = (MunifyRule)Preconditions.checkNotNull((Object)rule);
        this.query = (RelNode)Preconditions.checkNotNull((Object)query);
        this.target = (RelNode)Preconditions.checkNotNull((Object)target);
        this.inputs = (List<MunifyInput>)ImmutableList.copyOf((Collection)Preconditions.checkNotNull((Object)inputs));
        this.reflection = reflection;
    }
    
    public MunifyResult result(final RelNode result) {
        assert LogicalRels.equalType("result", result, "query", this.query, Litmus.THROW);
        return new MunifyResult(this, result);
    }
    
    public boolean isTraceEnabled() {
        return this.tracer.isTraceEnabled();
    }
    
    public ReflectionPtr getReflection() {
        return this.reflection;
    }
    
    public List<MunifyInput> getInputs() {
        return this.inputs;
    }
    
    public BupTracer getTracer() {
        return this.tracer;
    }
    
    public MunifyRule getRule() {
        return this.rule;
    }
    
    public RelNode getQuery() {
        return this.query;
    }
    
    public RelNode getTarget() {
        return this.target;
    }
    
    public static class MunifyInput
    {
        private final int queryPosition;
        private final int targetPosition;
        private final RelNode input;
        private final ReflectionPtr reflection;
        
        public MunifyInput(final int queryPosition, final int targetPosition, final RelNode input, final ReflectionPtr reflection) {
            this.queryPosition = queryPosition;
            this.targetPosition = targetPosition;
            this.input = input;
            this.reflection = reflection;
        }
        
        public ReflectionPtr getReflection() {
            return this.reflection;
        }
        
        public int getQueryPosition() {
            return this.queryPosition;
        }
        
        public int getTargetPosition() {
            return this.targetPosition;
        }
        
        public RelNode getInput() {
            return this.input;
        }
        
        public boolean isIdentity() {
            return this.queryPosition == this.targetPosition && this.input instanceof ReflectionPtr;
        }
        
        @Override
        public String toString() {
            final StringBuilder builder = new StringBuilder();
            builder.append("MunifyInput [queryPosition=").append(this.queryPosition).append(", targetPosition=").append(this.targetPosition).append("]");
            return builder.toString();
        }
    }
}
