package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.util.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.linq4j.*;
import java.util.*;
import com.google.common.base.*;

public final class ProjectOnFilterToProjectUnifyRule extends AbstractUnifyRule
{
    public static final ProjectOnFilterToProjectUnifyRule INSTANCE;
    
    private ProjectOnFilterToProjectUnifyRule() {
        super("P.F > P", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class, AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalFilter.class)), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        try {
            final LogicalProject target = (LogicalProject)call.target;
            final TargetMapper shuttle = (TargetMapper)TargetMapper.getRexShuttle(target);
            final LogicalProject queryProject = (LogicalProject)call.query;
            final LogicalFilter queryFilter = (LogicalFilter)queryProject.getInput();
            RexNode newCondition;
            try {
                newCondition = (RexNode)queryFilter.getCondition().accept((RexVisitor)shuttle);
            }
            catch (MatchFailed e) {
                return null;
            }
            final LogicalFilter newFilter = (LogicalFilter)RelOptUtil.createFilter((RelNode)call.reflection, newCondition);
            final RelNode inverse = invert(queryProject.getNamedProjects(), (RelNode)newFilter, shuttle);
            return call.result(inverse);
        }
        catch (MatchFailed e2) {
            return null;
        }
    }
    
    private static RexNode makeZeroLiteral(final RexBuilder rexBuilder, final RelDataType dataType) {
        try {
            return rexBuilder.makeCast(dataType, (RexNode)rexBuilder.constantNull());
        }
        catch (AssertionError | RuntimeException assertionError) {
            final Throwable t;
            final Throwable e = t;
            throw MatchFailed.INSTANCE;
        }
    }
    
    private static RelNode invert(final List<Pair<RexNode, String>> namedProjects, final RelNode input, final TargetMapper shuttle) {
        final List<RexNode> exprList = new ArrayList<RexNode>();
        final RexBuilder rexBuilder = input.getCluster().getRexBuilder();
        final List<RexNode> projects = (List<RexNode>)Pair.left((List)namedProjects);
        for (final RexNode expr : projects) {
            exprList.add(makeZeroLiteral(rexBuilder, expr.getType()));
        }
        for (final Ord<RexNode> expr2 : Ord.zip((List)projects)) {
            final Optional<RexNode> val = shuttle.getReferenceWithFieldName((RexNode)expr2.e, (String)namedProjects.get(expr2.i).right);
            if (val.isPresent()) {
                exprList.set(expr2.i, (RexNode)val.get());
            }
            else {
                final RexNode node = (RexNode)((RexNode)expr2.e).accept((RexVisitor)shuttle);
                if (node == null) {
                    throw MatchFailed.INSTANCE;
                }
                exprList.set(expr2.i, node);
            }
        }
        return RelOptUtil.createProject(input, (List)exprList, Pair.right((List)namedProjects));
    }
    
    static {
        INSTANCE = new ProjectOnFilterToProjectUnifyRule();
    }
}
