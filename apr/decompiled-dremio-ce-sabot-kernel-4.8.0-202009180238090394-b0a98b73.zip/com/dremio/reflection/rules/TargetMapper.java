package com.dremio.reflection.rules;

import com.dremio.exec.planner.acceleration.normalization.rules.*;
import javax.annotation.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rex.*;
import com.google.common.base.*;
import org.apache.calcite.linq4j.*;
import org.apache.calcite.sql.type.*;
import org.apache.calcite.avatica.util.*;
import org.apache.calcite.rel.*;
import java.util.*;
import org.apache.calcite.sql.*;
import org.apache.calcite.util.*;
import com.google.common.collect.*;

public class TargetMapper extends RexShuttle
{
    private final Multimap<ComparableRexNode, Integer> positions;
    private final List<RexNode> originals;
    private final boolean unifyLiterals;
    private final ImplicationChecker engine;
    private final List<String> targetFieldNames;
    private final Function<RexNode, RexNode> mapper;
    
    public TargetMapper(final Multimap<ComparableRexNode, Integer> positions, final List<RexNode> originals, final boolean unifyLiterals) {
        this(ImplicationChecker.INSTANCE, positions, originals, unifyLiterals, (List<String>)ImmutableList.of());
    }
    
    public TargetMapper(final Multimap<ComparableRexNode, Integer> positions, final List<RexNode> originals, final boolean unifyLiterals, final List<String> targetFieldNames) {
        this(ImplicationChecker.INSTANCE, positions, originals, unifyLiterals, targetFieldNames);
    }
    
    public TargetMapper(final ImplicationChecker engine, final Multimap<ComparableRexNode, Integer> positions, final List<RexNode> originals, final boolean unifyLiterals, final List<String> targetFieldNames) {
        this.mapper = (Function<RexNode, RexNode>)new Function<RexNode, RexNode>() {
            @Nullable
            public RexNode apply(@Nullable final RexNode node) {
                return (RexNode)node.accept((RexVisitor)TargetMapper.this);
            }
        };
        this.engine = engine;
        this.positions = positions;
        this.originals = originals;
        this.unifyLiterals = unifyLiterals;
        this.targetFieldNames = targetFieldNames;
    }
    
    public static RexShuttle getRexShuttle(final LogicalProject target) {
        return getRexShuttle(target, false);
    }
    
    public static RexShuttle getRexShuttle(final LogicalProject target, final boolean unifyLiterals) {
        final Multimap<ComparableRexNode, Integer> mappings = (Multimap<ComparableRexNode, Integer>)ArrayListMultimap.create();
        int indexExpr = 0;
        for (final RexNode expr : target.getProjects()) {
            final ComparableRexNode key = new ComparableRexNode(expr);
            mappings.put((Object)key, (Object)indexExpr);
            ++indexExpr;
        }
        return new TargetMapper(mappings, target.getProjects(), unifyLiterals, target.getRowType().getFieldNames());
    }
    
    protected Optional<RexNode> getReference(final RexNode node) {
        final Iterator<Integer> valueIterator = this.positions.get((Object)new ComparableRexNode(node)).iterator();
        if (valueIterator.hasNext()) {
            return (Optional<RexNode>)Optional.of((Object)new RexInputRef((int)valueIterator.next(), node.getType()));
        }
        return (Optional<RexNode>)Optional.absent();
    }
    
    protected Optional<RexNode> getReferenceWithFieldName(final RexNode node, final String fieldName) {
        for (final Integer value : this.positions.get((Object)new ComparableRexNode(node))) {
            if (fieldName.equals(this.targetFieldNames.get(value))) {
                return (Optional<RexNode>)Optional.of((Object)new RexInputRef((int)value, node.getType()));
            }
        }
        return (Optional<RexNode>)Optional.absent();
    }
    
    public RexNode visitLiteral(final RexLiteral literal) {
        if (this.unifyLiterals) {
            return (RexNode)this.getReference((RexNode)literal).or((Object)literal);
        }
        return (RexNode)literal;
    }
    
    public RexNode visitInputRef(final RexInputRef ref) {
        final Optional<RexNode> newRef = this.getReference((RexNode)ref);
        if (newRef.isPresent()) {
            return (RexNode)newRef.get();
        }
        throw MatchFailed.INSTANCE;
    }
    
    public RexNode visitCall(final RexCall call) {
        final Optional<RexNode> newRef = this.getReference((RexNode)call);
        if (newRef.isPresent()) {
            return (RexNode)newRef.get();
        }
        final Optional<RexCall> rewritten = this.engine.rewrite(this.originals, call);
        if (rewritten.isPresent()) {
            return (RexNode)rewritten.get();
        }
        final List<RexNode> operands = (List<RexNode>)call.getOperands();
        final List<RexNode> newOperands = (List<RexNode>)Lists.transform((List)operands, (Function)this.mapper);
        return (RexNode)call.clone(call.type, (List)newOperands);
    }
    
    protected static final class ImplicationChecker
    {
        public static final ImplicationRule[] RULES;
        public static final ImplicationChecker INSTANCE;
        private final ImplicationRule[] rules;
        
        private ImplicationChecker(final ImplicationRule[] rules) {
            this.rules = (ImplicationRule[])Preconditions.checkNotNull((Object)rules, (Object)"rules are required");
        }
        
        public Optional<RexCall> rewrite(final List<RexNode> candidates, final RexCall target) {
            for (final ImplicationRule rule : this.rules) {
                for (final Ord<RexNode> candidate : Ord.zip((List)candidates)) {
                    final Optional<RexCall> rewritten = rule.rewrite(candidate, target);
                    if (rewritten.isPresent()) {
                        return rewritten;
                    }
                }
            }
            return (Optional<RexCall>)Optional.absent();
        }
        
        static {
            RULES = new ImplicationRule[] { new DateSubTypeRewriteRule() };
            INSTANCE = new ImplicationChecker(ImplicationChecker.RULES);
        }
        
        protected static class DateSubTypeRewriteRule implements ImplicationRule
        {
            private static final Multimap<SqlTypeName, Object> SUBTYPES;
            private static final Set<String> FUNCTIONS;
            
            private TimeUnitRange toTimeUnitRange(final Object obj) {
                if (obj instanceof TimeUnitRange) {
                    return (TimeUnitRange)obj;
                }
                if (obj instanceof NlsString) {
                    return TimeUnitRange.valueOf(((NlsString)obj).getValue().toUpperCase(Locale.ROOT));
                }
                return null;
            }
            
            protected static boolean isSubType(final SqlTypeName source, final TimeUnitRange target) {
                return DateSubTypeRewriteRule.SUBTYPES.get((Object)source).contains(target);
            }
            
            @Override
            public Optional<RexCall> rewrite(final Ord<RexNode> candidate, final RexCall call) {
                if (!DateSubTypeRewriteRule.FUNCTIONS.contains(call.getOperator().getName().toLowerCase())) {
                    return (Optional<RexCall>)Optional.absent();
                }
                final RexLiteral firstOperand = call.getOperands().get(0);
                final TimeUnitRange targetType = this.toTimeUnitRange(firstOperand.getValue());
                if (targetType == null) {
                    return (Optional<RexCall>)Optional.absent();
                }
                final SqlTypeName sourceType = ((RexNode)candidate.e).getType().getSqlTypeName();
                if (!isSubType(sourceType, targetType)) {
                    return (Optional<RexCall>)Optional.absent();
                }
                final RefCollector candidateRefCollector = new RefCollector(null);
                ((RexNode)candidate.e).accept((RexVisitor)candidateRefCollector);
                final RefCollector sourceRefCollector = new RefCollector(null);
                call.accept((RexVisitor)sourceRefCollector);
                if (!candidateRefCollector.getReferences().equals(sourceRefCollector.getReferences())) {
                    return (Optional<RexCall>)Optional.absent();
                }
                final Set<ComparableRexNode> variants = new HashSet<ComparableRexNode>();
                variants.add(new ComparableRexNode((RexNode)candidate.e));
                if (candidate.e instanceof RexCall && ((RexNode)candidate.e).isA(SqlKind.CAST)) {
                    variants.add(new ComparableRexNode(((RexCall)candidate.e).getOperands().get(0)));
                }
                final RexLiteral firstOperand2 = call.getOperands().get(0);
                try {
                    final RexNode secondOperand = (RexNode)call.getOperands().get(1).accept((RexVisitor)new RexShuttle() {
                        public RexNode visitCall(final RexCall call) {
                            if (variants.contains(new ComparableRexNode((RexNode)call))) {
                                return (RexNode)new RexInputRef(candidate.i, ((RexNode)candidate.e).getType());
                            }
                            return super.visitCall(call);
                        }
                        
                        public RexNode visitInputRef(final RexInputRef ref) {
                            if (variants.contains(new ComparableRexNode((RexNode)ref))) {
                                return (RexNode)new RexInputRef(candidate.i, ((RexNode)candidate.e).getType());
                            }
                            throw new ControlFlowException();
                        }
                    });
                    final List<RexNode> newOperands = (List<RexNode>)ImmutableList.builder().add((Object)firstOperand2).add((Object)secondOperand).build();
                    final RexCall newCall = call.clone(call.type, (List)newOperands);
                    return (Optional<RexCall>)Optional.of((Object)newCall);
                }
                catch (ControlFlowException e) {
                    return (Optional<RexCall>)Optional.absent();
                }
            }
            
            static {
                SUBTYPES = (Multimap)MultimapBuilder.hashKeys().hashSetValues().build();
                FUNCTIONS = (Set)ImmutableSet.of((Object)"extract", (Object)"date_trunc");
                DateSubTypeRewriteRule.SUBTYPES.putAll((Object)SqlTypeName.DATE, (Iterable)ImmutableList.of((Object)TimeUnitRange.QUARTER, (Object)TimeUnitRange.YEAR, (Object)TimeUnitRange.MONTH, (Object)TimeUnitRange.WEEK, (Object)TimeUnitRange.DAY, (Object)TimeUnitRange.DOY, (Object)TimeUnitRange.DOW));
            }
        }
        
        interface ImplicationRule
        {
            Optional<RexCall> rewrite(final Ord<RexNode> p0, final RexCall p1);
        }
    }
}
