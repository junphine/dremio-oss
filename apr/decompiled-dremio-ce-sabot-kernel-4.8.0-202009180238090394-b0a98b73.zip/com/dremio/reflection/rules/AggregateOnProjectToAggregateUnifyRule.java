package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.util.mapping.*;
import java.util.stream.*;
import org.apache.calcite.util.*;
import org.apache.calcite.linq4j.*;
import com.dremio.exec.planner.acceleration.normalization.rules.*;
import org.apache.calcite.rex.*;
import com.google.common.base.*;
import javax.annotation.*;
import org.apache.calcite.rel.type.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.calcite.sql.*;
import org.apache.calcite.plan.*;
import org.slf4j.*;

public final class AggregateOnProjectToAggregateUnifyRule extends AbstractUnifyRule
{
    public static final AggregateOnProjectToAggregateUnifyRule INSTANCE;
    private static final Logger LOGGER;
    private final boolean unify;
    
    private AggregateOnProjectToAggregateUnifyRule(final boolean unify) {
        super("A.P => A", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalAggregate.class, AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class)), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalAggregate.class));
        this.unify = unify;
    }
    
    private static List<String> getNonEmptyFieldNames(final LogicalAggregate query) {
        final List<String> aggCallNames = new ArrayList<String>();
        for (int i = 0; i < query.getGroupSet().cardinality(); ++i) {
            final String origName = query.getRowType().getFieldNames().get(i);
            final String groupByName = (origName == null || origName.isEmpty()) ? ("EMPTY_GRP_$" + i) : origName;
            aggCallNames.add(groupByName);
        }
        for (int i = 0; i < query.getAggCallList().size(); ++i) {
            final AggregateCall aggCall = query.getAggCallList().get(i);
            final String aggCallName = (aggCall.getName() == null || aggCall.getName().isEmpty()) ? ("EMPTY_AGG_" + aggCall.getAggregation().getKind() + "$" + i) : aggCall.getName();
            aggCallNames.add(aggCallName);
        }
        return aggCallNames;
    }
    
    private static LogicalAggregate permute(final LogicalAggregate aggregate, final RelNode input, final Mapping mappings) {
        final ImmutableBitSet groupSet = Mappings.apply(mappings, aggregate.getGroupSet());
        final ImmutableList<ImmutableBitSet> groupSets = (ImmutableList<ImmutableBitSet>)Mappings.apply2(mappings, (Iterable)aggregate.getGroupSets());
        final List<AggregateCall> aggregateCalls = (List<AggregateCall>)aggregate.getAggCallList().stream().map(call -> call.copy(Mappings.apply2(mappings, call.getArgList()), Mappings.apply((Mappings.TargetMapping)mappings, call.filterArg))).collect(Collectors.toList());
        return new LogicalAggregate(input.getCluster(), input, aggregate.indicator, groupSet, (List)groupSets, (List)aggregateCalls);
    }
    
    private static LogicalProject unifyLiterals(final LogicalProject top, final LogicalProject bottom) {
        final Multimap<ComparableRexNode, Integer> mappings = (Multimap<ComparableRexNode, Integer>)ArrayListMultimap.create();
        final List<RexNode> originals = (List<RexNode>)Lists.newArrayList();
        for (final Ord<RexNode> pair : Ord.zip(bottom.getProjects())) {
            if (((RexNode)pair.e).getKind() == SqlKind.LITERAL) {
                mappings.put((Object)new ComparableRexNode((RexNode)pair.e), (Object)pair.i);
                originals.add((RexNode)pair.e);
            }
        }
        final RexShuttle mapper = new TargetMapper(mappings, originals, true) {
            @Override
            public RexNode visitInputRef(final RexInputRef ref) {
                try {
                    return super.visitInputRef(ref);
                }
                catch (MatchFailed ex) {
                    return (RexNode)ref;
                }
            }
        };
        final List<RexNode> newExprs = (List<RexNode>)mapper.apply(top.getProjects());
        return LogicalRels.createProject(top.getRowType(), top.getInput(), newExprs);
    }
    
    private RelNode addProjectToPermuteUnifiedAggregate(final RelNode unified, final LogicalAggregate query, final Mappings.TargetMapping mapping, final int queryGroupByCount) {
        Preconditions.checkArgument(unified.getRowType().getFieldCount() == query.getRowType().getFieldCount());
        final RexBuilder rexBuilder = query.getCluster().getRexBuilder();
        final List<RelDataTypeField> queryRowType = (List<RelDataTypeField>)query.getRowType().getFieldList();
        final List<RexNode> reverseProjectExprs = new ArrayList<RexNode>(queryRowType.size());
        final List<Integer> orderedIndex = new ArrayList<Integer>(mapping.getTargetCount());
        for (int i = 0; i < mapping.getTargetCount(); ++i) {
            if (query.getGroupSet().get(i)) {
                final int currentInput = mapping.getSourceOpt(i);
                if (currentInput != -1) {
                    assert !orderedIndex.contains(currentInput);
                    orderedIndex.add(currentInput);
                    if (orderedIndex.size() == queryGroupByCount) {
                        break;
                    }
                }
            }
        }
        Collections.sort(orderedIndex);
        for (int i = 0; i < mapping.getTargetCount(); ++i) {
            if (query.getGroupSet().get(i)) {
                final int currentInput = mapping.getSourceOpt(i);
                if (currentInput != -1) {
                    final int sizeOfExprs = reverseProjectExprs.size();
                    final int currentExpr = orderedIndex.indexOf(currentInput);
                    if (!queryRowType.get(sizeOfExprs).getType().equals(unified.getRowType().getFieldList().get(currentExpr).getType())) {
                        return null;
                    }
                    reverseProjectExprs.add((RexNode)rexBuilder.makeInputRef(queryRowType.get(sizeOfExprs).getType(), currentExpr));
                    if (reverseProjectExprs.size() == queryGroupByCount) {
                        break;
                    }
                }
            }
        }
        for (int i = 0; i < query.getAggCallList().size(); ++i) {
            reverseProjectExprs.add((RexNode)rexBuilder.makeInputRef(queryRowType.get(i + queryGroupByCount).getType(), i + queryGroupByCount));
        }
        final RelNode reverseProject = (RelNode)LogicalRels.createProject(query.getRowType(), unified, reverseProjectExprs);
        return reverseProject;
    }
    
    private List<RexNode> getDimensionInputExpressionsFromAggregateCalls(final LogicalAggregate query, final LogicalAggregate target, final LogicalProject project) {
        final List<RexNode> otherExprsThatShouldBeDimensions = new ArrayList<RexNode>();
        for (final AggregateCall aggCall : query.getAggCallList()) {
            for (final int argIndex : aggCall.getArgList()) {
                final RexNode argRexNode = project.getProjects().get(argIndex);
                final AggregateInputRexVisitor.DimensionFinder dimensionFinder = new AggregateInputRexVisitor.DimensionFinder(aggCall, target);
                argRexNode.accept((RexVisitor)dimensionFinder);
                otherExprsThatShouldBeDimensions.addAll(dimensionFinder.getDimensions());
            }
        }
        return otherExprsThatShouldBeDimensions;
    }
    
    private RewrittenRexNodes getDimensionInputExpressions(final LogicalAggregate query, final LogicalProject project, final RelNode queryChild, final LogicalAggregate target) {
        final List<RexNode> groupedNodes = new ArrayList<RexNode>();
        for (final int group : query.getGroupSet()) {
            groupedNodes.add(project.getProjects().get(group));
        }
        final List<RexNode> otherExprsThatShouldBeDimensions = this.getDimensionInputExpressionsFromAggregateCalls(query, target, project);
        final RefCollector groupedNodeRefCollector = new RefCollector(queryChild);
        groupedNodeRefCollector.apply((List)groupedNodes);
        groupedNodeRefCollector.apply((List)otherExprsThatShouldBeDimensions);
        if (!target.getGroupSet().contains(ImmutableBitSet.of((Iterable)groupedNodeRefCollector.getReferenceIndices()))) {
            AggregateOnProjectToAggregateUnifyRule.LOGGER.debug("Some references of expressions of the query are missing in the target aggregate dimensions.");
            return null;
        }
        final Map<Integer, RexNode> groupedMappings = (Map<Integer, RexNode>)Maps.toMap((Iterable)groupedNodeRefCollector.getReferenceIndices(), (Function)new Function<Integer, RexNode>() {
            @Nullable
            public RexNode apply(@Nullable final Integer oldRef) {
                final int pos = target.getGroupSet().indexOf((int)oldRef);
                final RelDataType type = target.getRowType().getFieldList().get(pos).getType();
                return (RexNode)target.getCluster().getRexBuilder().makeInputRef(type, pos);
            }
        });
        final Map<Integer, RexNode> groupedLiteralMappings = groupedNodeRefCollector.getLiteralInputReferences();
        final RexShuttle rewriter = new RexShuttle() {
            public RexNode visitInputRef(final RexInputRef inputRef) {
                final RexNode newRef = groupedMappings.get(inputRef.getIndex());
                if (newRef != null) {
                    return newRef;
                }
                final RexNode literalRef = groupedLiteralMappings.get(inputRef.getIndex());
                if (literalRef != null) {
                    return literalRef;
                }
                return (RexNode)inputRef;
            }
        };
        final List<RexNode> rewrittenProjects = (List<RexNode>)rewriter.apply((List)groupedNodes);
        final RewrittenRexNodes toReturn = new RewrittenRexNodes();
        toReturn.addProjectExpressions(rewrittenProjects);
        for (int i = 0; i < query.getGroupSet().cardinality(); ++i) {
            toReturn.rollupAggGroupSet.add(i);
        }
        toReturn.dimensionRewriter = rewriter;
        return toReturn;
    }
    
    private RewrittenRexNodes getAggregateInputExpressions(final LogicalAggregate query, final LogicalProject project, final LogicalAggregate target, final RewrittenRexNodes dimensionResult) {
        for (final AggregateCall aggCall : query.getAggCallList()) {
            final SqlAggFunction rollUpAggFunction = AggregateToAggregateUnifyRule.getRollup(aggCall.getAggregation());
            if (rollUpAggFunction == null || aggCall.getArgList().isEmpty()) {
                AggregateOnProjectToAggregateUnifyRule.LOGGER.debug("AggregateCall in query's argument cannot be rolled up, {}", (Object)aggCall);
                return null;
            }
            final List<RexNode> newExpressions = (List<RexNode>)Lists.newArrayList();
            for (final int arg : aggCall.getArgList()) {
                final RexNode node = project.getProjects().get(arg);
                final AggregateInputRexVisitor.AggregateCallRewriter aggregateCallRewriter = new AggregateInputRexVisitor.AggregateCallRewriter(aggCall, target, dimensionResult.dimensionRewriter);
                try {
                    final RexNode rewrittenNode = (RexNode)node.accept((RexVisitor)aggregateCallRewriter);
                    newExpressions.add(rewrittenNode);
                }
                catch (Exception e) {
                    AggregateOnProjectToAggregateUnifyRule.LOGGER.debug("AggregateCall in query's argument is not supported, {}", (Object)node);
                    return null;
                }
            }
            if (newExpressions.size() != 1) {
                return null;
            }
            final int indexOfToAdd = dimensionResult.addProjectExpression(newExpressions.get(0));
            Preconditions.checkState(indexOfToAdd >= 0);
            dimensionResult.rollupAggAggregateCallsArgs.add(indexOfToAdd);
        }
        return dimensionResult;
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalAggregate query = (LogicalAggregate)call.query;
        final LogicalAggregate target = (LogicalAggregate)call.target;
        final LogicalProject queryProject = (LogicalProject)query.getInput();
        final RelNode child = target.getInput();
        final RelNode queryChild = queryProject.getInput();
        final int queryGroupByCount = query.getGroupSet().cardinality();
        LogicalProject project;
        if (this.unify && child instanceof LogicalProject) {
            project = unifyLiterals(queryProject, (LogicalProject)child);
        }
        else {
            project = queryProject;
        }
        Mappings.TargetMapping mapping;
        try {
            mapping = project.getMapping();
        }
        catch (AssertionError e) {
            mapping = null;
        }
        if (mapping != null) {
            final LogicalAggregate aggregate2 = permute(query, project.getInput(), mapping.inverse());
            final RelNode unified = AggregateToAggregateUnifyRule.unifyAggregates(aggregate2, target, call.reflection);
            if (unified == null) {
                return null;
            }
            if (query.getRowType().equals(unified.getRowType())) {
                return call.result(unified);
            }
            final RelNode reverseProject = this.addProjectToPermuteUnifiedAggregate(unified, query, mapping, queryGroupByCount);
            if (reverseProject == null) {
                return null;
            }
            return call.result(reverseProject);
        }
        else {
            final RewrittenRexNodes resultAfterDimension = this.getDimensionInputExpressions(query, project, queryChild, target);
            if (resultAfterDimension == null) {
                AggregateOnProjectToAggregateUnifyRule.LOGGER.debug("Failed to match all the dimensions in query with target expressions, {}", (Object)query);
                return null;
            }
            final RewrittenRexNodes resultAfterAggCalls = this.getAggregateInputExpressions(query, project, target, resultAfterDimension);
            if (resultAfterAggCalls == null) {
                AggregateOnProjectToAggregateUnifyRule.LOGGER.debug("Failed to match all the aggregate calls in the query with target expressions, {}", (Object)query);
                return null;
            }
            final LogicalProject newProject = LogicalRels.createProject((RelNode)call.reflection, resultAfterAggCalls.rewrittenProject, getNonEmptyFieldNames(query));
            final ImmutableBitSet newGroupSet = ImmutableBitSet.of((Iterable)resultAfterAggCalls.rollupAggGroupSet);
            final List<AggregateCall> rollupAggCalls = new ArrayList<AggregateCall>();
            Preconditions.checkState(query.getAggCallList().size() == resultAfterAggCalls.rollupAggAggregateCallsArgs.size());
            final RelNode inputToAggregate = (RelNode)newProject;
            for (int i = 0; i < query.getAggCallList().size(); ++i) {
                final AggregateCall queryAgg = query.getAggCallList().get(i);
                final int newArgIndex = resultAfterAggCalls.rollupAggAggregateCallsArgs.get(i);
                final SqlAggFunction rollUpAggFunction = AggregateToAggregateUnifyRule.getRollup(queryAgg.getAggregation());
                final AggregateCall newCall = AggregateCall.create(rollUpAggFunction, queryAgg.isDistinct(), (List)ImmutableList.of((Object)newArgIndex), queryAgg.filterArg, newGroupSet.cardinality(), inputToAggregate, (RelDataType)null, queryAgg.getName());
                rollupAggCalls.add(newCall);
            }
            final LogicalAggregate newAggregate = new LogicalAggregate(newProject.getCluster(), (RelNode)newProject, query.indicator, newGroupSet, (List)ImmutableList.of((Object)newGroupSet), (List)rollupAggCalls);
            if (!newAggregate.getRowType().equals(query.getRowType())) {
                Preconditions.checkState(newAggregate.getRowType().getFieldCount() == query.getRowType().getFieldCount());
                final List<RexNode> castExpressions = new ArrayList<RexNode>();
                final RexBuilder rexBuilder = query.getCluster().getRexBuilder();
                final List<RelDataTypeField> queryFields = (List<RelDataTypeField>)query.getRowType().getFieldList();
                final List<RelDataTypeField> newAggFields = (List<RelDataTypeField>)newAggregate.getRowType().getFieldList();
                for (int j = 0; j < query.getRowType().getFieldCount(); ++j) {
                    final RelDataTypeField queryElem = queryFields.get(j);
                    final RelDataTypeField newAggElem = newAggFields.get(j);
                    if (queryElem.getType().equals(newAggElem.getType())) {
                        castExpressions.add((RexNode)rexBuilder.makeInputRef(newAggElem.getType(), j));
                    }
                    else {
                        castExpressions.add(rexBuilder.makeCast(queryElem.getType(), (RexNode)rexBuilder.makeInputRef(newAggElem.getType(), j)));
                    }
                }
                final RelNode topCastProject = RelOptUtil.createProject((RelNode)newAggregate, (List)castExpressions, query.getRowType().getFieldNames());
                return call.result(topCastProject);
            }
            return call.result((RelNode)newAggregate);
        }
    }
    
    static {
        INSTANCE = new AggregateOnProjectToAggregateUnifyRule(false);
        LOGGER = LoggerFactory.getLogger((Class)AggregateOnProjectToAggregateUnifyRule.class);
    }
    
    private static class RewrittenRexNodes
    {
        private RexShuttle dimensionRewriter;
        private List<ComparableRexNode> rewrittenProjectToCompare;
        private List<RexNode> rewrittenProject;
        private List<Integer> rollupAggGroupSet;
        private List<Integer> rollupAggAggregateCallsArgs;
        
        private RewrittenRexNodes() {
            this.dimensionRewriter = null;
            this.rewrittenProjectToCompare = new ArrayList<ComparableRexNode>();
            this.rewrittenProject = new ArrayList<RexNode>();
            this.rollupAggGroupSet = new ArrayList<Integer>();
            this.rollupAggAggregateCallsArgs = new ArrayList<Integer>();
        }
        
        void addProjectExpressions(final List<RexNode> toAdd) {
            for (final RexNode toAddOne : toAdd) {
                this.addProjectExpression(toAddOne);
            }
        }
        
        int addProjectExpression(final RexNode toAdd) {
            final ComparableRexNode toCompare = new ComparableRexNode(toAdd);
            if (!this.rewrittenProjectToCompare.contains(toCompare)) {
                this.rewrittenProject.add(toAdd);
                this.rewrittenProjectToCompare.add(toCompare);
            }
            return this.rewrittenProjectToCompare.indexOf(toCompare);
        }
    }
}
