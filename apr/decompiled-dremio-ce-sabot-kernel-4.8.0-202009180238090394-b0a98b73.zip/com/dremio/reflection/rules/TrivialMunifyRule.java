package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import java.util.*;

public final class TrivialMunifyRule extends MunifyRule
{
    public static final MunifyRule INSTANCE;
    
    private TrivialMunifyRule() {
        super("Multi Equivalence", RelNode.class);
    }
    
    @Override
    public MunifyResult apply(final MunifyRuleCall call) {
        return isTrivialMatch(call) ? call.result((RelNode)call.getReflection()) : null;
    }
    
    public static boolean isTrivialMatch(final MunifyRuleCall call) {
        if (!call.getQuery().getClass().equals(call.getTarget().getClass())) {
            return false;
        }
        final List<MunifyRuleCall.MunifyInput> inputs = call.getInputs();
        for (final MunifyRuleCall.MunifyInput mi : inputs) {
            if (!mi.isIdentity()) {
                return false;
            }
        }
        return TrivialRule.withDummyInputs(call.getQuery()).recomputeDigest().equals(TrivialRule.withDummyInputs(call.getTarget()).recomputeDigest());
    }
    
    static {
        INSTANCE = new TrivialMunifyRule();
    }
}
