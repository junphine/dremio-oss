package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import com.dremio.reflection.bup.*;
import com.dremio.exec.planner.physical.*;
import com.dremio.exec.planner.acceleration.substitution.*;
import com.dremio.options.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.rel.type.*;
import java.util.*;
import com.google.common.base.*;

public final class FilterToFilterUnifyRule extends AbstractUnifyRule
{
    public static final FilterToFilterUnifyRule INSTANCE;
    
    private FilterToFilterUnifyRule() {
        super("F => F", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalFilter.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalFilter.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalFilter query = (LogicalFilter)call.query;
        final LogicalFilter target = (LogicalFilter)call.target;
        if (query.getCondition().toString().equals(target.getCondition().toString())) {
            return null;
        }
        final RelNode newFilter = createFilter(query, target, call.reflection);
        if (newFilter == null) {
            return null;
        }
        return call.result(newFilter);
    }
    
    public static RelNode createFilter(final LogicalFilter query, final LogicalFilter target, final ReflectionPtr ptr) {
        final long limit = PrelUtil.getPlannerSettings(query.getCluster()).getOptions().getOption((TypeValidators.LongValidator)ReflectionOptions.ACCELERATION_FILTER_THRESHOLD);
        final RexNode newCondition = splitFilter(query.getCluster().getRexBuilder(), query.getCluster().getPlanner().getExecutor(), query.getCondition(), target.getCondition(), target.getInput().getRowType(), limit);
        if (newCondition == null) {
            return null;
        }
        if (newCondition.isAlwaysTrue()) {
            return (RelNode)ptr;
        }
        return RelOptUtil.createFilter((RelNode)ptr, (Iterable)Collections.singleton(newCondition));
    }
    
    public static RexNode splitFilter(final RexBuilder rexBuilder, final RexExecutor executor, final RexNode condition, final RexNode target, final RelDataType rowType, final long limit) {
        final List<RexNode> conditionFilters = new ArrayList<RexNode>();
        final List<RexNode> targetFilters = new ArrayList<RexNode>();
        final List<RexNode> remainingFilter = new ArrayList<RexNode>();
        RelOptUtil.decomposeConjunction(condition, (List)conditionFilters);
        RelOptUtil.decomposeConjunction(target, (List)targetFilters);
        final boolean implied = RexSubstitutionUtil.implies(conditionFilters, targetFilters, rowType, rexBuilder, executor, remainingFilter, limit);
        if (!implied) {
            return null;
        }
        if (remainingFilter.isEmpty()) {
            return (RexNode)rexBuilder.makeLiteral(true);
        }
        Preconditions.checkState(remainingFilter.size() == 1, (Object)"implies() should return a single RexNode for the remaining filters");
        return remainingFilter.get(0);
    }
    
    static {
        INSTANCE = new FilterToFilterUnifyRule();
    }
}
