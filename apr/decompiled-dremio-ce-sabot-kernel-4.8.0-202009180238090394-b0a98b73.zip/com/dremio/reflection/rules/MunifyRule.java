package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;

public abstract class MunifyRule
{
    private final String name;
    protected final AbstractUnifyRule.Operand targetOperand;
    
    protected MunifyRule(final String name, final Class<? extends RelNode> targetOperand) {
        this.name = name;
        this.targetOperand = AbstractUnifyRule.operand(targetOperand);
    }
    
    public String getName() {
        return this.name;
    }
    
    public AbstractUnifyRule.Operand getTargetOperand() {
        return this.targetOperand;
    }
    
    public abstract MunifyResult apply(final MunifyRuleCall p0);
    
    @Override
    public String toString() {
        return this.name;
    }
}
