package com.dremio.reflection.rules;

public abstract class UnifyRule
{
    private final String name;
    protected final AbstractUnifyRule.Operand queryOperand;
    protected final AbstractUnifyRule.Operand targetOperand;
    
    protected UnifyRule(final String name, final AbstractUnifyRule.Operand queryOperand, final AbstractUnifyRule.Operand targetOperand) {
        this.name = name;
        this.queryOperand = queryOperand;
        this.targetOperand = targetOperand;
    }
    
    public String getName() {
        return this.name;
    }
    
    public AbstractUnifyRule.Operand getQueryOperand() {
        return this.queryOperand;
    }
    
    public AbstractUnifyRule.Operand getTargetOperand() {
        return this.targetOperand;
    }
    
    public abstract UnifyResult apply(final UnifyRuleCall p0);
    
    @Override
    public String toString() {
        return this.name;
    }
}
