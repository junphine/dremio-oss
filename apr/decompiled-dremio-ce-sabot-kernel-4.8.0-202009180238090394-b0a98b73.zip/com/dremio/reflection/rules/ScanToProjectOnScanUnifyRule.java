package com.dremio.reflection.rules;

import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.rel.logical.*;
import java.util.*;
import org.apache.calcite.rex.*;

public final class ScanToProjectOnScanUnifyRule extends AbstractUnifyRule
{
    public static final ScanToProjectOnScanUnifyRule INSTANCE;
    
    private ScanToProjectOnScanUnifyRule() {
        super("S => P.S", AbstractUnifyRule.operand((Class<? extends RelNode>)TableScan.class), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class, AbstractUnifyRule.operand((Class<? extends RelNode>)TableScan.class)));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalProject target = (LogicalProject)call.target;
        final TableScan query = (TableScan)call.query;
        if (!query.equals(target.getInput())) {
            return null;
        }
        final RexShuttle shuttle = TargetMapper.getRexShuttle(target);
        final RexBuilder rexBuilder = target.getCluster().getRexBuilder();
        List<RexNode> newProjects;
        try {
            newProjects = (List<RexNode>)shuttle.apply(rexBuilder.identityProjects(query.getRowType()));
        }
        catch (MatchFailed e) {
            return null;
        }
        final LogicalProject newProject = LogicalRels.createProject(query.getRowType(), (RelNode)call.reflection, newProjects);
        final RelNode newProject2 = LogicalRels.strip(newProject);
        return call.result(newProject2);
    }
    
    static {
        INSTANCE = new ScanToProjectOnScanUnifyRule();
    }
}
