package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import org.apache.calcite.util.*;

public class MunifyResult
{
    public final MunifyRuleCall call;
    public final RelNode result;
    
    public MunifyResult(final MunifyRuleCall call, final RelNode result) {
        this.call = call;
        assert LogicalRels.equalType("query", call.getQuery(), "result", result, Litmus.THROW);
        this.result = result;
    }
}
