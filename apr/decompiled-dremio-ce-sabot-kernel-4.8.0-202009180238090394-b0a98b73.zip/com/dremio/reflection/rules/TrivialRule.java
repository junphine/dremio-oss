package com.dremio.reflection.rules;

import com.dremio.exec.planner.common.*;
import org.apache.calcite.rel.logical.*;
import com.dremio.exec.planner.acceleration.substitution.*;
import org.apache.calcite.rel.type.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.metadata.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.util.*;
import org.apache.calcite.rex.*;

public final class TrivialRule extends AbstractUnifyRule
{
    public static final RelNode DUMMY_INPUT;
    public static final TrivialRule INSTANCE;
    
    private TrivialRule() {
        super("Equivalence", TrivialRule.ANY, TrivialRule.ANY);
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        if (!call.query.getClass().equals(call.target.getClass())) {
            return null;
        }
        final Equality e = new Equality(call.target);
        if (call.query.accept((RelShuttle)e) != null) {
            return call.result((RelNode)call.reflection);
        }
        return null;
    }
    
    public static RelNode withDummyInputs(final RelNode node) {
        final int inputSize = node.getInputs().size();
        if (inputSize == 0) {
            return node;
        }
        final List<RelNode> inputs = new ArrayList<RelNode>(inputSize);
        for (int i = 0; i < inputSize; ++i) {
            inputs.add(TrivialRule.DUMMY_INPUT);
        }
        return node.copy(node.getTraitSet(), (List)inputs);
    }
    
    static {
        DUMMY_INPUT = (RelNode)new FakeInput();
        INSTANCE = new TrivialRule();
    }
    
    private class Equality implements RelShuttle
    {
        private final RelNode right;
        
        public Equality(final RelNode right) {
            this.right = right;
        }
        
        public RelNode visit(final TableScan left) {
            if (left instanceof ScanRelBase && this.right instanceof ScanRelBase) {
                final ScanRelBase right2 = (ScanRelBase)this.right;
                final ScanRelBase left2 = (ScanRelBase)left;
                return this.rt(right2.getTableMetadata().getName().equals((Object)left2.getTableMetadata().getName()) && right2.getProjectedSchema().equals((Object)left2.getProjectedSchema()));
            }
            return this.other((RelNode)left);
        }
        
        public RelNode visit(final TableFunctionScan left) {
            return this.other((RelNode)left);
        }
        
        public RelNode visit(final LogicalValues left) {
            return this.other((RelNode)left);
        }
        
        public RelNode visit(final LogicalFilter left) {
            final LogicalFilter right2 = (LogicalFilter)this.right;
            return this.rt(right2.getCondition().toString().equals(left.getCondition().toString()));
        }
        
        public RelNode visit(final LogicalProject left) {
            final LogicalProject right2 = (LogicalProject)this.right;
            return this.rt(RelOptUtil.areRowTypesEqual(right2.getRowType(), left.getRowType(), false) && right2.getProjects().toString().equals(left.getProjects().toString()));
        }
        
        public RelNode visit(final LogicalJoin left) {
            final LogicalJoin right2 = (LogicalJoin)this.right;
            return this.rt(this.eq(left.getCondition(), right2.getCondition()) && left.getJoinType().equals((Object)right2.getJoinType()));
        }
        
        public RelNode visit(final LogicalCorrelate left) {
            return this.other((RelNode)left);
        }
        
        public RelNode visit(final LogicalUnion left) {
            final LogicalUnion right2 = (LogicalUnion)this.right;
            return this.rt(left.all == right2.all && left.kind == right2.kind);
        }
        
        public RelNode visit(final LogicalIntersect left) {
            final LogicalIntersect right2 = (LogicalIntersect)this.right;
            return this.rt(left.all == right2.all && left.kind == right2.kind);
        }
        
        public RelNode visit(final LogicalMinus left) {
            final LogicalMinus right2 = (LogicalMinus)this.right;
            return this.rt(left.all == right2.all && left.kind == right2.kind);
        }
        
        public RelNode visit(final LogicalAggregate left) {
            final LogicalAggregate right2 = (LogicalAggregate)this.right;
            return this.rt(left.getGroupSet().equals((Object)right2.getGroupSet()) && left.getAggCallList().toString().equals(right2.getAggCallList().toString()));
        }
        
        public RelNode visit(final LogicalSort left) {
            final LogicalSort right2 = (LogicalSort)this.right;
            return this.rt(right2.collation.equals(left.collation) && this.eq(right2.fetch, left.fetch) && this.eq(right2.offset, left.offset));
        }
        
        public RelNode visit(final LogicalExchange left) {
            return this.other((RelNode)left);
        }
        
        public RelNode visit(final RelNode left) {
            return this.other(left);
        }
        
        public RelNode visit(final LogicalMatch match) {
            return this.other((RelNode)match);
        }
        
        private RelNode visit(final ExpansionLeafNode left) {
            return this.rt(left.getPath().equals(((ExpansionLeafNode)this.right).getPath()));
        }
        
        private final RelNode other(final RelNode left) {
            if (left instanceof ExpansionLeafNode) {
                return this.visit((ExpansionLeafNode)left);
            }
            final int leftInputs = left.getInputs().size();
            final int rightInputs = this.right.getInputs().size();
            if (leftInputs != rightInputs) {
                return null;
            }
            final List<RelNode> inputs = new ArrayList<RelNode>(leftInputs);
            for (int i = 0; i < leftInputs; ++i) {
                inputs.add(TrivialRule.DUMMY_INPUT);
            }
            final RelNode rightPrime = TrivialRule.withDummyInputs(this.right);
            final RelNode leftPrime = TrivialRule.withDummyInputs(left);
            if (rightPrime.recomputeDigest().equals(leftPrime.recomputeDigest())) {
                return left;
            }
            return null;
        }
        
        private boolean eq(final RexNode a, final RexNode b) {
            if (a == null) {
                return b == null;
            }
            return b != null && a.toString().equals(b.toString());
        }
        
        private RelNode rt(final boolean bool) {
            if (bool) {
                return TrivialRule.DUMMY_INPUT;
            }
            return null;
        }
    }
    
    private static class FakeInput implements RelNode
    {
        public int getId() {
            return 0;
        }
        
        public String getDigest() {
            return null;
        }
        
        public RelTraitSet getTraitSet() {
            return null;
        }
        
        public String getDescription() {
            return null;
        }
        
        public RelOptCluster getCluster() {
            return null;
        }
        
        public List<RexNode> getChildExps() {
            return null;
        }
        
        public Convention getConvention() {
            return null;
        }
        
        public String getCorrelVariable() {
            return null;
        }
        
        public boolean isDistinct() {
            return false;
        }
        
        public RelNode getInput(final int i) {
            return null;
        }
        
        public RelOptQuery getQuery() {
            return null;
        }
        
        public RelDataType getRowType() {
            return null;
        }
        
        public RelDataType getExpectedInputRowType(final int ordinalInParent) {
            return null;
        }
        
        public List<RelNode> getInputs() {
            return (List<RelNode>)ImmutableList.of();
        }
        
        public double estimateRowCount(final RelMetadataQuery mq) {
            return 0.0;
        }
        
        public double getRows() {
            return 0.0;
        }
        
        public Set<String> getVariablesStopped() {
            return null;
        }
        
        public Set<CorrelationId> getVariablesSet() {
            return null;
        }
        
        public void collectVariablesUsed(final Set<CorrelationId> variableSet) {
        }
        
        public void collectVariablesSet(final Set<CorrelationId> variableSet) {
        }
        
        public void childrenAccept(final RelVisitor visitor) {
        }
        
        public RelOptCost computeSelfCost(final RelOptPlanner planner, final RelMetadataQuery mq) {
            return null;
        }
        
        public RelOptCost computeSelfCost(final RelOptPlanner planner) {
            return null;
        }
        
        public <M extends Metadata> M metadata(final Class<M> metadataClass, final RelMetadataQuery mq) {
            return null;
        }
        
        public void explain(final RelWriter pw) {
        }
        
        public RelNode onRegister(final RelOptPlanner planner) {
            return null;
        }
        
        public String recomputeDigest() {
            return "";
        }
        
        public void replaceInput(final int ordinalInParent, final RelNode p) {
        }
        
        public RelOptTable getTable() {
            return null;
        }
        
        public String getRelTypeName() {
            return "FakeInput";
        }
        
        public boolean isValid(final Litmus litmus, final RelNode.Context context) {
            return false;
        }
        
        public boolean isValid(final boolean fail) {
            return false;
        }
        
        public List<RelCollation> getCollationList() {
            return null;
        }
        
        public RelNode copy(final RelTraitSet traitSet, final List<RelNode> inputs) {
            return null;
        }
        
        public void register(final RelOptPlanner planner) {
        }
        
        public boolean isKey(final ImmutableBitSet columns) {
            return false;
        }
        
        public RelNode accept(final RelShuttle shuttle) {
            return null;
        }
        
        public RelNode accept(final RexShuttle shuttle) {
            return null;
        }
    }
}
