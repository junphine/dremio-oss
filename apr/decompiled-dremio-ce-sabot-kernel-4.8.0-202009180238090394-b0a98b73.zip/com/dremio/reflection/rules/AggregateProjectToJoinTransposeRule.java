package com.dremio.reflection.rules;

import com.dremio.exec.planner.logical.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.sql.fun.*;
import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.tools.*;
import org.apache.calcite.rex.*;
import org.apache.calcite.util.*;
import com.google.common.collect.*;
import com.google.common.base.*;
import java.util.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.sql.*;

public final class AggregateProjectToJoinTransposeRule extends RelOptRule
{
    public static RelOptRule INSTANCE;
    
    private AggregateProjectToJoinTransposeRule() {
        super(operand((Class)Aggregate.class, (RelTrait)null, Aggregate.IS_SIMPLE, operand((Class)Project.class, operand((Class)Join.class, any()), new RelOptRuleOperand[0]), new RelOptRuleOperand[0]), DremioRelFactories.CALCITE_LOGICAL_BUILDER, "aggregate-project-to-join-rule");
    }
    
    public void onMatch(final RelOptRuleCall call) {
        final Aggregate a = (Aggregate)call.rel(0);
        final Project p = (Project)call.rel(1);
        final Join j = (Join)call.rel(2);
        final List<Integer> groupingFields = new ArrayList<Integer>();
        final RexBuilder rb = call.builder().getRexBuilder();
        final ImmutableBitSet.Builder bs = ImmutableBitSet.builder();
        for (final Integer i : a.getGroupSet()) {
            final RexNode expr = p.getProjects().get(i);
            if (expr instanceof RexInputRef) {
                bs.set(((RexInputRef)expr).getIndex());
            }
            else {
                if (!RexUtil.isConstant(expr)) {
                    return;
                }
                continue;
            }
        }
        final Map<Integer, Integer> groupingIndexMapping = new HashMap<Integer, Integer>();
        int cnt = 0;
        for (final Integer k : bs.build().asList()) {
            groupingIndexMapping.put(k, cnt);
            ++cnt;
        }
        for (final Integer k : a.getGroupSet()) {
            final RexNode expr2 = p.getProjects().get(k);
            expr2.accept((RexVisitor)new RexShuttle() {
                public RexNode visitInputRef(final RexInputRef ref) {
                    groupingFields.add(ref.getIndex());
                    return (RexNode)ref;
                }
            });
        }
        final List<RexNode> exps = (List<RexNode>)p.getChildExps();
        final ImmutableBitSet newGroupingSet = ImmutableBitSet.of((Iterable)groupingFields);
        final List<AggregateCall> pushedDownAggCalls = new ArrayList<AggregateCall>();
        for (final AggregateCall c : a.getAggCallList()) {
            if (!DremioAggregateJoinTransposeRule.supportsSplitting(c)) {
                return;
            }
            final List<Integer> args = (List<Integer>)c.getArgList();
            if (args.size() > 1) {
                return;
            }
            if (args.size() == 0) {
                pushedDownAggCalls.add(AggregateCall.create(c.getAggregation(), c.isDistinct(), c.isApproximate(), (List)ImmutableList.of(), c.filterArg, c.getType(), c.getName()));
            }
            else {
                final RexNode e = exps.get(args.get(0));
                if (e instanceof RexInputRef) {
                    pushedDownAggCalls.add(AggregateCall.create(c.getAggregation(), c.isDistinct(), c.isApproximate(), (List)ImmutableList.of((Object)((RexInputRef)e).getIndex()), c.filterArg, c.getType(), c.getName()));
                }
                else {
                    if (!(e instanceof RexLiteral)) {
                        return;
                    }
                    switch (c.getAggregation().getKind()) {
                        case SUM: {
                            if (RexLiteral.intValue(e) != 1) {
                                return;
                            }
                        }
                        case COUNT: {
                            pushedDownAggCalls.add(AggregateCall.create(SqlStdOperatorTable.COUNT, c.isDistinct(), c.isApproximate(), (List)ImmutableList.of(), c.filterArg, nonNullable(c.getType(), a.getCluster()), c.getName()));
                            continue;
                        }
                        default: {
                            return;
                        }
                    }
                }
            }
        }
        final RelNode belowProjectAggregate = (RelNode)LogicalAggregate.create((RelNode)j, newGroupingSet, (List)ImmutableList.of(), (List)pushedDownAggCalls);
        final TransformCollectingCall innerRule = new TransformCollectingCall(call.getPlanner(), DremioAggregateJoinTransposeRule.INSTANCE.getOperand(), new RelNode[] { belowProjectAggregate, j }, null);
        DremioAggregateJoinTransposeRule.INSTANCE.onMatch(innerRule);
    Label_0692:
        for (final RelNode outcome : innerRule.outcome) {
            if (!(outcome instanceof Aggregate)) {
                continue;
            }
            final RelBuilder newResult = call.builder();
            final Aggregate agg = (Aggregate)outcome;
            final RelNode input = agg.getInput();
            newResult.push(input);
            final List<RelBuilder.AggCall> newAggCalls = new ArrayList<RelBuilder.AggCall>();
            final List<Integer> finalMapping = (List<Integer>)agg.getGroupSet().asList();
            final List<RexNode> finalProjectExpressions = new ArrayList<RexNode>();
            for (final Integer l : a.getGroupSet()) {
                final RexNode expr3 = p.getProjects().get(l);
                finalProjectExpressions.add((RexNode)expr3.accept((RexVisitor)new RexShuttle() {
                    public RexNode visitInputRef(final RexInputRef ref) {
                        return (RexNode)rb.makeInputRef(ref.getType(), (int)finalMapping.get(groupingIndexMapping.get(ref.getIndex())));
                    }
                }));
            }
            for (final AggregateCall c2 : agg.getAggCallList()) {
                final List<Integer> args2 = (List<Integer>)c2.getArgList();
                if (args2.size() > 1) {
                    continue Label_0692;
                }
                if (args2.size() == 0) {
                    newAggCalls.add(newResult.aggregateCall(c2.getAggregation(), c2.isDistinct(), (RexNode)null, c2.name, (Iterable)ImmutableList.of()));
                }
                else {
                    final int index = c2.getArgList().get(0);
                    final RexInputRef newProjRef = rb.makeInputRef(input.getRowType().getFieldList().get(index).getType(), index);
                    final RexInputRef newAggRef = rb.makeInputRef(newProjRef.getType(), finalProjectExpressions.size());
                    finalProjectExpressions.add((RexNode)newProjRef);
                    newAggCalls.add(newResult.aggregateCall(c2.getAggregation(), c2.isDistinct(), (RexNode)null, c2.name, (Iterable)ImmutableList.of((Object)newAggRef)));
                }
            }
            final ImmutableBitSet newGroupSet = ImmutableBitSet.range(a.getGroupSet().cardinality());
            newResult.project((Iterable)finalProjectExpressions);
            newResult.aggregate(newResult.groupKey(newGroupSet, a.indicator, (ImmutableList)null), (Iterable)newAggCalls);
            if (RelOptUtil.areRowTypesEqual(a.getRowType(), newResult.peek().getRowType(), false)) {
                call.transformTo(newResult.build());
            }
            else {
                final RexBuilder rexBuilder = a.getCluster().getRexBuilder();
                final List<RexNode> projects = (List<RexNode>)FluentIterable.from((Iterable)Pair.zip(newResult.peek().getRowType().getFieldList(), a.getRowType().getFieldList(), true)).transform((Function)new Function<Pair<RelDataTypeField, RelDataTypeField>, RexNode>() {
                    public RexNode apply(final Pair<RelDataTypeField, RelDataTypeField> pair) {
                        if (((RelDataTypeField)pair.left).getType().isNullable() == ((RelDataTypeField)pair.right).getType().isNullable()) {
                            return (RexNode)new RexInputRef(((RelDataTypeField)pair.left).getIndex(), ((RelDataTypeField)pair.left).getType());
                        }
                        return rexBuilder.makeCast(((RelDataTypeField)pair.right).getType(), (RexNode)new RexInputRef(((RelDataTypeField)pair.left).getIndex(), ((RelDataTypeField)pair.left).getType()));
                    }
                }).toList();
                newResult.project((Iterable)projects);
                call.transformTo(newResult.build());
            }
        }
    }
    
    private static RelDataType nonNullable(final RelDataType type, final RelOptCluster cluster) {
        return cluster.getTypeFactory().createTypeWithNullability(type, false);
    }
    
    static {
        AggregateProjectToJoinTransposeRule.INSTANCE = new AggregateProjectToJoinTransposeRule();
    }
    
    static class TransformCollectingCall extends RelOptRuleCall
    {
        final List<RelNode> outcome;
        
        public TransformCollectingCall(final RelOptPlanner planner, final RelOptRuleOperand operand, final RelNode[] rels, final Map<RelNode, List<RelNode>> nodeInputs, final List<RelNode> parents) {
            super(planner, operand, rels, (Map)nodeInputs, (List)parents);
            this.outcome = new ArrayList<RelNode>();
        }
        
        public TransformCollectingCall(final RelOptPlanner planner, final RelOptRuleOperand operand, final RelNode[] rels, final Map<RelNode, List<RelNode>> nodeInputs) {
            super(planner, operand, rels, (Map)nodeInputs);
            this.outcome = new ArrayList<RelNode>();
        }
        
        public void transformTo(final RelNode rel, final Map<RelNode, RelNode> equiv) {
            this.outcome.add(rel);
        }
    }
}
