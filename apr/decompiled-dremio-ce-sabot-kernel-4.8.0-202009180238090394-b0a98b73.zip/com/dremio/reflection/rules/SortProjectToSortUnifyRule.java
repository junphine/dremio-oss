package com.dremio.reflection.rules;

import org.apache.calcite.rel.logical.*;
import org.apache.calcite.rel.*;
import java.util.*;
import org.apache.calcite.rex.*;

public final class SortProjectToSortUnifyRule extends AbstractUnifyRule
{
    public static final SortProjectToSortUnifyRule INSTANCE;
    
    private SortProjectToSortUnifyRule() {
        super("S.P => P", AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalSort.class, AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalProject.class)), AbstractUnifyRule.operand((Class<? extends RelNode>)LogicalSort.class));
    }
    
    @Override
    public UnifyResult apply(final UnifyRuleCall call) {
        final LogicalSort querySort = (LogicalSort)call.query;
        final LogicalSort targetSort = (LogicalSort)call.target;
        if (Objects.equals(querySort.getCollation(), targetSort.getCollation()) && Objects.equals(querySort.fetch, targetSort.fetch) && Objects.equals(querySort.offset, targetSort.offset)) {
            final LogicalProject queryProject = (LogicalProject)querySort.getInput();
            final LogicalProject newProject = LogicalRels.createProject(queryProject.getRowType(), (RelNode)call.reflection, queryProject.getProjects());
            return call.result((RelNode)newProject);
        }
        return null;
    }
    
    static {
        INSTANCE = new SortProjectToSortUnifyRule();
    }
}
