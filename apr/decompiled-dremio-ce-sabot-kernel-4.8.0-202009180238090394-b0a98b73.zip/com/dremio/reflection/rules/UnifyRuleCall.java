package com.dremio.reflection.rules;

import org.apache.calcite.rel.*;
import com.dremio.reflection.bup.*;
import com.google.common.base.*;
import org.apache.calcite.util.*;

public class UnifyRuleCall
{
    private final BupTracer tracer;
    public final UnifyRule rule;
    public final RelNode query;
    public final RelNode target;
    public final ReflectionPtr reflection;
    
    public UnifyRuleCall(final BupTracer tracer, final UnifyRule rule, final RelNode query, final RelNode target, final ReflectionPtr reflection) {
        this.tracer = tracer;
        this.rule = (UnifyRule)Preconditions.checkNotNull((Object)rule);
        this.query = (RelNode)Preconditions.checkNotNull((Object)query);
        this.target = (RelNode)Preconditions.checkNotNull((Object)target);
        this.reflection = (ReflectionPtr)Preconditions.checkNotNull((Object)reflection);
    }
    
    public UnifyResult result(final RelNode result) {
        assert LogicalRels.equalType("result", result, "query", this.query, Litmus.THROW);
        return new UnifyResult(this, result);
    }
    
    public boolean isTraceEnabled() {
        return this.tracer.isTraceEnabled();
    }
    
    public BupTracer getTracer() {
        return this.tracer;
    }
    
    public static UnifyRuleCall createCall(final BupTracer tracer, final UnifyRule rule, final RelNode query, final RelNode target, final ReflectionPtr reflection) {
        return new UnifyRuleCall(tracer, rule, query, target, reflection);
    }
}
