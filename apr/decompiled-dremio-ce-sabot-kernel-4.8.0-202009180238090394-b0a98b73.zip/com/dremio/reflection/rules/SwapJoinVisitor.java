package com.dremio.reflection.rules;

import com.dremio.exec.planner.*;
import org.apache.calcite.rel.*;
import com.dremio.sabot.op.join.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.logical.*;
import java.util.*;
import org.apache.calcite.rel.metadata.*;
import org.apache.calcite.rex.*;

public final class SwapJoinVisitor extends StatelessRelShuttleImpl
{
    public static final SwapJoinVisitor INSTANCE;
    
    public static RelNode transform(final RelNode rel) {
        return rel.accept((RelShuttle)SwapJoinVisitor.INSTANCE);
    }
    
    public RelNode visit(final LogicalJoin join) {
        final LogicalJoin j = (LogicalJoin)super.visit(join);
        final JoinRelType joinType = join.getJoinType();
        final RelMetadataQuery mq = j.getCluster().getMetadataQuery();
        if (mq.getRowCount(j.getLeft()) < mq.getRowCount(j.getRight())) {
            final RexNode newCondition = JoinUtils.getSwappedCondition((RelNode)j);
            JoinRelType newJoinType = null;
            switch (joinType) {
                case INNER:
                case FULL: {
                    newJoinType = joinType;
                    break;
                }
                case LEFT: {
                    newJoinType = JoinRelType.RIGHT;
                    break;
                }
                case RIGHT: {
                    newJoinType = JoinRelType.LEFT;
                    break;
                }
                default: {
                    throw new RuntimeException("Unknown join type: " + joinType);
                }
            }
            final LogicalJoin newJoin = LogicalJoin.create(j.getRight(), j.getLeft(), newCondition, j.getVariablesSet(), newJoinType);
            final List<RexNode> projectExprs = (List<RexNode>)RelOptUtil.createSwappedJoinExprs((RelNode)newJoin, (Join)j, true);
            final LogicalProject topProject = LogicalProject.create((RelNode)newJoin, (List)projectExprs, j.getRowType());
            return (RelNode)topProject;
        }
        return (RelNode)j;
    }
    
    static {
        INSTANCE = new SwapJoinVisitor();
    }
}
