package com.dremio.reflection.rules;

import org.apache.calcite.rel.core.*;
import org.apache.calcite.rel.logical.*;
import com.dremio.exec.planner.acceleration.normalization.rules.*;
import org.apache.calcite.rel.type.*;
import org.apache.calcite.sql.fun.*;
import java.math.*;
import org.apache.calcite.sql.type.*;
import org.apache.calcite.sql.*;
import com.dremio.exec.planner.logical.*;
import org.slf4j.*;
import com.google.common.collect.*;
import org.apache.calcite.rex.*;
import java.util.*;

public abstract class AggregateInputRexVisitor extends RexShuttle
{
    private static final Logger LOGGER;
    protected final AggregateCall aggCall;
    protected final LogicalAggregate target;
    protected final Map<Integer, RexNode> targetLiteralInputs;
    protected final int literalOneIndex;
    
    public AggregateInputRexVisitor(final AggregateCall aggCall, final LogicalAggregate target) {
        this.targetLiteralInputs = new HashMap<Integer, RexNode>();
        this.aggCall = aggCall;
        this.target = target;
        int literalIntegerOneIndex = -1;
        if (target.getInput() instanceof LogicalProject) {
            final LogicalProject targetChild = (LogicalProject)target.getInput();
            for (int i = 0; i < targetChild.getProjects().size(); ++i) {
                final RexNode expr = targetChild.getProjects().get(i);
                if (expr.getKind() == SqlKind.LITERAL) {
                    this.targetLiteralInputs.put(i, expr);
                    if (ConvertToCountOne.isIntegerLiteralOne(expr)) {
                        literalIntegerOneIndex = i;
                    }
                }
            }
        }
        this.literalOneIndex = literalIntegerOneIndex;
    }
    
    public RexNode checkAggregateCall(final AggregateCall check) {
        int indexOf = ProjectableSqlAggFunctions.indexOfMatchingCall(check, this.target.getAggCallList());
        boolean foundConvertedAggCall = false;
        if (indexOf < 0) {
            if (check.getAggregation().getKind() == SqlKind.SUM0) {
                indexOf = ProjectableSqlAggFunctions.indexOfMatchingCall(ProjectableSqlAggFunctions.convertToRegularSum(check), this.target.getAggCallList());
                foundConvertedAggCall = true;
            }
            if (indexOf < 0) {
                throw new UnsupportedOperationException("Failed to find corresponding aggregate call (" + check + ") in target");
            }
        }
        final int indexInTarget = this.target.getGroupSet().cardinality() + indexOf;
        final RexInputRef inputRef = this.target.getCluster().getRexBuilder().makeInputRef(this.target.getRowType().getFieldList().get(indexInTarget).getType(), indexInTarget);
        if (foundConvertedAggCall) {
            final RexBuilder rexBuilder = this.target.getCluster().getRexBuilder();
            return rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.CASE, new RexNode[] { rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.IS_NULL, new RexNode[] { inputRef }), rexBuilder.makeBigintLiteral(BigDecimal.ZERO), inputRef });
        }
        return (RexNode)inputRef;
    }
    
    public RexNode createCountOne() {
        return this.createCountOne(false);
    }
    
    public RexNode createCountOne(final boolean projectable) {
        if (this.literalOneIndex < 0) {
            throw new UnsupportedOperationException("Cannot create count(1) if literal one is not an input, " + this.target.getInput());
        }
        final SqlAggFunction function = (SqlAggFunction)(projectable ? ProjectableSqlAggFunctions.PROJECTABLE_COUNT : SqlStdOperatorTable.COUNT);
        final AggregateCall check = AggregateCall.create(function, false, (List)ImmutableList.of((Object)this.literalOneIndex), -1, this.target.getCluster().getTypeFactory().createSqlType(SqlTypeName.BIGINT), this.aggCall.getName());
        return this.checkAggregateCall(check);
    }
    
    public RexNode handleInputRef(final RexInputRef inputRef) {
        if (this.aggCall.getAggregation().getKind() == SqlKind.COUNT && this.target.getGroupSet().get(inputRef.getIndex())) {
            final RexBuilder rexBuilder = this.target.getCluster().getRexBuilder();
            final RexNode countOne = this.createCountOne(this.aggCall.getAggregation() instanceof ProjectableSqlAggFunction);
            return rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.CASE, new RexNode[] { rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.EQUALS, new RexNode[] { inputRef, rexBuilder.makeNullLiteral(inputRef.getType().getSqlTypeName()) }), rexBuilder.makeZeroLiteral(inputRef.getType()), countOne });
        }
        if (this.targetLiteralInputs.containsKey(inputRef.getIndex())) {
            try {
                return (RexNode)this.targetLiteralInputs.get(inputRef.getIndex()).accept((RexVisitor)this);
            }
            catch (Exception e) {
                AggregateInputRexVisitor.LOGGER.debug("Failed to handle literal input in target input project, " + inputRef);
            }
        }
        final AggregateCall check = AggregateCall.create(this.aggCall.getAggregation(), this.aggCall.isDistinct(), (List)ImmutableList.of((Object)inputRef.getIndex()), this.aggCall.filterArg, this.aggCall.getType(), this.aggCall.getName());
        return this.checkAggregateCall(check);
    }
    
    public RexNode removeCast(final RexNode node) {
        if (node.getKind() == SqlKind.CAST && ((RexCall)node).getOperands().size() == 1 && ((RexCall)node).getOperands().get(0).getKind() == SqlKind.LITERAL) {
            return ((RexCall)node).getOperands().get(0);
        }
        return node;
    }
    
    public RexNode handleCoalesce(final RexCall call) {
        final List<RexNode> operands = (List<RexNode>)call.getOperands();
        if (call.getKind() != SqlKind.CASE || operands.size() != 3) {
            return null;
        }
        final RexNode predicate = call.getOperands().get(0);
        RexNode inputToNullCheck = null;
        RexNode whenNull = null;
        RexNode whenNotNull = null;
        switch (predicate.getKind()) {
            case IS_NOT_NULL: {
                inputToNullCheck = ((RexCall)predicate).getOperands().get(0);
                whenNull = this.removeCast(operands.get(2));
                whenNotNull = operands.get(1);
                break;
            }
            case IS_NULL: {
                inputToNullCheck = ((RexCall)predicate).getOperands().get(0);
                whenNull = this.removeCast(operands.get(1));
                whenNotNull = operands.get(2);
                break;
            }
            default: {
                return null;
            }
        }
        if (whenNotNull.getKind() != SqlKind.INPUT_REF || inputToNullCheck.getKind() != SqlKind.INPUT_REF || whenNull.getKind() != SqlKind.LITERAL || ((RexInputRef)whenNotNull).getIndex() != ((RexInputRef)inputToNullCheck).getIndex()) {
            return null;
        }
        switch (this.aggCall.getAggregation().getKind()) {
            case COUNT: {
                if (RexLiteral.isNullLiteral(whenNull)) {
                    return this.handleInputRef((RexInputRef)whenNotNull);
                }
                return this.createCountOne();
            }
            case SUM:
            case SUM0: {
                if (RexLiteral.isNullLiteral(whenNull)) {
                    return (RexNode)whenNotNull.accept((RexVisitor)this);
                }
                if (!SqlTypeName.NUMERIC_TYPES.contains(whenNull.getType().getSqlTypeName()) || (!((RexLiteral)whenNull).getValue().equals(BigDecimal.ZERO) && Double.valueOf(((RexLiteral)whenNull).toString()) != 0.0)) {
                    break;
                }
                if (this.aggCall.getAggregation().getKind() == SqlKind.SUM0) {
                    return (RexNode)whenNotNull.accept((RexVisitor)this);
                }
                final AggregateCall check = AggregateCall.create(SqlStdOperatorTable.SUM0, this.aggCall.isDistinct(), (List)ImmutableList.of((Object)((RexInputRef)whenNotNull).getIndex()), this.aggCall.filterArg, this.target.getCluster().getTypeFactory().createTypeWithNullability(this.aggCall.getType(), false), this.aggCall.getName());
                return this.checkAggregateCall(check);
            }
        }
        return null;
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)AggregateInputRexVisitor.class);
    }
    
    public static class AggregateCallRewriter extends AggregateInputRexVisitor
    {
        private final RexShuttle rewriter;
        
        public AggregateCallRewriter(final AggregateCall aggCall, final LogicalAggregate target, final RexShuttle rewriter) {
            super(aggCall, target);
            this.rewriter = rewriter;
        }
        
        public RexNode visitInputRef(final RexInputRef inputRef) {
            return this.handleInputRef(inputRef);
        }
        
        public RexNode visitLiteral(final RexLiteral literal) {
            final RexBuilder rexBuilder = this.target.getCluster().getRexBuilder();
            switch (this.aggCall.getAggregation().getKind()) {
                case MIN:
                case MAX: {
                    return (RexNode)literal;
                }
                case COUNT: {
                    if (RexLiteral.isNullLiteral((RexNode)literal)) {
                        return rexBuilder.makeZeroLiteral(this.aggCall.getType());
                    }
                    return this.createCountOne();
                }
                case SUM:
                case SUM0: {
                    if (!RexLiteral.isNullLiteral((RexNode)literal)) {
                        final RexNode countOne = this.createCountOne();
                        return rexBuilder.makeCall((SqlOperator)SqlStdOperatorTable.MULTIPLY, new RexNode[] { literal, countOne });
                    }
                    if (this.aggCall.getAggregation().getKind() == SqlKind.SUM) {
                        return rexBuilder.makeNullLiteral(this.aggCall.getType().getSqlTypeName());
                    }
                    return rexBuilder.makeZeroLiteral(this.aggCall.getType());
                }
                default: {
                    throw new UnsupportedOperationException("Unsupported aggregate call " + this.aggCall + " on literal input, " + literal);
                }
            }
        }
        
        public RexNode visitCall(final RexCall call) {
            switch (call.getKind()) {
                case CASE: {
                    try {
                        final RexNode coalesce = this.handleCoalesce(call);
                        if (coalesce != null) {
                            return coalesce;
                        }
                    }
                    catch (Exception e) {
                        AggregateInputRexVisitor.LOGGER.debug("Failed to convert CASE to COALESCE, " + call);
                    }
                    final List<RexNode> operands = (List<RexNode>)call.getOperands();
                    final List<RexNode> newOperands = (List<RexNode>)Lists.newArrayList();
                    for (int i = 0; i < operands.size(); ++i) {
                        if (RexUtil.isCasePredicate(call, i)) {
                            final RexNode predicate = operands.get(i);
                            newOperands.add(this.rewriter.apply(predicate));
                        }
                        else {
                            newOperands.add((RexNode)this.removeCast(operands.get(i)).accept((RexVisitor)this));
                        }
                    }
                    return (RexNode)call.clone(call.getType(), (List)newOperands);
                }
                case CAST: {
                    if (call.getOperands().size() == 1 && call.getType().getSqlTypeName() == call.getOperands().get(0).getType().getSqlTypeName()) {
                        return (RexNode)call.getOperands().get(0).accept((RexVisitor)this);
                    }
                    break;
                }
            }
            throw new UnsupportedOperationException("Unsupported aggregate call " + this.aggCall + " on RexCall input, " + call);
        }
    }
    
    public static class DimensionFinder extends AggregateInputRexVisitor
    {
        private final List<RexNode> dimensions;
        
        DimensionFinder(final AggregateCall aggCall, final LogicalAggregate target) {
            super(aggCall, target);
            this.dimensions = new ArrayList<RexNode>();
        }
        
        public List<RexNode> getDimensions() {
            return (List<RexNode>)ImmutableList.copyOf((Collection)this.dimensions);
        }
        
        public RexNode visitCall(final RexCall call) {
            switch (call.getKind()) {
                case CASE: {
                    try {
                        final RexNode coalesce = this.handleCoalesce(call);
                        if (coalesce != null) {
                            return coalesce;
                        }
                    }
                    catch (Exception e) {
                        AggregateInputRexVisitor.LOGGER.debug("Failed to convert CASE to COALESCE, " + call);
                    }
                    final List<RexNode> operands = (List<RexNode>)call.getOperands();
                    for (int i = 0; i < operands.size(); ++i) {
                        if (RexUtil.isCasePredicate(call, i)) {
                            this.dimensions.add(operands.get(i));
                        }
                        else {
                            operands.get(i).accept((RexVisitor)this);
                        }
                    }
                    return (RexNode)call;
                }
                default: {
                    return super.visitCall(call);
                }
            }
        }
    }
}
