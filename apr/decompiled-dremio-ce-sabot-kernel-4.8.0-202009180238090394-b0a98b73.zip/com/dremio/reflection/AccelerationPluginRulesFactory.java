package com.dremio.reflection;

import com.dremio.exec.store.*;
import com.dremio.exec.ops.*;
import com.dremio.exec.planner.*;
import com.dremio.exec.catalog.conf.*;
import org.apache.calcite.plan.*;
import com.dremio.exec.catalog.*;
import com.dremio.exec.planner.acceleration.substitution.rules.*;
import com.google.common.collect.*;
import java.util.*;
import com.dremio.exec.planner.physical.*;
import com.dremio.exec.store.dfs.*;
import com.dremio.common.exceptions.*;
import org.slf4j.*;

public class AccelerationPluginRulesFactory implements StoragePluginRulesFactory
{
    private static final Logger LOGGER;
    private final WeakHashMap<Class<? extends StoragePluginRulesFactory>, StoragePluginRulesFactory> delegates;
    
    public AccelerationPluginRulesFactory() {
        this.delegates = new WeakHashMap<Class<? extends StoragePluginRulesFactory>, StoragePluginRulesFactory>();
    }
    
    public Set<RelOptRule> getRules(final OptimizerRulesContext optimizerContext, final PlannerPhase phase, final SourceType pluginType) {
        final StoragePluginRulesFactory delegate = this.newDelegate(optimizerContext.getPlannerSettings());
        return (Set<RelOptRule>)delegate.getRules(optimizerContext, phase, pluginType);
    }
    
    public Set<RelOptRule> getRules(final OptimizerRulesContext optimizerContext, final PlannerPhase phase, final StoragePluginId pluginId) {
        final StoragePluginRulesFactory delegate = this.newDelegate(optimizerContext.getPlannerSettings());
        final Set<RelOptRule> rules = (Set<RelOptRule>)Sets.newHashSet((Object[])new RelOptRule[] { ProjectableAggregateToProjectRule.INSTANCE });
        rules.addAll(delegate.getRules(optimizerContext, phase, pluginId));
        return rules;
    }
    
    private StoragePluginRulesFactory newDelegate(final PlannerSettings plannerSettings) {
        final Class<? extends StoragePluginRulesFactory> clazz = (Class<? extends StoragePluginRulesFactory>)plannerSettings.getSabotConfig().getClass("dremio.plugins.dfs.rulesfactory", (Class)StoragePluginRulesFactory.class, (Class)FileSystemRulesFactory.class);
        StoragePluginRulesFactory delegate = this.delegates.get(clazz);
        if (delegate == null) {
            try {
                delegate = (StoragePluginRulesFactory)clazz.newInstance();
            }
            catch (ReflectiveOperationException e) {
                throw UserException.validationError((Throwable)e).message("Failure getting plugin rules.", new Object[0]).build(AccelerationPluginRulesFactory.LOGGER);
            }
            this.delegates.put(clazz, delegate);
        }
        return delegate;
    }
    
    static {
        LOGGER = LoggerFactory.getLogger((Class)StoragePluginRulesFactory.class);
    }
}
