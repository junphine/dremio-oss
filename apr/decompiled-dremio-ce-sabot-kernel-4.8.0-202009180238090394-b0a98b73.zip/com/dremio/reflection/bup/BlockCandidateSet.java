package com.dremio.reflection.bup;

import org.apache.calcite.rel.*;
import com.google.common.base.*;
import java.util.*;
import com.google.common.collect.*;

public class BlockCandidateSet
{
    private ListMultimap<Integer, BlockCandidate> candidates;
    
    public BlockCandidateSet(final RelNode candidate, final int matBlockHeight) {
        this.candidates = (ListMultimap<Integer, BlockCandidate>)ArrayListMultimap.create();
        final BlockFinder bf = new BlockFinder(true);
        candidate.accept((RelShuttle)bf);
        bf.grabLeaves();
        final int maxLevel = bf.getMaxLevel() + 1;
        if (maxLevel < matBlockHeight) {
            return;
        }
        final int blockOffset = maxLevel - matBlockHeight;
        for (int i = 0; i < matBlockHeight; ++i) {
            final int candidateLevel = i + blockOffset;
            final List<BlockFinder.Block> possibleMatchBlocks = bf.getBlocksForLevel(candidateLevel, true);
            this.candidates.putAll((Object)i, (Iterable)FluentIterable.from((Iterable)possibleMatchBlocks).transform((Function)new Function<BlockFinder.Block, BlockCandidate>() {
                public BlockCandidate apply(final BlockFinder.Block input) {
                    return new BlockCandidate(input.getRoot(), input.getRoot(), input.getLeaf(), null);
                }
            }).toList());
        }
    }
    
    public Iterable<BlockCandidate> getCandidatesForLevel(final int blockLevel) {
        return (Iterable<BlockCandidate>)Iterables.unmodifiableIterable((Iterable)this.candidates.get((Object)blockLevel));
    }
}
