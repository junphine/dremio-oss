package com.dremio.reflection.bup;

import com.dremio.exec.planner.*;
import com.google.common.base.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.linq4j.*;
import java.util.*;
import com.google.common.collect.*;

public class BlockFinder extends RoutingShuttle
{
    private final Block rootBlock;
    private final boolean populateMultimap;
    private final ListMultimap<Integer, Block> blocks;
    private final List<Block> leafBlocks;
    private Block currentBlock;
    private int maxLevel;
    
    public BlockFinder(final boolean populateMultimap) {
        this.rootBlock = new Block(0);
        this.leafBlocks = new ArrayList<Block>();
        this.currentBlock = this.rootBlock;
        this.maxLevel = 0;
        this.populateMultimap = populateMultimap;
        if (populateMultimap) {
            (this.blocks = (ListMultimap<Integer, Block>)ArrayListMultimap.create()).put((Object)0, (Object)this.rootBlock);
        }
        else {
            this.blocks = null;
        }
    }
    
    public Block getRoot() {
        return this.rootBlock;
    }
    
    public void grabLeaves() {
        for (final Block b : this.blocks.values()) {
            if (b.children.isEmpty()) {
                this.leafBlocks.add(b);
            }
        }
    }
    
    public List<Block> getBlocksForLevel(final int level, final boolean includeBlocksAtHigherLevels) {
        Preconditions.checkArgument(this.populateMultimap);
        List<Block> blocksAtLevel = (List<Block>)this.blocks.get((Object)level);
        if (!includeBlocksAtHigherLevels) {
            return blocksAtLevel;
        }
        blocksAtLevel = (List<Block>)Lists.newArrayList((Iterable)blocksAtLevel);
        for (int i = level - 1; i > -1; --i) {
            blocksAtLevel.addAll(this.blocks.get((Object)i));
        }
        return blocksAtLevel;
    }
    
    public static Block getBlocks(final RelNode root) {
        final BlockFinder f = new BlockFinder(false);
        root.accept((RelShuttle)f);
        return f.rootBlock;
    }
    
    public int getMaxLevel() {
        return this.maxLevel;
    }
    
    protected RelNode visitChildren(RelNode rel) {
        this.currentBlock.addStream(rel);
        final List<RelNode> inputs = (List<RelNode>)rel.getInputs();
        final boolean sameTree = inputs.size() < 2;
        final Block parentBlock = this.currentBlock;
        for (final Ord<RelNode> input : Ord.zip((List)inputs)) {
            if (!sameTree) {
                final int newLevel = parentBlock.getLevel() + 1;
                this.maxLevel = Math.max(newLevel, this.maxLevel);
                parentBlock.addChild(this.currentBlock = new Block(newLevel));
                if (this.populateMultimap) {
                    this.blocks.put((Object)newLevel, (Object)this.currentBlock);
                }
            }
            rel = this.visitChild(rel, input.i, (RelNode)input.e);
        }
        return rel;
    }
    
    public static class Block implements Iterable<RelNode>
    {
        private final int level;
        private LinkedList<RelNode> stream;
        private List<Block> children;
        private int blockCount;
        
        public Block(final int level) {
            this.stream = new LinkedList<RelNode>();
            this.children = new ArrayList<Block>();
            this.blockCount = -1;
            this.level = level;
        }
        
        public RelNode getLeaf() {
            return this.stream.get(0);
        }
        
        public RelNode getRoot() {
            return this.stream.get(this.stream.size() - 1);
        }
        
        public int getLevel() {
            return this.level;
        }
        
        private void addStream(final RelNode node) {
            this.stream.addFirst(node);
        }
        
        private void addChild(final Block block) {
            this.children.add(block);
        }
        
        public int getRelCount() {
            return this.stream.size();
        }
        
        public int getBlockCount() {
            if (this.blockCount == -1) {
                int count = 1;
                for (final Block b : this.children) {
                    count += b.getBlockCount();
                }
                this.blockCount = count;
            }
            return this.blockCount;
        }
        
        public Iterable<Block> blocks() {
            return (Iterable<Block>)Iterables.unmodifiableIterable((Iterable)this.children);
        }
        
        @Override
        public Iterator<RelNode> iterator() {
            return (Iterator<RelNode>)Iterators.unmodifiableIterator((Iterator)this.stream.iterator());
        }
    }
}
