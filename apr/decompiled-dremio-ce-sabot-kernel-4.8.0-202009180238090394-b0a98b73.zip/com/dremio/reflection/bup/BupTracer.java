package com.dremio.reflection.bup;

import com.dremio.reflection.*;
import com.dremio.reflection.rules.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.*;
import org.apache.calcite.sql.*;
import com.dremio.exec.planner.acceleration.*;
import org.joda.time.format.*;
import com.google.common.base.*;
import java.util.*;
import org.slf4j.*;
import com.google.common.collect.*;

public class BupTracer implements SubstitutionErrorCollector
{
    private static final Logger logger;
    private static final int COMPARE_TREE_WIDTH = 75;
    private static final String INDENT = "\t";
    private static final Joiner DOT_JOINER;
    private static final FluentIterable<String> EMPTY;
    private final String compositeId;
    private final FluentIterable<String> ids;
    private final int size;
    private final boolean enabled;
    private final SubstitutionErrorCollector collector;
    
    public BupTracer(final boolean enabled) {
        this(enabled, SubstitutionErrorCollector.NO_OP);
    }
    
    public BupTracer(final boolean enabled, final SubstitutionErrorCollector collector) {
        this(enabled, BupTracer.EMPTY, collector);
    }
    
    private BupTracer(final boolean enabled, final FluentIterable<String> ids, final SubstitutionErrorCollector collector) {
        this.ids = ids;
        this.enabled = enabled;
        this.compositeId = ids.join(BupTracer.DOT_JOINER);
        this.size = ids.size();
        this.collector = collector;
        if (enabled && ids.size() == 1) {
            this.log("Starting tracing for thread " + Thread.currentThread().getName());
        }
    }
    
    public boolean isTraceEnabled() {
        return this.enabled;
    }
    
    public BupTracer child(final String child) {
        return new BupTracer(this.enabled, (FluentIterable<String>)this.ids.append((Object[])new String[] { child }), this.collector);
    }
    
    public BupTracer child(final Object obj) {
        return this.child(obj.toString());
    }
    
    public void log(final String message) {
        if (this.enabled) {
            BupTracer.logger.info(indent(this.size, String.format("%s: %s", this.compositeId, message)));
        }
    }
    
    public void log(final String message, final List<MunifyRuleCall.MunifyInput> inputs) {
        if (this.enabled) {
            final StringBuilder sb = new StringBuilder();
            sb.append(indent(this.size, String.format("%s: %s", this.compositeId, message)));
            sb.append("\n");
            for (final MunifyRuleCall.MunifyInput i : inputs) {
                sb.append(indent(this.size + 1, String.format("User: %d, Reflection: %d", i.getQueryPosition(), i.getTargetPosition())));
                sb.append("\n");
                sb.append(indent(this.size + 1, RelOptUtil.toString(i.getInput())));
                sb.append("\n");
            }
            BupTracer.logger.info(sb.toString());
        }
    }
    
    public void log(final String message, final Iterable<RelNode> nodes) {
        if (this.enabled) {
            final StringBuilder sb = new StringBuilder();
            sb.append(message);
            for (final RelNode n : nodes) {
                this.logIndented(sb.toString(), RelOptUtil.toString(n, SqlExplainLevel.DIGEST_ATTRIBUTES));
            }
        }
    }
    
    public void log(final String strFormat, final Object... objs) {
        if (this.enabled) {
            BupTracer.logger.info(String.format(strFormat, objs));
        }
    }
    
    public void log(final String message, final DremioMaterialization mater) {
        if (this.enabled) {
            final StringBuilder sb = new StringBuilder();
            sb.append(message);
            sb.append(", layout name: " + mater.getLayoutInfo().getName());
            sb.append(", id: " + mater.getReflectionId());
            sb.append(", expiration: " + ISODateTimeFormat.basicDateTime().print(mater.getExpirationTimestamp()));
            this.logIndented(sb.toString(), RelOptUtil.toString(mater.getQueryRel(), SqlExplainLevel.DIGEST_ATTRIBUTES));
        }
    }
    
    public <T> Iterable<T> logEmpty(final String message, final Iterable<T> iter) {
        if (!this.enabled) {
            return iter;
        }
        return new Iterable<T>() {
            @Override
            public Iterator<T> iterator() {
                final Iterator<T> newIter = iter.iterator();
                if (!newIter.hasNext()) {
                    BupTracer.this.log(message);
                }
                return newIter;
            }
        };
    }
    
    public void log(final String message, final RelNode tree) {
        if (this.enabled) {
            this.logIndented(message, RelOptUtil.toString(tree, SqlExplainLevel.DIGEST_ATTRIBUTES));
        }
    }
    
    public void log(final String message, final RelNode tree1, final int tree1Horizon, final RelNode tree2, final int tree2Horizon) {
        if (this.enabled) {
            final String empty = Strings.padEnd("", 75, ' ');
            final String[] tree1Parts = markTree(tree1, tree1Horizon, SqlExplainLevel.DIGEST_ATTRIBUTES, 75);
            final String[] tree2Parts = markTree(tree2, tree2Horizon, SqlExplainLevel.DIGEST_ATTRIBUTES, 75);
            String indent = "";
            for (int i = 0; i < this.size; ++i) {
                indent += "\t";
            }
            final int max = Math.max(tree1Parts.length, tree2Parts.length);
            final StringBuilder sb = new StringBuilder();
            sb.append(indent);
            sb.append(String.format("%s: %s", this.compositeId, message));
            sb.append('\n');
            indent += "\t";
            for (int j = 0; j < max; ++j) {
                sb.append(indent);
                if (tree1Parts.length > j) {
                    sb.append(tree1Parts[j]);
                }
                else {
                    sb.append(empty);
                }
                if (tree2Parts.length > j) {
                    sb.append("\t");
                    sb.append(tree2Parts[j]);
                }
                sb.append('\n');
            }
            BupTracer.logger.info(sb.toString());
        }
    }
    
    @Override
    public void addError(final Exception e) {
        this.collector.addError(e);
    }
    
    public void log(final String message, final RelNode tree1, final int tree1Horizon, final RelNode tree2, final int tree2Horizon, final RelNode tree3) {
        if (this.enabled) {
            final String empty = Strings.padEnd("", 75, ' ');
            final String[] tree1Parts = markTree(tree1, tree1Horizon, SqlExplainLevel.DIGEST_ATTRIBUTES, 75);
            final String[] tree2Parts = markTree(tree2, tree2Horizon, SqlExplainLevel.DIGEST_ATTRIBUTES, 75);
            final String[] tree3Parts = markTree(tree3, 0, SqlExplainLevel.DIGEST_ATTRIBUTES, 75);
            String indent = "";
            for (int i = 0; i < this.size; ++i) {
                indent += "\t";
            }
            final int max = Math.max(tree1Parts.length, Math.max(tree3Parts.length, tree2Parts.length));
            final StringBuilder sb = new StringBuilder();
            sb.append(indent);
            sb.append(String.format("%s: %s", this.compositeId, message));
            sb.append('\n');
            indent += "\t";
            for (int j = 0; j < max; ++j) {
                sb.append(indent);
                if (tree1Parts.length > j) {
                    sb.append(tree1Parts[j]);
                }
                else {
                    sb.append(empty);
                }
                sb.append("\t");
                if (tree2Parts.length > j) {
                    sb.append(tree2Parts[j]);
                }
                else {
                    sb.append(empty);
                }
                if (tree3Parts.length > j) {
                    sb.append("\t");
                    sb.append(tree3Parts[j]);
                }
                sb.append('\n');
            }
            BupTracer.logger.info(sb.toString());
        }
    }
    
    private static String[] markTree(final RelNode node, final int horizon, final SqlExplainLevel explainLevel, final int max) {
        final Set<Integer> markers = new HashSet<Integer>();
        for (int i = 0; i < horizon; ++i) {
            markers.add(i);
        }
        final String[] treeParts = RelOptUtil.toString(node, explainLevel).split("\\n");
        for (int j = 0; j < treeParts.length; ++j) {
            final String prepend = markers.contains(j) ? "> " : "  ";
            treeParts[j] = prepend + treeParts[j];
            if (max > 0) {
                treeParts[j] = Strings.padEnd(treeParts[j], max, ' ').substring(0, max);
            }
        }
        return treeParts;
    }
    
    private void logIndented(final String message, final String body) {
        BupTracer.logger.info(indent(this.size, String.format("%s: %s", this.compositeId, message)) + "\n" + indent(this.size + 1, body));
    }
    
    private static String indent(final int indent, final Object value) {
        String replacement = "";
        for (int i = 0; i < indent; ++i) {
            replacement += "\t";
        }
        return value.toString().replaceAll("(?m)^", replacement);
    }
    
    static {
        logger = LoggerFactory.getLogger("com.dremio.reflection.ReflectionTracer");
        DOT_JOINER = Joiner.on('.');
        EMPTY = FluentIterable.from((Iterable)ImmutableList.of());
    }
}
