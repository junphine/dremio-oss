package com.dremio.reflection.bup;

import com.dremio.exec.planner.*;
import org.apache.calcite.plan.*;
import com.google.common.base.*;
import org.apache.calcite.rel.*;
import java.util.*;
import com.dremio.reflection.rules.*;

public final class ReplacementShuttle extends RoutingShuttle
{
    private final RelNode toReplace;
    private final RelNode replacement;
    private final boolean byDigest;
    private boolean found;
    private final boolean usePointer;
    
    private ReplacementShuttle(final RelNode toReplace, final RelNode replacement, final boolean byDigest, final boolean usePointer) {
        this.toReplace = toReplace;
        this.replacement = replacement;
        this.byDigest = byDigest;
        this.usePointer = usePointer;
    }
    
    public static RelNode replace(final RelNode originalTree, final RelNode toReplace, final RelNode replacement) {
        return replace(originalTree, toReplace, replacement, false);
    }
    
    public static RelNode replace(final RelNode originalTree, final RelNode toReplace, final RelNode replacement, final boolean usePointer) {
        Preconditions.checkArgument(RelOptUtil.areRowTypesEqual(toReplace.getRowType(), replacement.getRowType(), false), "Row types didn't match. \n\tOriginal: %s\n\tReplacement: %s.", (Object)toReplace.getRowType(), (Object)replacement.getRowType());
        final ReplacementShuttle shuttle = new ReplacementShuttle(toReplace, replacement, false, usePointer);
        final RelNode updated = originalTree.accept((RelShuttle)shuttle);
        if (!shuttle.found) {
            throw new IllegalStateException("Replacement node not found.");
        }
        return updated;
    }
    
    public RelNode visit(final RelNode other) {
        if (other == this.toReplace || (this.byDigest && other.getClass().equals(this.toReplace.getClass()) && other.recomputeDigest().equals(this.toReplace.getDigest()))) {
            this.found = true;
            return this.result(this.replacement, this.toReplace);
        }
        return super.visit(other);
    }
    
    protected RelNode visitChild(final RelNode parent, final int i, final RelNode child) {
        RelNode child2;
        if (child == this.toReplace) {
            child2 = this.result(this.replacement, this.toReplace);
            this.found = true;
        }
        else {
            child2 = child.accept((RelShuttle)this);
        }
        if (child2 != child) {
            final List<RelNode> newInputs = new ArrayList<RelNode>(parent.getInputs());
            newInputs.set(i, child2);
            return parent.copy(parent.getTraitSet(), (List)newInputs);
        }
        return parent;
    }
    
    private RelNode result(final RelNode result, final RelNode toReplace) {
        if (this.usePointer) {
            return (RelNode)new ReplacementPointer(result, toReplace);
        }
        return result;
    }
}
