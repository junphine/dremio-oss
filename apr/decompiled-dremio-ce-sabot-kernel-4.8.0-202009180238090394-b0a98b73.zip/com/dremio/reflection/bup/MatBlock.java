package com.dremio.reflection.bup;

import com.dremio.exec.planner.acceleration.*;
import com.dremio.exec.planner.acceleration.substitution.*;
import org.apache.calcite.rel.*;
import java.util.stream.*;
import com.google.common.collect.*;
import com.dremio.service.*;
import org.apache.calcite.rel.rules.*;
import org.apache.calcite.plan.hep.*;
import java.util.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.rel.metadata.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.util.*;
import java.util.function.*;
import com.google.common.base.*;
import com.dremio.common.exceptions.*;
import com.dremio.reflection.rules.*;
import org.slf4j.*;
import com.dremio.exec.planner.*;

public class MatBlock
{
    private static final Logger logger;
    private final Predicate<RelNode> resultValidationPredicate;
    private final PlanningTerminator terminator;
    private final BupTracer tracer;
    private final List<MatNode> nodes;
    private final List<MatBlock> childBlocks;
    private final int level;
    private final MatNode leaf;
    private final MatNode root;
    private final int maxBlockHeight;
    private final boolean isRootBlock;
    private final DremioMaterialization materialization;
    private final String blockId;
    private final List<SubIterator> leafIterators;
    private final BlockFinder.Block initBlock;
    private BlockCandidateSet lastCandidateSet;
    private Iterable<BlockCandidate> candidates;
    private final List<ExpansionLeafNode> remaining;
    
    public MatBlock(final BupTracer tracer, final PlanningTerminator terminator, final DremioMaterialization materialization, final BlockFinder.Block block, final int maxBlockHeight, final UnifyRuleSet ruleSet, final MunifyRuleSet multiRules, final Predicate<RelNode> resultValidationPredicate, final List<ExpansionLeafNode> remaining) {
        this("0", tracer, terminator, materialization, block, maxBlockHeight, true, ruleSet, multiRules, resultValidationPredicate, remaining);
    }
    
    private MatBlock(final String blockId, final BupTracer tracer, final PlanningTerminator terminator, final DremioMaterialization materialization, final BlockFinder.Block block, final int maxBlockHeight, final boolean isRoot, final UnifyRuleSet ruleSet, final MunifyRuleSet multiRules, final Predicate<RelNode> resultValidationPredicate, final List<ExpansionLeafNode> remaining) {
        this.leafIterators = new ArrayList<SubIterator>();
        this.tracer = tracer;
        this.isRootBlock = isRoot;
        this.materialization = materialization;
        this.maxBlockHeight = maxBlockHeight;
        this.resultValidationPredicate = resultValidationPredicate;
        this.terminator = terminator;
        this.blockId = blockId;
        this.remaining = remaining;
        this.initBlock = block;
        this.level = block.getLevel();
        final ImmutableList.Builder<MatBlock> blockBuilder = (ImmutableList.Builder<MatBlock>)ImmutableList.builder();
        int x = 0;
        for (final BlockFinder.Block b : block.blocks()) {
            blockBuilder.add((Object)new MatBlock(blockId + "." + x++, tracer.child("b" + b.getLevel()), terminator, materialization, b, maxBlockHeight, false, ruleSet, multiRules, resultValidationPredicate, remaining));
        }
        this.childBlocks = (List<MatBlock>)blockBuilder.build();
        final List<RelNode> relNodes = (List<RelNode>)ImmutableList.copyOf((Iterable)block);
        final ImmutableList.Builder<MatNode> builder = (ImmutableList.Builder<MatNode>)ImmutableList.builder();
        MatNode prev = null;
        for (int i = 0; i < relNodes.size(); ++i) {
            final RelNode current = relNodes.get(i);
            final boolean isRootOfBlock = i == relNodes.size() - 1;
            final boolean isLeafNode = i == 0;
            MatNode newNode;
            if (isLeafNode) {
                newNode = new MatNode(ruleSet, multiRules, current, null, 0, isRootOfBlock, this.leafIterators);
            }
            else {
                newNode = new MatNode(ruleSet, multiRules, current, prev, i, isRootOfBlock, (List<SubIterator>)ImmutableList.of());
            }
            builder.add((Object)newNode);
            prev = newNode;
        }
        this.nodes = (List<MatNode>)builder.build();
        this.leaf = this.nodes.get(0);
        this.root = this.nodes.get(this.nodes.size() - 1);
    }
    
    public String getBlockId() {
        return this.blockId;
    }
    
    public boolean isRoot() {
        return this.isRootBlock;
    }
    
    public int getLevel() {
        return this.level;
    }
    
    public void resetAndInit(final BlockCandidateSet candidateSet) {
        this.leafIterators.clear();
        this.lastCandidateSet = candidateSet;
        this.candidates = candidateSet.getCandidatesForLevel(this.level);
        for (final MatBlock b : this.childBlocks) {
            b.resetAndInit(candidateSet);
        }
        for (final MatNode n : this.nodes) {
            n.clear();
        }
    }
    
    public void resetIteartors() {
        for (final SubIterator i : this.leafIterators) {
            i.reset();
        }
        for (final MatNode n : this.nodes) {
            n.clear();
        }
        for (final MatBlock b : this.childBlocks) {
            b.resetIteartors();
        }
    }
    
    private Stream<BlockCandidate> determineLeafIterators() {
        if (this.childBlocks.isEmpty()) {
            this.leafIterators.addAll((Collection<? extends SubIterator>)FluentIterable.from((Iterable)this.candidates).transformAndConcat((Function)new Function<BlockCandidate, Iterable<SubIterator>>() {
                public Iterable<SubIterator> apply(final BlockCandidate input) {
                    final SubIteratorCollector collector = new SubIteratorCollector(input);
                    input.getBlockRoot().accept((RelShuttle)collector);
                    return collector.iterators;
                }
            }).toList());
            return Stream.empty();
        }
        return this.matchLeafNode();
    }
    
    private Stream<BlockCandidate> matchLeafNode() {
        final List<List<BlockCandidate>> childCandidateLists = this.childBlocks.stream().map(input -> input.generateAlternativeBlocks().collect((Collector<? super BlockCandidate, ?, List<? super BlockCandidate>>)Collectors.toList())).collect((Collector<? super Object, ?, List<List<BlockCandidate>>>)Collectors.toList());
        List<ChildCandidate>[] options;
        Set<RelNode> possibleInputs;
        int i;
        final List<List<BlockCandidate>> list;
        List<BlockCandidate> childCandidates;
        List<ChildCandidate> optionList;
        final Iterator<BlockCandidate> iterator;
        BlockCandidate childCandidate;
        RelNode wrongInputsCurrentNode;
        IdentityHashMap<RelNode, Integer> inputMap;
        List<RelNode> originalInputs;
        int j;
        List<Set<ChildCandidate>> sets;
        Set<List<ChildCandidate>> product;
        Set<RelNode> candidateNodes;
        final Iterator<ChildCandidate> iterator2;
        ChildCandidate d;
        ImmutableList.Builder<MunifyRuleCall.MunifyInput> builder;
        int k;
        ChildCandidate can;
        final IdentityHashMap<K, Integer> identityHashMap;
        int originalPosition;
        Stream<List<MunifyRuleCall.MunifyInput>> finalCombos;
        Pointer<Integer> comboInt;
        final RelNode tree;
        ReflectionPtr ptr;
        BupTracer tracer;
        final Pointer pointer;
        Integer n;
        final Object value;
        final StringBuilder sb;
        BupTracer inner;
        final BupTracer tracer2;
        final RelNode relNode;
        final ReflectionPtr reflectionPtr;
        MunifyResult result;
        RelNode newRoot;
        final Throwable t;
        Throwable e;
        final Throwable t2;
        Throwable e2;
        final Stream<BlockCandidate> newParentCandidates = StreamSupport.stream(this.candidates.spliterator(), false).flatMap(parent -> {
            try {
                options = (List<ChildCandidate>[])new List[this.childBlocks.size()];
                possibleInputs = (Set<RelNode>)Sets.newIdentityHashSet();
                possibleInputs.addAll(parent.getBlockLeaf().getInputs());
                for (i = 0; i < this.childBlocks.size(); ++i) {
                    childCandidates = list.get(i);
                    optionList = new ArrayList<ChildCandidate>();
                    options[i] = optionList;
                    childCandidates.iterator();
                    while (iterator.hasNext()) {
                        childCandidate = iterator.next();
                        if (!possibleInputs.contains(childCandidate.getOriginalBlockRoot())) {
                            continue;
                        }
                        else {
                            optionList.add(new ChildCandidate(childCandidate.getOriginalBlockRoot(), canonize(childCandidate.getBlockRoot()), childCandidate.getReflection()));
                        }
                    }
                }
                wrongInputsCurrentNode = parent.getBlockLeaf();
                inputMap = new IdentityHashMap<RelNode, Integer>();
                for (originalInputs = (List<RelNode>)wrongInputsCurrentNode.getInputs(), j = 0; j < originalInputs.size(); ++j) {
                    inputMap.put(originalInputs.get(j), j);
                }
                sets = Arrays.stream(options).map((java.util.function.Function<? super List<ChildCandidate>, ?>)ImmutableSet::copyOf).collect((Collector<? super Object, Object, List<Set<ChildCandidate>>>)ImmutableList.toImmutableList());
                product = (Set<List<ChildCandidate>>)Sets.cartesianProduct((List)sets);
                finalCombos = product.stream().filter(c -> {
                    candidateNodes = (Set<RelNode>)Sets.newIdentityHashSet();
                    c.iterator();
                    while (iterator2.hasNext()) {
                        d = iterator2.next();
                        candidateNodes.add(d.getOriginalBlockRoot());
                    }
                    return c.size() == candidateNodes.size();
                }).map(c -> {
                    builder = (ImmutableList.Builder<MunifyRuleCall.MunifyInput>)ImmutableList.builder();
                    for (k = 0; k < c.size(); ++k) {
                        can = c.get(k);
                        originalPosition = identityHashMap.get(can.getOriginalBlockRoot());
                        builder.add((Object)new MunifyRuleCall.MunifyInput(originalPosition, k, can.getNewBlockRoot(), can.getReflection()));
                    }
                    return builder.build();
                });
                comboInt = (Pointer<Integer>)new Pointer((Object)0);
                return finalCombos.flatMap(inputList -> {
                    this.tracer.log("Attempting Multi Match combo. User Query:", tree);
                    this.tracer.log("User Inputs:", inputList);
                    this.tracer.log("Reflection:", this.leaf.getRel());
                    ptr = new ReflectionPtr(this.materialization, this, this.leaf);
                    tracer = this.tracer;
                    new StringBuilder().append("c");
                    n = (Integer)pointer.value;
                    (int)pointer.value + 1;
                    pointer.value = value;
                    inner = tracer.child(sb.append(n).toString());
                    return StreamSupport.stream(this.leaf.getValidMultiRules().spliterator(), false).flatMap(rule -> {
                        try {
                            result = rule.apply(new MunifyRuleCall(tracer2, rule, relNode, this.leaf.getRel(), reflectionPtr, inputList));
                            if (result != null) {
                                tracer2.log(rule.getName() + ": Found match.", result.result);
                                newRoot = canonize(ReplacementShuttle.replace(parent.getBlockRoot(), relNode, result.result));
                                if (this.leaf.isRoot()) {
                                    return Stream.of(new BlockCandidate(parent.getBlockRoot(), newRoot.accept((RelShuttle)MunifyCreatedLateBlock.MUNIFY_LATE_BLOCK_RESOLVER), null, reflectionPtr));
                                }
                                else {
                                    this.leaf.addMatch(new SubIterator(parent, newRoot, 0));
                                }
                            }
                            else {
                                tracer2.log(rule.getName() + ": No match.");
                            }
                        }
                        catch (Exception | AssertionError ex) {
                            e = t;
                            this.handleError(e);
                            return Stream.empty();
                        }
                        return Stream.empty();
                    }).filter(Objects::nonNull);
                });
            }
            catch (Exception | AssertionError ex2) {
                e2 = t2;
                this.handleError(e2);
                return Stream.empty();
            }
        });
        return newParentCandidates;
    }
    
    public static RelNode canonize(final RelNode rel) {
        final HepProgramBuilder hepPgmBldr = new HepProgramBuilder();
        hepPgmBldr.addMatchOrder(HepMatchOrder.BOTTOM_UP);
        hepPgmBldr.addRuleInstance(PushFilterPastProjectRule.CALCITE_NO_CHILD_CHECK);
        hepPgmBldr.addRuleInstance((RelOptRule)ProjectMergeRule.INSTANCE);
        final HepPlanner planner = new HepPlanner(hepPgmBldr.build());
        planner.setRoot(rel);
        return planner.findBestExp();
    }
    
    public Stream<Candidate> generateCandidates(final RelNode startingCandidateQuery, final DremioMaterialization materialization) {
        Preconditions.checkArgument(this.level == 0, (Object)"Only the root materialization block can generate Candidates.");
        final BlockCandidateSet set = new BlockCandidateSet(startingCandidateQuery, this.maxBlockHeight);
        this.resetAndInit(set);
        final Stream<BlockCandidate> blockCandidates = this.generateAlternativeBlocks();
        final Set<Integer> candidateSet = new HashSet<Integer>();
        RelNode currentNode;
        RelNode alternative;
        RelNode alternativeTree;
        RelNode newRoot;
        int initialFlattenCount;
        int finalFlattenCount;
        String message;
        Candidate candidate;
        final Set<Integer> set2;
        final Throwable t;
        Throwable ex;
        return blockCandidates.map(newBlockCandidate -> {
            try {
                currentNode = newBlockCandidate.getOriginalBlockRoot();
                alternative = newBlockCandidate.getBlockRoot();
                if (this.resultValidationPredicate.apply((Object)currentNode)) {
                    this.tracer.log("Reflection replacement identified, pre-expansion:", alternative);
                    alternativeTree = applyRowDiscount(ReflectionPtr.expand(alternative), currentNode);
                    newRoot = ReplacementShuttle.replace(startingCandidateQuery, currentNode, alternativeTree, true);
                    initialFlattenCount = FlattenVisitors.FlattenCounter.countFlattensInPlan(currentNode);
                    finalFlattenCount = FlattenVisitors.FlattenCounter.countFlattensInPlan(alternativeTree) + FlattenVisitors.FlattenCounter.countFlattensInPlan(materialization.getQueryRel());
                    if (initialFlattenCount != finalFlattenCount) {
                        if (MatBlock.logger.isDebugEnabled()) {
                            message = "Substitution does not preserve flatten count. Excluding replacement:\n" + RelOptUtil.toString(newRoot);
                            this.tracer.log(message);
                            MatBlock.logger.debug(message);
                        }
                        return null;
                    }
                    else {
                        this.tracer.log("Reflection post replacement", newRoot);
                        candidate = new Candidate(newRoot, alternativeTree, (List<DremioMaterialization>)ImmutableList.of((Object)materialization));
                        return set2.add(candidate.getId()) ? candidate : null;
                    }
                }
                else {
                    return null;
                }
            }
            catch (Exception | AssertionError ex2) {
                ex = t;
                this.handleError(ex);
                return null;
            }
        }).filter(Objects::nonNull);
    }
    
    private static RelNode applyRowDiscount(final RelNode relToUpdate, final RelNode rootBeforeReplacement) {
        final RelMetadataQuery mq = rootBeforeReplacement.getCluster().getMetadataQuery();
        final double beforeRowCount = mq.getRowCount(rootBeforeReplacement);
        final double afterRowCount = mq.getRowCount(relToUpdate);
        final RelOptCost beforeCost = mq.getCumulativeCost(rootBeforeReplacement);
        final RelOptCost afterCost = mq.getCumulativeCost(relToUpdate);
        final double rowDiscount = (beforeRowCount < afterRowCount) ? (beforeRowCount / afterRowCount) : 1.0;
        final double costDiscount = Math.min(1.0, beforeCost.divideBy(afterCost));
        return new RowCountReplacer(Math.min(rowDiscount, costDiscount)).updateRowCount(relToUpdate);
    }
    
    private Stream<BlockCandidate> generateAlternativeBlocks() {
        final Stream<BlockCandidate> rootLeafDirect = this.determineLeafIterators();
        if (this.leaf.isRoot() && !this.childBlocks.isEmpty()) {
            return rootLeafDirect;
        }
        rootLeafDirect.forEach(Util::discard);
        List<MatNode> matNodes = this.nodes;
        if (this.childBlocks.size() > 1) {
            matNodes = matNodes.subList(1, matNodes.size());
        }
        BupTracer childTracer;
        UnifyRuleSet rules;
        Pointer<Integer> iterInt;
        final Pointer pointer;
        Integer n;
        final Object value;
        final BupTracer tracer;
        final StringBuilder sb;
        BupTracer tracerInner;
        Stream.Builder<BlockCandidate> builder;
        RelNode currentUserNode;
        BupTracer tracerInner2;
        int ruleInt;
        final UnifyRuleSet set;
        final Iterator<UnifyRule> iterator;
        UnifyRule rule;
        final BupTracer bupTracer;
        final StringBuilder sb2;
        final int n2;
        BupTracer ruleTracer;
        ReflectionPtr ptr;
        UnifyResult result;
        SubIterator newIterator;
        final Throwable t;
        Throwable e;
        final Throwable t2;
        Throwable e2;
        final Stream<BlockCandidate> parentCandidates = matNodes.stream().flatMap(matNode -> {
            try {
                childTracer = this.tracer.child("n" + matNode.getNodeCount());
                childTracer.log("Attempting matches at reflection node.", matNode.getRel());
                rules = matNode.getValidRules();
                iterInt = (Pointer<Integer>)new Pointer((Object)0);
                return StreamSupport.stream(childTracer.logEmpty("No available user matches at node.", matNode.subs()).spliterator(), false).flatMap(iter -> {
                    new StringBuilder().append("u");
                    n = (Integer)pointer.value;
                    (int)pointer.value + 1;
                    pointer.value = value;
                    tracerInner = tracer.child(sb.append(n).toString());
                    tracerInner.log("Attempting matches on user node.", iter.getIterRoot());
                    builder = Stream.builder();
                    try {
                        while (iter.hasNext()) {
                            currentUserNode = iter.next();
                            tracerInner2 = tracerInner.child("p" + iter.getPosition());
                            tracerInner2.log("Trying position.");
                            ruleInt = 0;
                            tracerInner2.logEmpty("No applicable rules.", (Iterable<UnifyRule>)set.applicableOnUserNode(currentUserNode, iter.getMatHorizon())).iterator();
                            while (iterator.hasNext()) {
                                rule = iterator.next();
                                new StringBuilder().append("r");
                                ruleInt++;
                                ruleTracer = bupTracer.child(sb2.append(n2).toString());
                                this.terminator.checkTerm();
                                ptr = new ReflectionPtr(this.materialization, this, matNode);
                                result = rule.apply(UnifyRuleCall.createCall(tracer, rule, currentUserNode, matNode.getRel(), ptr));
                                if (result != null) {
                                    ruleTracer.log(rule.getName() + ": Found match.", currentUserNode, rule.getQueryOperand().getHorizon(), matNode.getRel(), rule.getTargetOperand().getHorizon(), result.result);
                                    if (matNode.isRoot()) {
                                        builder.add(iter.generateCandidate(result.result, ptr));
                                        if (currentUserNode instanceof ExpansionLeafNode) {
                                            this.remaining.remove(currentUserNode);
                                        }
                                        ruleTracer.log("Full block match", result.result);
                                    }
                                    else {
                                        newIterator = iter.replicateWithReplace(result.result);
                                        matNode.addMatch(newIterator);
                                    }
                                }
                                else {
                                    ruleTracer.log(rule.getName() + ": No match.", currentUserNode, rule.getQueryOperand().getHorizon(), matNode.getRel(), rule.getTargetOperand().getHorizon());
                                }
                            }
                        }
                    }
                    catch (Exception | AssertionError ex) {
                        e = t;
                        this.handleError(e);
                    }
                    return builder.build();
                });
            }
            catch (Exception | AssertionError ex2) {
                e2 = t2;
                this.handleError(e2);
                return Stream.empty();
            }
        });
        return parentCandidates;
    }
    
    private void handleError(final Throwable e) {
        Throwables.throwIfInstanceOf(e, (Class)PlanningTerminator.PlanningTerminationException.class);
        this.tracer.addError((Exception)UserException.planError(e).message("Failure while attempting substitution, skipping materialization %s", new Object[] { this.materialization.getMaterializationId() }).build(MatBlock.logger));
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)MatBlock.class);
    }
    
    private static class ChildCandidate
    {
        private final RelNode originalBlockRoot;
        private final RelNode newBlockRoot;
        private final ReflectionPtr reflection;
        
        public ChildCandidate(final RelNode originalBlockRoot, final RelNode newBlockRoot, final ReflectionPtr reflection) {
            this.originalBlockRoot = originalBlockRoot;
            this.newBlockRoot = newBlockRoot;
            this.reflection = reflection;
        }
        
        public ReflectionPtr getReflection() {
            return this.reflection;
        }
        
        public RelNode getOriginalBlockRoot() {
            return this.originalBlockRoot;
        }
        
        public RelNode getNewBlockRoot() {
            return this.newBlockRoot;
        }
        
        @Override
        public String toString() {
            final StringBuilder builder = new StringBuilder();
            builder.append("ChildCandidate [originalBlockRoot=").append(this.originalBlockRoot).append(", newBlockRoot=").append(this.newBlockRoot).append("]");
            return builder.toString();
        }
    }
    
    private static class SubIteratorCollector extends RoutingShuttle
    {
        private final BlockCandidate candidate;
        private final List<SubIterator> iterators;
        
        public SubIteratorCollector(final BlockCandidate candidate) {
            this.iterators = new ArrayList<SubIterator>();
            this.candidate = candidate;
        }
        
        protected RelNode visitChildren(final RelNode rel) {
            final int size = rel.getInputs().size();
            switch (size) {
                case 0: {
                    this.iterators.add(new SubIterator(this.candidate, this.candidate.getBlockRoot(), -1));
                    return rel;
                }
                case 1: {
                    return super.visitChildren(rel);
                }
                default: {
                    return rel;
                }
            }
        }
    }
}
