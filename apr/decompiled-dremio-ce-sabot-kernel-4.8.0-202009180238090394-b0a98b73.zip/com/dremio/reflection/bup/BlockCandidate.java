package com.dremio.reflection.bup;

import org.apache.calcite.rel.*;

public class BlockCandidate
{
    private final RelNode originalBlockRoot;
    private final RelNode blockRoot;
    private final RelNode blockLeaf;
    private final ReflectionPtr reflection;
    
    public BlockCandidate(final RelNode originalBlockRoot, final RelNode blockRoot, final RelNode blockLeaf, final ReflectionPtr reflection) {
        this.originalBlockRoot = originalBlockRoot;
        this.blockRoot = blockRoot;
        this.blockLeaf = blockLeaf;
        this.reflection = reflection;
    }
    
    public RelNode getOriginalBlockRoot() {
        return this.originalBlockRoot;
    }
    
    public RelNode getBlockRoot() {
        return this.blockRoot;
    }
    
    public RelNode getBlockLeaf() {
        return this.blockLeaf;
    }
    
    public ReflectionPtr getReflection() {
        return this.reflection;
    }
}
