package com.dremio.reflection.bup;

import org.apache.calcite.rel.*;
import java.util.*;
import com.google.common.collect.*;
import com.google.common.base.*;

public class MatNode
{
    private final Type type;
    private final RelNode rel;
    private final MatNode child;
    private final UnifyRuleSet validRules;
    private final MunifyRuleSet validMRules;
    private final boolean root;
    private final List<SubIterator> leafIterators;
    private final int maxHorizon;
    private final int nodeCount;
    private final List<SubIterator> matchingIterators;
    
    public MatNode(final UnifyRuleSet ruleSet, final MunifyRuleSet multiRuleSet, final RelNode rel, final MatNode child, final int nodeOrdinal, final boolean root, final List<SubIterator> leafIterators) {
        this.matchingIterators = new ArrayList<SubIterator>(4);
        this.rel = rel;
        this.root = root;
        this.child = child;
        this.type = Type.getType(rel.getInputs().size());
        this.nodeCount = nodeOrdinal + 1;
        this.validRules = ruleSet.applicableOnMatNode(rel);
        this.validMRules = multiRuleSet.applicableOnMatNode(rel);
        this.leafIterators = leafIterators;
        this.maxHorizon = this.validRules.getMaxHorizon();
    }
    
    public boolean isRoot() {
        return this.root;
    }
    
    public int getMaxHorizon() {
        return this.maxHorizon;
    }
    
    public void clear() {
        this.matchingIterators.clear();
    }
    
    public RelNode getRel() {
        return this.rel;
    }
    
    public int getNodeCount() {
        return this.nodeCount;
    }
    
    public UnifyRuleSet getValidRules() {
        return this.validRules;
    }
    
    public MunifyRuleSet getValidMultiRules() {
        return this.validMRules;
    }
    
    public Iterable<SubIterator> subs() {
        return this.subs(this.validRules.getMaxTargetDepth());
    }
    
    private Iterable<SubIterator> subs(final int depth) {
        if (depth == 0) {
            return (Iterable<SubIterator>)ImmutableList.of();
        }
        if (this.nodeCount == 1) {
            return (Iterable<SubIterator>)FluentIterable.from((Iterable)this.leafIterators).transform((Function)new Function<SubIterator, SubIterator>() {
                public SubIterator apply(final SubIterator input) {
                    input.reset();
                    return input;
                }
            });
        }
        FluentIterable<SubIterator> subs = (FluentIterable<SubIterator>)FluentIterable.from((Iterable)this.child.matchingIterators);
        if (depth > 1) {
            subs = (FluentIterable<SubIterator>)subs.append((Iterable)this.child.subs(depth - 1));
        }
        return (Iterable<SubIterator>)subs.transform((Function)new Function<SubIterator, SubIterator>() {
            public SubIterator apply(final SubIterator input) {
                input.reset();
                return input;
            }
        });
    }
    
    public void addMatch(final SubIterator iter) {
        this.matchingIterators.add(iter);
    }
    
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("MatNode [rel=").append(this.rel).append(", root=").append(this.root).append(", nodeCount=").append(this.nodeCount).append(", matchingIterators=").append(this.matchingIterators).append("]");
        return builder.toString();
    }
    
    public enum Type
    {
        LEAF_NONE(true), 
        LEAF_MULTI(true), 
        SINGLE(false);
        
        private final boolean leaf;
        
        private Type(final boolean leaf) {
            this.leaf = leaf;
        }
        
        public boolean isLeaf() {
            return this.leaf;
        }
        
        public static Type getType(final int childCount) {
            Preconditions.checkArgument(childCount >= 0);
            switch (childCount) {
                case 0: {
                    return Type.LEAF_NONE;
                }
                case 1: {
                    return Type.SINGLE;
                }
                default: {
                    return Type.LEAF_MULTI;
                }
            }
        }
    }
}
