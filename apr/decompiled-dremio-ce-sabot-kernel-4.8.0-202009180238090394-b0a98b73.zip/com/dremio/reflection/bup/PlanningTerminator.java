package com.dremio.reflection.bup;

import java.lang.management.*;

public class PlanningTerminator
{
    private static final boolean IS_DEBUG;
    private final long terminationInMillis;
    private final long terminationTime;
    
    public PlanningTerminator(final long terminationInMillis) {
        this.terminationInMillis = terminationInMillis;
        this.terminationTime = System.currentTimeMillis() + terminationInMillis;
    }
    
    public final void checkTerm() {
        if (!PlanningTerminator.IS_DEBUG && System.currentTimeMillis() >= this.terminationTime) {
            throw new PlanningTerminationException(this.terminationInMillis);
        }
    }
    
    static {
        IS_DEBUG = (ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp") > 0);
    }
    
    public static class PlanningTerminationException extends RuntimeException
    {
        public PlanningTerminationException(final long terminationInMillis) {
            super(String.format("Substitution terminated after timeout of %d milliseconds.", terminationInMillis));
        }
    }
}
