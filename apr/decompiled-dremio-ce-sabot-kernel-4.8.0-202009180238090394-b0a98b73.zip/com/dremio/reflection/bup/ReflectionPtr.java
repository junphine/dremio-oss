package com.dremio.reflection.bup;

import com.dremio.exec.planner.acceleration.*;
import com.google.common.base.*;
import com.dremio.exec.planner.*;
import org.apache.calcite.rel.*;

public class ReflectionPtr extends AbstractRelNode
{
    private final DremioMaterialization materialization;
    private final MatBlock block;
    private final MatNode node;
    
    public ReflectionPtr(final DremioMaterialization materialization, final MatBlock block, final MatNode node) {
        super(node.getRel().getCluster(), node.getRel().getTraitSet());
        this.materialization = materialization;
        this.block = block;
        this.node = node;
        this.rowType = node.getRel().getRowType();
        this.digest = materialization.getReflectionId() + block.getBlockId() + node.getNodeCount();
    }
    
    public RelWriter explainTerms(final RelWriter pw) {
        return pw.item("reflection", (Object)this.materialization.getLayoutInfo().getName()).item("id", (Object)this.materialization.getReflectionId()).item("block", (Object)this.block.getBlockId()).item("node", (Object)this.node.getNodeCount());
    }
    
    public RelNode expandToMaterializationTable() {
        Preconditions.checkArgument(this.block.isRoot(), (Object)"A materialization should only be expanded if the reflection ptr points to the root of the block tree.");
        Preconditions.checkArgument(this.node.isRoot(), (Object)"A materialization should only be expanded if the reflection ptr points to the root node in the root block tree");
        return this.materialization.getTableRel();
    }
    
    public static RelNode expand(final RelNode node) {
        final ApplyReflectionShuttle ars = new ApplyReflectionShuttle();
        final RelNode result = node.accept((RelShuttle)ars);
        Preconditions.checkArgument(ars.applyCount == 1, "Expected one expansion, observed %s", ars.applyCount);
        return result;
    }
    
    public DremioMaterialization getMaterialization() {
        return this.materialization;
    }
    
    private static class ApplyReflectionShuttle extends RoutingShuttle
    {
        private int applyCount;
        
        private ApplyReflectionShuttle() {
            this.applyCount = 0;
        }
        
        public RelNode visit(final RelNode other) {
            if (other instanceof ReflectionPtr) {
                final ReflectionPtr rf = (ReflectionPtr)other;
                ++this.applyCount;
                return (RelNode)new MaterializationPointer(rf.expandToMaterializationTable());
            }
            return super.visit(other);
        }
    }
    
    static class MaterializationPointer extends SingleRel
    {
        public MaterializationPointer(final RelNode tableRel) {
            super(tableRel.getCluster(), tableRel.getTraitSet(), tableRel);
        }
    }
}
