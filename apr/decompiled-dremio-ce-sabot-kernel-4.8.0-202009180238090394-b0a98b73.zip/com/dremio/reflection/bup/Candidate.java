package com.dremio.reflection.bup;

import java.util.*;
import com.dremio.exec.planner.acceleration.*;
import org.apache.calcite.plan.*;
import com.dremio.exec.planner.acceleration.substitution.*;
import com.dremio.exec.planner.*;
import com.dremio.reflection.rules.*;
import org.apache.calcite.rel.*;

public class Candidate
{
    private final RelNode root;
    private final RelNode replacement;
    private final List<DremioMaterialization> usedMaterializations;
    
    public Candidate(final RelNode root, final RelNode replacement, final List<DremioMaterialization> usedMaterializations) {
        this.root = root;
        this.replacement = replacement;
        this.usedMaterializations = usedMaterializations;
    }
    
    public RelNode getRoot() {
        return this.root;
    }
    
    public RelNode getReplacement() {
        return this.replacement;
    }
    
    public List<DremioMaterialization> getUsedMaterializations() {
        return this.usedMaterializations;
    }
    
    public boolean usesMaterialization() {
        return !this.usedMaterializations.isEmpty();
    }
    
    @Override
    public String toString() {
        return "Candidate [root=" + RelOptUtil.toString(this.root) + ", usedMaterializations=" + this.usedMaterializations + "]";
    }
    
    public int getId() {
        int result = 17;
        result = 31 * result + SubstitutionUtils.hash(this.root);
        result = 31 * result + SubstitutionUtils.hash(this.replacement);
        return result;
    }
    
    public RelNode getReplacementPlan() {
        return this.root.accept((RelShuttle)new RoutingShuttle() {
            public RelNode visit(final RelNode other) {
                if (other instanceof ReplacementPointer) {
                    return ((ReplacementPointer)other).getReplacement();
                }
                return super.visit(other);
            }
        });
    }
}
