package com.dremio.reflection.bup;

import org.apache.calcite.plan.*;
import java.util.*;
import com.dremio.exec.planner.acceleration.*;
import com.dremio.exec.planner.acceleration.substitution.*;
import com.google.common.collect.*;
import java.util.stream.*;
import com.dremio.exec.planner.physical.visitor.*;
import com.dremio.service.*;
import org.apache.calcite.rel.*;
import com.google.common.base.*;
import com.dremio.common.exceptions.*;
import com.dremio.exec.planner.acceleration.normalization.*;
import org.slf4j.*;
import com.dremio.reflection.rules.*;

public class BupFinder
{
    private static final Logger logger;
    private static final UnifyRuleSet RULES;
    private static final MunifyRuleSet MULTI_RULES;
    private final PlanningTerminator terminator;
    private final BupTracer tracer;
    private final RelOptCluster cluster;
    private final RelNode candidateQuery;
    private final List<DremioMaterialization> materializations;
    private final Predicate<RelNode> resultValidationPredicate;
    private final List<ExpansionLeafNode> remaining;
    
    public BupFinder(final PlanningTerminator terminator, final BupTracer tracer, final RelOptCluster cluster, final RelNode candidateQuery, final List<DremioMaterialization> materializations, final Predicate<RelNode> resultValidationPredicate) {
        this.terminator = terminator;
        this.tracer = tracer;
        this.cluster = cluster;
        this.candidateQuery = candidateQuery;
        this.materializations = materializations;
        this.resultValidationPredicate = resultValidationPredicate;
        this.remaining = (List<ExpansionLeafNode>)ImmutableList.of();
    }
    
    public BupFinder(final PlanningTerminator terminator, final BupTracer tracer, final RelOptCluster cluster, final RelNode candidateQuery, final List<DremioMaterialization> materializations, final Predicate<RelNode> resultValidationPredicate, final List<ExpansionLeafNode> remaining) {
        this.terminator = terminator;
        this.tracer = tracer;
        this.cluster = cluster;
        this.candidateQuery = candidateQuery;
        this.materializations = materializations;
        this.resultValidationPredicate = resultValidationPredicate;
        this.remaining = remaining;
    }
    
    public RelOptCluster getCluster() {
        return this.cluster;
    }
    
    public boolean isTraceEnabled() {
        return this.tracer.isTraceEnabled();
    }
    
    public Stream<Candidate> generateAlternatives() {
        final RelNode uniquifiedCandidateQuery = CrelUniqifier.uniqifyGraph(this.candidateQuery);
        final Pointer<Integer> mNum = (Pointer<Integer>)new Pointer((Object)0);
        BlockFinder bf;
        BupTracer tracer;
        final Pointer pointer;
        Integer n;
        final Object value;
        final StringBuilder sb;
        BupTracer childTracer;
        MatBlock block;
        final RelNode startingCandidateQuery;
        final RelNode cleaned;
        return this.materializations.stream().flatMap(m -> {
            try {
                bf = new BlockFinder(false);
                m.getQueryRel().accept((RelShuttle)bf);
                tracer = this.tracer;
                new StringBuilder().append("m");
                n = (Integer)pointer.value;
                (int)pointer.value + 1;
                pointer.value = value;
                childTracer = tracer.child(sb.append(n).toString());
                childTracer.log("Evaluating reflection", m);
                block = new MatBlock(childTracer, this.terminator, m, bf.getRoot(), bf.getMaxLevel() + 1, BupFinder.RULES, BupFinder.MULTI_RULES, this.resultValidationPredicate, this.remaining);
                return block.generateCandidates(startingCandidateQuery, m);
            }
            catch (RuntimeException ex) {
                Throwables.throwIfInstanceOf((Throwable)ex, (Class)PlanningTerminator.PlanningTerminationException.class);
                this.tracer.addError((Exception)UserException.planError((Throwable)ex).message("Failure while attempting substitution, skipping materialization %s", new Object[] { m.getMaterializationId() }).build(BupFinder.logger));
                return Stream.empty();
            }
        }).filter(Candidate::usesMaterialization).map(c -> {
            cleaned = Normalizers.QUERY_NORMALIZER.normalize(c.getRoot());
            return new Candidate(cleaned, c.getReplacement(), c.getUsedMaterializations());
        });
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)BupFinder.class);
        RULES = new UnifyRuleSet(new UnifyRule[] { TrivialRule.INSTANCE, ScanToScanUnifyRule.INSTANCE, SortProjectToSortUnifyRule.INSTANCE, ScanToProjectOnScanUnifyRule.INSTANCE, ProjectToProjectUnifyRule.INSTANCE, WindowToWindowUnifyRule.INSTANCE, WindowOnProjectToWindowUnifyRule.INSTANCE, ProjectToWindowUnifyRule.INSTANCE, ProjectOnFilterToProjectUnifyRule.INSTANCE, FilterToProjectUnifyRule.INSTANCE, AggregateOnFilterToAggregateUnifyRule.INSTANCE, AggregateOnProjectOnFilterToAggregateUnifyRule.INSTANCE, AggregateToProjectUnifyRule.INSTANCE, FilterToFilterUnifyRule.INSTANCE, AggregateToAggregateUnifyRule.INSTANCE, AggregateOnProjectToAggregateUnifyRule.INSTANCE });
        MULTI_RULES = new MunifyRuleSet(new MunifyRule[] { MultiJoinToMultiJoinMunifyRule.INSTANCE, TrivialMunifyRule.INSTANCE });
    }
}
