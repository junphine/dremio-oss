package com.dremio.reflection.bup;

import org.apache.calcite.rel.*;
import com.dremio.exec.planner.*;
import com.dremio.exec.calcite.logical.*;

public class RowCountReplacer
{
    private final double discount;
    
    public RowCountReplacer(final double discount) {
        this.discount = discount;
    }
    
    public RelNode updateRowCount(final RelNode node) {
        return node.accept((RelShuttle)new MaterializationFinder());
    }
    
    private class MaterializationFinder extends RoutingShuttle
    {
        public RelNode visit(final RelNode other) {
            if (!(other instanceof ReflectionPtr.MaterializationPointer)) {
                return super.visit(other);
            }
            if (RowCountReplacer.this.discount == 1.0) {
                return ((ReflectionPtr.MaterializationPointer)other).getInput();
            }
            return ((ReflectionPtr.MaterializationPointer)other).getInput().accept((RelShuttle)new ReplacingShuttle());
        }
    }
    
    private class ReplacingShuttle extends RoutingShuttle
    {
        public RelNode visit(final RelNode other) {
            if (other instanceof ScanCrel) {
                return (RelNode)((ScanCrel)other).applyRowDiscount(RowCountReplacer.this.discount);
            }
            return super.visit(other);
        }
    }
}
