package com.dremio.reflection.bup;

import com.dremio.reflection.rules.*;
import com.google.common.collect.*;
import org.apache.calcite.rel.*;
import com.google.common.base.*;
import java.util.*;

public class MunifyRuleSet implements Iterable<MunifyRule>
{
    private final FluentIterable<MunifyRule> rules;
    
    public MunifyRuleSet(final MunifyRule... rules) {
        this((FluentIterable<MunifyRule>)FluentIterable.from((Object[])rules));
    }
    
    private MunifyRuleSet(final FluentIterable<MunifyRule> rules) {
        this.rules = rules;
    }
    
    public MunifyRuleSet applicableOnMatNode(final RelNode n) {
        return new MunifyRuleSet((FluentIterable<MunifyRule>)this.rules.filter((Predicate)new Predicate<MunifyRule>() {
            public boolean apply(final MunifyRule input) {
                return input.getTargetOperand().matches(n);
            }
        }));
    }
    
    @Override
    public Iterator<MunifyRule> iterator() {
        return (Iterator<MunifyRule>)this.rules.iterator();
    }
    
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("UnifyRuleSet [rules=").append(this.rules).append("]");
        return builder.toString();
    }
}
