package com.dremio.reflection.bup;

import com.google.common.collect.*;
import com.dremio.exec.planner.acceleration.*;
import com.google.common.base.*;
import com.dremio.reflection.rules.*;
import org.apache.calcite.rel.*;
import java.util.*;

class SubIterator
{
    private final BlockCandidate parentCandidate;
    private final RelNode root;
    private final int materOffset;
    private final ImmutableList<RelNode> nodes;
    private int position;
    
    public SubIterator(final BlockCandidate parentCandidate, final RelNode root, final int materOffset) {
        this.parentCandidate = parentCandidate;
        this.root = root;
        this.materOffset = materOffset;
        this.position = materOffset;
        final SubTreeCollector stc = new SubTreeCollector();
        stc.add(root);
        this.nodes = (ImmutableList<RelNode>)ImmutableList.copyOf((Collection)stc.list);
    }
    
    public RelNode getIterRoot() {
        return (RelNode)this.nodes.get(this.nodes.size() - 1);
    }
    
    public DremioMaterialization getMaterialization() {
        return this.parentCandidate.getReflection().getMaterialization();
    }
    
    public void reset() {
        this.position = this.materOffset;
    }
    
    public boolean hasNext() {
        return this.nodes.size() > this.position + 1;
    }
    
    public RelNode next() {
        Preconditions.checkArgument(this.hasNext(), (Object)"No more elements.");
        ++this.position;
        return (RelNode)this.nodes.get(this.position);
    }
    
    public BlockCandidate generateCandidate(final RelNode alternative, final ReflectionPtr ptr) {
        final RelNode currentNode = (RelNode)this.nodes.get(this.position);
        final RelNode newRoot = ReplacementShuttle.replace(this.root, currentNode, alternative).accept((RelShuttle)MunifyCreatedLateBlock.MUNIFY_LATE_BLOCK_RESOLVER);
        return new BlockCandidate(this.parentCandidate.getOriginalBlockRoot(), newRoot, null, ptr);
    }
    
    public SubIterator replicateWithReplace(final RelNode alternative) {
        final RelNode currentNode = (RelNode)this.nodes.get(this.position);
        final RelNode newRoot = ReplacementShuttle.replace(this.root, currentNode, alternative);
        return new SubIterator(this.parentCandidate, newRoot, 0);
    }
    
    public int getMatHorizon() {
        return this.position - this.materOffset;
    }
    
    public int getPosition() {
        return this.position;
    }
    
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("SubIterator [root=").append(this.root).append(", materOffset=").append(this.materOffset).append(", nodes=").append(this.nodes).append(", position=").append(this.position).append("]");
        return builder.toString();
    }
    
    private static class SubTreeCollector
    {
        private LinkedList<RelNode> list;
        
        private SubTreeCollector() {
            this.list = new LinkedList<RelNode>();
        }
        
        private void add(final RelNode rn) {
            this.list.addFirst(rn);
            final List<RelNode> children = (List<RelNode>)rn.getInputs();
            switch (children.size()) {
                case 0: {}
                case 1: {
                    this.add(children.get(0));
                }
                default: {}
            }
        }
    }
}
