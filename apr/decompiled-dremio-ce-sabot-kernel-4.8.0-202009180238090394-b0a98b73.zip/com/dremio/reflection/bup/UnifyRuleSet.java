package com.dremio.reflection.bup;

import com.dremio.reflection.rules.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.calcite.rel.*;
import com.google.common.base.*;

public class UnifyRuleSet implements Iterable<UnifyRule>
{
    private static final UnifyRuleSet EMPTY;
    private final FluentIterable<UnifyRule> rules;
    private final int maxUserHorizon;
    private final int maxTargetDepth;
    
    public UnifyRuleSet(final UnifyRule... rules) {
        this((FluentIterable<UnifyRule>)FluentIterable.from((Object[])rules));
    }
    
    private UnifyRuleSet(final FluentIterable<UnifyRule> rules) {
        this.rules = rules;
        int max = 0;
        int newMaxTargetDepth = 0;
        for (final UnifyRule r : rules) {
            max = Math.max(max, r.getQueryOperand().getHorizon());
            newMaxTargetDepth = Math.max(newMaxTargetDepth, r.getTargetOperand().getHorizon());
        }
        this.maxUserHorizon = max;
        this.maxTargetDepth = newMaxTargetDepth;
    }
    
    public int getMaxTargetDepth() {
        return this.maxTargetDepth;
    }
    
    public UnifyRuleSet applicableOnMatNode(final RelNode n) {
        return new UnifyRuleSet((FluentIterable<UnifyRule>)this.rules.filter((Predicate)new Predicate<UnifyRule>() {
            public boolean apply(final UnifyRule input) {
                return input.getTargetOperand().matches(n);
            }
        }));
    }
    
    public UnifyRuleSet applicableOnUserNode(final RelNode n, final int matHorizon) {
        if (matHorizon > this.maxUserHorizon) {
            return UnifyRuleSet.EMPTY;
        }
        return new UnifyRuleSet((FluentIterable<UnifyRule>)this.rules.filter((Predicate)new Predicate<UnifyRule>() {
            public boolean apply(final UnifyRule input) {
                return input.getQueryOperand().getHorizon() == matHorizon && input.getQueryOperand().matches(n);
            }
        }));
    }
    
    @Override
    public Iterator<UnifyRule> iterator() {
        return (Iterator<UnifyRule>)this.rules.iterator();
    }
    
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("UnifyRuleSet [rules=").append(this.rules).append("]");
        return builder.toString();
    }
    
    public int getMaxHorizon() {
        int max = 0;
        for (final UnifyRule r : this.rules) {
            max = Math.max(max, r.getQueryOperand().getHorizon());
        }
        return max;
    }
    
    static {
        EMPTY = new UnifyRuleSet(new UnifyRule[0]);
    }
}
