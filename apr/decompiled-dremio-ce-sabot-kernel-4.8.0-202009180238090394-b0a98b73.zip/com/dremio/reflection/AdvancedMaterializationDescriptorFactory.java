package com.dremio.reflection;

import com.dremio.service.reflection.proto.*;
import com.dremio.service.namespace.dataset.proto.*;
import com.dremio.service.reflection.*;
import com.dremio.exec.planner.acceleration.*;
import com.google.common.collect.*;
import com.google.common.base.*;
import java.util.*;
import com.dremio.service.job.proto.*;
import org.slf4j.*;

public class AdvancedMaterializationDescriptorFactory implements MaterializationDescriptorFactory
{
    private static final Logger logger;
    
    public MaterializationDescriptor getMaterializationDescriptor(final ReflectionGoal reflectionGoal, final ReflectionEntry reflectionEntry, final Materialization materialization, final double originalCost) {
        final IncrementalUpdateSettings updateSettings = new IncrementalUpdateSettings(reflectionEntry.getRefreshMethod() == RefreshMethod.INCREMENTAL, reflectionEntry.getRefreshField());
        return new MaterializationDescriptor(ReflectionUtils.toReflectionInfo(reflectionGoal), materialization.getId().getId(), materialization.getTag(), (long)materialization.getExpiration(), materialization.getLogicalPlan().toByteArray(), ReflectionUtils.getMaterializationPath(materialization), originalCost, (long)materialization.getInitRefreshSubmit(), ReflectionUtils.getPartitionNames(materialization.getPartitionList()), updateSettings, toSnowflakeSchemaProperties(materialization.getJoinAnalysis()), materialization.getLogicalPlanStrippedHash());
    }
    
    public static JoinDependencyProperties toSnowflakeSchemaProperties(final JoinAnalysis joinAnalysis) {
        if (joinAnalysis == null || joinAnalysis.getJoinStatsList() == null || joinAnalysis.getJoinStatsList().isEmpty()) {
            AdvancedMaterializationDescriptorFactory.logger.debug("No join stats found");
            return null;
        }
        if (!validateJoinConditions(joinAnalysis)) {
            return null;
        }
        AdvancedMaterializationDescriptorFactory.logger.debug("Computing join dependency properties from joinAnalysis: {}", (Object)joinAnalysis);
        try {
            final Map<Integer, JoinTable> joinTableMap = (Map<Integer, JoinTable>)FluentIterable.from((Iterable)joinAnalysis.getJoinTablesList()).uniqueIndex((Function)new Function<JoinTable, Integer>() {
                public Integer apply(final JoinTable joinTable) {
                    return joinTable.getTableId();
                }
            });
            final List<JoinDependencyProperties.Dependency> dependencies = (List<JoinDependencyProperties.Dependency>)FluentIterable.from((Iterable)joinAnalysis.getJoinStatsList()).transformAndConcat((Function)new Function<JoinStats, Iterable<JoinDependencyProperties.Dependency>>() {
                public Iterable<JoinDependencyProperties.Dependency> apply(final JoinStats joinStats) {
                    final List<JoinDependencyProperties.Dependency> dependencies = new ArrayList<JoinDependencyProperties.Dependency>();
                    if (!isBuildCardinalityPreserving(joinStats)) {
                        final List<String> buildPath = (List<String>)joinTableMap.get(joinStats.getJoinConditionsList().get(0).getBuildSideTableId()).getTableSchemaPathList();
                        final List<String> probePath = (List<String>)joinTableMap.get(joinStats.getJoinConditionsList().get(0).getProbeSideTableId()).getTableSchemaPathList();
                        dependencies.add(new JoinDependencyProperties.Dependency((List)probePath, (List)buildPath));
                    }
                    if (!isProbeCardinalityPreserving(joinStats)) {
                        final List<String> buildPath = (List<String>)joinTableMap.get(joinStats.getJoinConditionsList().get(0).getBuildSideTableId()).getTableSchemaPathList();
                        final List<String> probePath = (List<String>)joinTableMap.get(joinStats.getJoinConditionsList().get(0).getProbeSideTableId()).getTableSchemaPathList();
                        dependencies.add(new JoinDependencyProperties.Dependency((List)buildPath, (List)probePath));
                    }
                    return dependencies;
                }
            }).toList();
            AdvancedMaterializationDescriptorFactory.logger.debug("Found join dependencies: {}", (Object)dependencies);
            return new JoinDependencyProperties((List)dependencies);
        }
        catch (Exception e) {
            AdvancedMaterializationDescriptorFactory.logger.debug("Caught exception while finding join dependencies", (Throwable)e);
            return null;
        }
    }
    
    private static boolean validateJoinConditions(final JoinAnalysis analysis) {
        return FluentIterable.from((Iterable)analysis.getJoinStatsList()).allMatch((Predicate)new Predicate<JoinStats>() {
            public boolean apply(final JoinStats joinStats) {
                if (joinStats.getJoinConditionsList() == null) {
                    return false;
                }
                final Set<Integer> buildTables = new HashSet<Integer>();
                final Set<Integer> probeTables = new HashSet<Integer>();
                for (final JoinCondition stats : joinStats.getJoinConditionsList()) {
                    buildTables.add(stats.getBuildSideTableId());
                    probeTables.add(stats.getProbeSideTableId());
                }
                if (buildTables.size() != 1 || probeTables.size() != 1) {
                    AdvancedMaterializationDescriptorFactory.logger.debug("Join does not have distinct build and probe sides; Build table ids: {}, probe table ids: {}", (Object)buildTables, (Object)probeTables);
                }
                return true;
            }
        });
    }
    
    private static boolean isBuildCardinalityPreserving(final JoinStats joinStats) {
        return Objects.equals(joinStats.getBuildInputCount(), joinStats.getOutputRecords()) && (Objects.equals(joinStats.getUnmatchedBuildCount(), 0L) || joinStats.getJoinType() == JoinType.RightOuter || joinStats.getJoinType() == JoinType.FullOuter);
    }
    
    private static boolean isProbeCardinalityPreserving(final JoinStats joinStats) {
        return Objects.equals(joinStats.getProbeInputCount(), joinStats.getOutputRecords()) && (Objects.equals(joinStats.getUnmatchedProbeCount(), 0L) || joinStats.getJoinType() == JoinType.LeftOuter || joinStats.getJoinType() == JoinType.FullOuter);
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)AdvancedMaterializationDescriptorFactory.class);
    }
}
