package com.dremio.reflection;

import com.google.common.collect.*;
import java.util.*;

public interface SubstitutionErrorCollector
{
    public static final SubstitutionErrorCollector NO_OP = new SubstitutionErrorCollector() {};
    
    default void addError(final Exception e) {
    }
    
    public static class ListErrorCollector implements SubstitutionErrorCollector
    {
        private final List<String> errors;
        
        public ListErrorCollector() {
            this.errors = (List<String>)Lists.newArrayList();
        }
        
        @Override
        public void addError(final Exception e) {
            this.errors.add(e.getMessage());
        }
        
        public Iterable<String> getErrors() {
            return (Iterable<String>)ImmutableList.copyOf((Collection)this.errors);
        }
        
        public boolean hasErrors() {
            return !this.errors.isEmpty();
        }
        
        public void clear() {
            this.errors.clear();
        }
    }
}
