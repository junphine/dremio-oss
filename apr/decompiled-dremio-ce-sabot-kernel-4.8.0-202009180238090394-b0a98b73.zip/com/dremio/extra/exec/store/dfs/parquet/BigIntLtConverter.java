package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

public class BigIntLtConverter extends BigIntFilterConverter
{
    @Override
    ParquetFilter getParquetFilter(final ParquetFilter parquetFilter) {
        final BigIntLtFilter filter = (BigIntLtFilter)parquetFilter;
        final Long number = filter.getValue();
        if (this.isGreaterThanIntMax(number)) {
            return this.getAllFilter();
        }
        if (this.isLesserThanIntMin(number)) {
            return this.getNoneFilter();
        }
        return (ParquetFilter)new IntLtFilter((int)(Object)number);
    }
}
