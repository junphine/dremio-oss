package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;

public interface ParquetVarCharFilterConverter
{
    ParquetFilter convertIfNecessary(final ParquetFilter p0, final String p1);
}
