package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.parquet.reader.*;
import java.math.*;

class DecimalEqConverter extends HiveDecimalFilterConverter
{
    @Override
    ParquetFilter transformFilterFromLowerScaleToHigherScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final DecimalEqFilter filter = (DecimalEqFilter)parquetFilter;
        final ComparableDecimal truncatedValue = this.truncateLower(filter.getValue(), fileScale);
        return (ParquetFilter)new DecimalEqFilter(truncatedValue);
    }
    
    @Override
    ParquetFilter transformFilterFromHigherScaleToLowerScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final DecimalEqFilter filter = (DecimalEqFilter)parquetFilter;
        final int newScale = tableScale + 1;
        final ComparableDecimal value = filter.getValue();
        final BigDecimal minusHalf = this.minusHalf(value, newScale);
        final BigDecimal plusHalf = this.plusHalf(value, newScale);
        final boolean minusHalfCanScale = this.decimalCanScaleTo(minusHalf, fileScale);
        final boolean plusHalfCanScale = this.decimalCanScaleTo(plusHalf, fileScale);
        if (minusHalfCanScale && plusHalfCanScale) {
            return this.getBetweenCCFilter(minusHalf, plusHalf);
        }
        if (minusHalfCanScale && !plusHalfCanScale) {
            return this.getGteFilter(minusHalf);
        }
        if (!minusHalfCanScale && plusHalfCanScale) {
            return this.getLteFilter(plusHalf);
        }
        return this.getNoneFilter(value);
    }
}
