package com.dremio.extra.exec.store.dfs.parquet;

import java.util.*;
import com.google.common.collect.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.common.expression.*;
import org.apache.parquet.format.*;
import org.apache.arrow.vector.types.pojo.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;

class BigIntToIntFilterRewriter implements FilterRewriter
{
    private Map<Class, BigIntFilterConverter> bigIntFilterConverterMap;
    
    BigIntToIntFilterRewriter() {
        (this.bigIntFilterConverterMap = (Map<Class, BigIntFilterConverter>)Maps.newHashMap()).put(BigIntEqFilter.class, new BigIntEqConverter());
        this.bigIntFilterConverterMap.put(BigIntLtFilter.class, new BigIntLtConverter());
        this.bigIntFilterConverterMap.put(BigIntLteFilter.class, new BigIntLteConverter());
        this.bigIntFilterConverterMap.put(BigIntGtFilter.class, new BigIntGtConverter());
        this.bigIntFilterConverterMap.put(BigIntGteFilter.class, new BigIntGteConverter());
        this.bigIntFilterConverterMap.put(BigIntBetweenCCFilter.class, new BigIntBetweenCCConverter());
        this.bigIntFilterConverterMap.put(BigIntBetweenCOFilter.class, new BigIntBetweenCOConverter());
        this.bigIntFilterConverterMap.put(BigIntBetweenOCFilter.class, new BigIntBetweenOCConverter());
        this.bigIntFilterConverterMap.put(BigIntBetweenOOFilter.class, new BigIntBetweenOOConverter());
    }
    
    @Override
    public boolean canConvert(final ParquetFilterCondition filterCondition, final CompleteType filterTableColumnType, final SchemaElement filterColumnFileSchemaType) {
        return this.bigIntFilterConverterMap.get(filterCondition.getFilter().getClass()) != null && filterColumnFileSchemaType.type.equals((Object)Type.INT32) && filterTableColumnType.getType().getTypeID().equals((Object)ArrowType.ArrowTypeID.Int) && ((ArrowType.Int)filterTableColumnType.getType()).getBitWidth() == 64;
    }
    
    @Override
    public ParquetFilterIface convertIfNecessary(final ParquetFilterCondition filterCondition, final SchemaDerivationHelper schemaHelper, final String filteredColumn, final SchemaElement filterColumnFileSchemaType) {
        final ParquetFilter filter = (ParquetFilter)filterCondition.getFilter();
        return (ParquetFilterIface)this.bigIntFilterConverterMap.get(filter.getClass()).getParquetFilter(filter);
    }
}
