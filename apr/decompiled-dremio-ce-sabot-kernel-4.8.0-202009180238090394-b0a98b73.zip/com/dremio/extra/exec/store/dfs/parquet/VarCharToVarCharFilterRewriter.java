package com.dremio.extra.exec.store.dfs.parquet;

import java.util.*;
import org.apache.commons.collections4.map.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.common.expression.*;
import org.apache.parquet.format.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;

public class VarCharToVarCharFilterRewriter implements FilterRewriter
{
    private final Map<Class, ParquetVarCharFilterConverter> varcharFiltersMap;
    
    VarCharToVarCharFilterRewriter(final ManagedSchema managedSchema) {
        (this.varcharFiltersMap = (Map<Class, ParquetVarCharFilterConverter>)new DefaultedMap((Object)new DefaultVarCharFilterConverter())).put(VarCharEqFilter.class, new VarCharEqFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharLtFilter.class, new VarCharLtFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharLteFilter.class, new VarCharLteFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharGtFilter.class, new VarCharGtFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharGteFilter.class, new VarCharGteFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharBetweenCCFilter.class, new VarCharBetweenCCFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharBetweenCOFilter.class, new VarCharBetweenCOFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharBetweenOOFilter.class, new VarCharBetweenOOFilterConverter(managedSchema));
        this.varcharFiltersMap.put(VarCharBetweenOCFilter.class, new VarCharBetweenOCFilterConverter(managedSchema));
    }
    
    @Override
    public boolean canConvert(final ParquetFilterCondition filterCondition, final CompleteType filterTableColumnType, final SchemaElement filterColumnFileSchemaType) {
        return this.varcharFiltersMap.get(filterCondition.getFilter().getClass()) != null && filterTableColumnType.isText();
    }
    
    @Override
    public ParquetFilterIface convertIfNecessary(final ParquetFilterCondition filterCondition, final SchemaDerivationHelper schemaHelper, final String filteredColumn, final SchemaElement filterColumnFileSchemaType) {
        final ParquetFilter filter = (ParquetFilter)filterCondition.getFilter();
        return (ParquetFilterIface)this.varcharFiltersMap.get(filter.getClass()).convertIfNecessary(filter, filteredColumn);
    }
}
