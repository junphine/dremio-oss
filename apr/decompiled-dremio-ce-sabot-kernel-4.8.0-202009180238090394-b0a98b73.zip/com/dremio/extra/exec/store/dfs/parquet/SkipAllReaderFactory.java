package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.metadata.*;
import com.dremio.parquet.reader.*;
import java.util.*;
import com.dremio.common.expression.*;
import org.apache.arrow.vector.*;

public class SkipAllReaderFactory implements ReaderFactory
{
    public void close() throws Exception {
    }
    
    public Reader newRowGroupReader(final RowGroupMetadata rowGroupMetadata) {
        return (Reader)new Reader() {
            public int eval() {
                return 0;
            }
            
            public List<SchemaPath> getColumnsToBoost() {
                return null;
            }
            
            public void close() {
            }
        };
    }
    
    public SimpleIntVector getDeltas() {
        return null;
    }
}
