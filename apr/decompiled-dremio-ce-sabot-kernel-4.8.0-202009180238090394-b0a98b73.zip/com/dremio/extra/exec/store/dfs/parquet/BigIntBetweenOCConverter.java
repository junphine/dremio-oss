package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

public class BigIntBetweenOCConverter extends BigIntBetweenConverter
{
    @Override
    ParquetFilter getFilterStartLessThanMinInt(final Long rangeEnd) {
        return (ParquetFilter)new IntLteFilter((int)(Object)rangeEnd);
    }
    
    @Override
    ParquetFilter getFilterEndGreaterThanMaxInt(final Long rangeStart) {
        return (ParquetFilter)new IntGtFilter((int)(Object)rangeStart);
    }
    
    @Override
    ParquetFilter getFilterBothInRange(final Long rangeStart, final Long rangeEnd) {
        return (ParquetFilter)new IntBetweenOCFilter((int)(Object)rangeStart, (int)(Object)rangeEnd);
    }
    
    @Override
    Long getStartValue(final ParquetFilter parquetFilter) {
        return ((BigIntBetweenOCFilter)parquetFilter).getStart();
    }
    
    @Override
    Long getEndValue(final ParquetFilter parquetFilter) {
        return ((BigIntBetweenOCFilter)parquetFilter).getEnd();
    }
}
