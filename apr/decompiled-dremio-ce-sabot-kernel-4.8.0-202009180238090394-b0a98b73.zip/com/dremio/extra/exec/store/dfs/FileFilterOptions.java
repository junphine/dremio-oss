package com.dremio.extra.exec.store.dfs;

import com.dremio.options.*;

@Options
public interface FileFilterOptions
{
    public static final TypeValidators.BooleanValidator ENABLE_PARQUET_FILTER_PUSHDOWN = new TypeValidators.BooleanValidator("planner.enable_parquet_filter_pushdown", true);
}
