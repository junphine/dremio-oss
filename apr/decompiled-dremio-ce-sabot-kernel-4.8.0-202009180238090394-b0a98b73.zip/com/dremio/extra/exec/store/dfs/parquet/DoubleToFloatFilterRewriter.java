package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.common.expression.*;
import org.apache.arrow.vector.types.pojo.*;
import org.apache.arrow.vector.types.*;
import org.apache.parquet.format.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

class DoubleToFloatFilterRewriter implements FilterRewriter
{
    @Override
    public boolean canConvert(final ParquetFilterCondition filterCondition, final CompleteType filterTableColumnType, final SchemaElement filterColumnFileSchemaType) {
        return filterTableColumnType.getType().getTypeID() == ArrowType.ArrowTypeID.FloatingPoint && ((ArrowType.FloatingPoint)filterTableColumnType.getType()).getPrecision() == FloatingPointPrecision.DOUBLE && filterColumnFileSchemaType.getType() == Type.FLOAT;
    }
    
    @Override
    public ParquetFilterIface convertIfNecessary(final ParquetFilterCondition filterCondition, final SchemaDerivationHelper schemaHelper, final String filteredColumn, final SchemaElement filterColumnFileSchemaType) {
        final ParquetFilter filter = (ParquetFilter)filterCondition.getFilter();
        switch (Clazz.valueOf(filter.getClass().getSimpleName())) {
            case Float8EqFilter: {
                return (ParquetFilterIface)convertEqFilter(filter);
            }
            case Float8LtFilter: {
                return (ParquetFilterIface)convertLtFilter(filter);
            }
            case Float8LteFilter: {
                return (ParquetFilterIface)convertLteFilter(filter);
            }
            case Float8GtFilter: {
                return (ParquetFilterIface)convertGtFilter(filter);
            }
            case Float8GteFilter: {
                return (ParquetFilterIface)convertGteFilter(filter);
            }
            case Float8BetweenCCFilter: {
                return (ParquetFilterIface)convertBetweenCCFilter(filter);
            }
            case Float8BetweenCOFilter: {
                return (ParquetFilterIface)convertBetweenCOFilter(filter);
            }
            case Float8BetweenOCFilter: {
                return (ParquetFilterIface)convertBetweenOCFilter(filter);
            }
            case Float8BetweenOOFilter: {
                return (ParquetFilterIface)convertBetweenOOFilter(filter);
            }
            case Float8AllFilter: {
                return (ParquetFilterIface)new Float4AllFilter(0.0f);
            }
            case Float8NoneFilter: {
                return (ParquetFilterIface)new Float4NoneFilter(0.0f);
            }
            default: {
                return (ParquetFilterIface)filter;
            }
        }
    }
    
    static ParquetFilter convertEqFilter(final ParquetFilter filter) {
        final double value = ((Float8EqFilter)filter).getValue();
        final float floatValue = (float)value;
        if ((value > 3.4028234663852886E38 && value != Double.POSITIVE_INFINITY) || (value < -3.4028234663852886E38 && value != Double.NEGATIVE_INFINITY)) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        return (ParquetFilter)new Float4EqFilter(floatValue);
    }
    
    static ParquetFilter convertGteFilter(final ParquetFilter filter) {
        final double value = ((Float8GteFilter)filter).getValue();
        if (value < -3.4028234663852886E38 && value != Double.NEGATIVE_INFINITY) {
            return (ParquetFilter)new Float4GteFilter(-3.4028235E38f);
        }
        final float floatValue = (float)value;
        return (ParquetFilter)new Float4GteFilter(floatValue);
    }
    
    static ParquetFilter convertGtFilter(final ParquetFilter filter) {
        final double value = ((Float8GtFilter)filter).getValue();
        if (value == Double.POSITIVE_INFINITY) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        final float floatValue = (float)value;
        return (ParquetFilter)new Float4GteFilter(floatValue);
    }
    
    static ParquetFilter convertLteFilter(final ParquetFilter filter) {
        final double value = ((Float8LteFilter)filter).getValue();
        if (value > 3.4028234663852886E38 && value != Double.POSITIVE_INFINITY) {
            return (ParquetFilter)new Float4LteFilter(Float.MAX_VALUE);
        }
        final float floatValue = (float)value;
        return (ParquetFilter)new Float4LteFilter(floatValue);
    }
    
    static ParquetFilter convertLtFilter(final ParquetFilter filter) {
        final double value = ((Float8LtFilter)filter).getValue();
        if (value == Double.NEGATIVE_INFINITY) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        final float floatValue = (float)value;
        return (ParquetFilter)new Float4LteFilter(floatValue);
    }
    
    static ParquetFilter convertBetweenCCFilter(final ParquetFilter filter) {
        final double start = ((Float8BetweenCCFilter)filter).getStart();
        final double end = ((Float8BetweenCCFilter)filter).getEnd();
        float floatStart = (float)start;
        float floatEnd = (float)end;
        if (start < -3.4028234663852886E38 && start != Double.NEGATIVE_INFINITY) {
            floatStart = -3.4028235E38f;
        }
        if (end > 3.4028234663852886E38 && end != Double.POSITIVE_INFINITY) {
            floatEnd = Float.MAX_VALUE;
        }
        if (floatStart > floatEnd) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        return (ParquetFilter)new Float4BetweenCCFilter(floatStart, floatEnd);
    }
    
    static ParquetFilter convertBetweenCOFilter(final ParquetFilter filter) {
        final double start = ((Float8BetweenCOFilter)filter).getStart();
        final double end = ((Float8BetweenCOFilter)filter).getEnd();
        float floatStart = (float)start;
        final float floatEnd = (float)end;
        if (end == Double.NEGATIVE_INFINITY) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        if (start < -3.4028234663852886E38 && start != Double.NEGATIVE_INFINITY) {
            floatStart = -3.4028235E38f;
        }
        if (floatStart > floatEnd) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        return (ParquetFilter)new Float4BetweenCCFilter(floatStart, floatEnd);
    }
    
    static ParquetFilter convertBetweenOCFilter(final ParquetFilter filter) {
        final double start = ((Float8BetweenOCFilter)filter).getStart();
        final double end = ((Float8BetweenOCFilter)filter).getEnd();
        final float floatStart = (float)start;
        float floatEnd = (float)end;
        if (start == Double.POSITIVE_INFINITY) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        if (end > 3.4028234663852886E38 && end != Double.POSITIVE_INFINITY) {
            floatEnd = Float.MAX_VALUE;
        }
        if (floatStart > floatEnd) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        return (ParquetFilter)new Float4BetweenCCFilter(floatStart, floatEnd);
    }
    
    static ParquetFilter convertBetweenOOFilter(final ParquetFilter filter) {
        final double start = ((Float8BetweenOOFilter)filter).getStart();
        final double end = ((Float8BetweenOOFilter)filter).getEnd();
        final float floatStart = (float)start;
        final float floatEnd = (float)end;
        if (start == Double.POSITIVE_INFINITY || end == Double.NEGATIVE_INFINITY || start > 3.4028234663852886E38 || end < -3.4028234663852886E38 || floatStart > floatEnd) {
            return (ParquetFilter)new Float4NoneFilter(0.0f);
        }
        return (ParquetFilter)new Float4BetweenCCFilter(floatStart, floatEnd);
    }
    
    enum Clazz
    {
        Float8EqFilter, 
        Float8LtFilter, 
        Float8LteFilter, 
        Float8GtFilter, 
        Float8GteFilter, 
        Float8BetweenCCFilter, 
        Float8BetweenCOFilter, 
        Float8BetweenOCFilter, 
        Float8BetweenOOFilter, 
        Float8AllFilter, 
        Float8NoneFilter;
    }
}
