package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.*;
import com.dremio.parquet.reader.filter.*;
import java.math.*;

class DecimalBetweenOOConverter extends DecimalBetweenConverter
{
    @Override
    ComparableDecimal getRangeStart(final ParquetFilter parquetFilter) {
        final DecimalBetweenOOFilter filter = (DecimalBetweenOOFilter)parquetFilter;
        return filter.rangeStart;
    }
    
    @Override
    ComparableDecimal getRangeEnd(final ParquetFilter parquetFilter) {
        final DecimalBetweenOOFilter filter = (DecimalBetweenOOFilter)parquetFilter;
        return filter.rangeEnd;
    }
    
    @Override
    BigDecimal getNewStart(final ParquetFilter parquetFilter, final int scale) {
        final DecimalBetweenOOFilter filter = (DecimalBetweenOOFilter)parquetFilter;
        return this.plusHalf(filter.rangeStart, scale);
    }
    
    @Override
    BigDecimal getNewEnd(final ParquetFilter parquetFilter, final int scale) {
        final DecimalBetweenOOFilter filter = (DecimalBetweenOOFilter)parquetFilter;
        return this.minusHalf(filter.rangeEnd, scale);
    }
}
