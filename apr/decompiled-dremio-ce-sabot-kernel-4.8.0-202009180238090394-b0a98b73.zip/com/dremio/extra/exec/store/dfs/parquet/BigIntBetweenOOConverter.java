package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

public class BigIntBetweenOOConverter extends BigIntBetweenConverter
{
    @Override
    ParquetFilter getFilterStartLessThanMinInt(final Long rangeEnd) {
        return (ParquetFilter)new IntLtFilter((int)(Object)rangeEnd);
    }
    
    @Override
    ParquetFilter getFilterEndGreaterThanMaxInt(final Long rangeStart) {
        return (ParquetFilter)new IntGtFilter((int)(Object)rangeStart);
    }
    
    @Override
    ParquetFilter getFilterBothInRange(final Long rangeStart, final Long rangeEnd) {
        return (ParquetFilter)new IntBetweenOOFilter((int)(Object)rangeStart, (int)(Object)rangeEnd);
    }
    
    @Override
    Long getStartValue(final ParquetFilter parquetFilter) {
        return ((BigIntBetweenOOFilter)parquetFilter).getStart();
    }
    
    @Override
    Long getEndValue(final ParquetFilter parquetFilter) {
        return ((BigIntBetweenOOFilter)parquetFilter).getEnd();
    }
}
