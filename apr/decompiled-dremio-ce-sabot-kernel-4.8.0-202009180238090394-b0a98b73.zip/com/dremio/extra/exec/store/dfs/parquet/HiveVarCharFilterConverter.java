package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.exec.store.parquet.*;
import java.util.function.*;
import com.dremio.parquet.reader.*;
import java.nio.charset.*;
import org.apache.arrow.util.*;

abstract class HiveVarCharFilterConverter implements ParquetVarCharFilterConverter
{
    protected ManagedSchema managedSchema;
    
    public HiveVarCharFilterConverter(final ManagedSchema managedSchema) {
        this.managedSchema = managedSchema;
    }
    
    @Override
    public ParquetFilter convertIfNecessary(final ParquetFilter originalFilter, final String filteredColumn) {
        if (this.managedSchema.isNotValidFixedLenTextField(filteredColumn)) {
            return originalFilter;
        }
        final int fieldLen = this.managedSchema.getField(filteredColumn).map(ManagedSchemaField::getLength).orElse(65536);
        return this.convertIfNecessary(originalFilter, fieldLen);
    }
    
    protected abstract ParquetFilter convertIfNecessary(final ParquetFilter p0, final int p1);
    
    @VisibleForTesting
    protected int length(final ComparableBinary val1) {
        return new String(val1.getBytes(), StandardCharsets.UTF_8).length();
    }
    
    @VisibleForTesting
    protected ComparableBinary trimToFieldSize(final ComparableBinary value, final int fieldLen) {
        final byte[] trimmedVal = new String(value.getBytes(), StandardCharsets.UTF_8).substring(0, fieldLen).getBytes(StandardCharsets.UTF_8);
        return new ComparableBinary(trimmedVal);
    }
    
    @VisibleForTesting
    protected ComparableBinary getNextLexicalValue(final ComparableBinary value) throws MaxLengthReachedException {
        return new ComparableBinary(this.getNextLexicalString(value.getBytes()));
    }
    
    @VisibleForTesting
    protected byte[] getNextLexicalString(final byte[] bytes) throws MaxLengthReachedException {
        final char[] charArr = new String(bytes, StandardCharsets.UTF_8).toCharArray();
        for (int i = charArr.length - 1; i >= 0; --i) {
            if (charArr[i] < '\uffff') {
                final char[] array = charArr;
                final int n = i;
                ++array[n];
                return new String(charArr).getBytes(StandardCharsets.UTF_8);
            }
        }
        throw new MaxLengthReachedException();
    }
    
    protected class MaxLengthReachedException extends Exception
    {
    }
}
