package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

abstract class BigIntFilterConverter
{
    private static final Integer EXAMPLE_INTEGER;
    
    abstract ParquetFilter getParquetFilter(final ParquetFilter p0);
    
    boolean isGreaterThanIntMax(final Long number) {
        return number > 2147483647L;
    }
    
    boolean isLesserThanIntMin(final Long number) {
        return number < -2147483648L;
    }
    
    ParquetFilter getNoneFilter() {
        return (ParquetFilter)new IntNoneFilter((int)BigIntFilterConverter.EXAMPLE_INTEGER);
    }
    
    ParquetFilter getAllFilter() {
        return (ParquetFilter)new IntAllFilter((int)BigIntFilterConverter.EXAMPLE_INTEGER);
    }
    
    static {
        EXAMPLE_INTEGER = 0;
    }
}
