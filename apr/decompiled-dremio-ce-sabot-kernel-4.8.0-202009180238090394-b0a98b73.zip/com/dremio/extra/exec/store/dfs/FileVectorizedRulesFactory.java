package com.dremio.extra.exec.store.dfs;

import com.dremio.exec.ops.*;
import com.dremio.exec.planner.*;
import com.dremio.exec.catalog.conf.*;
import java.util.*;
import com.google.common.collect.*;
import com.dremio.extra.exec.store.dfs.parquet.*;
import com.dremio.exec.store.dfs.*;
import org.apache.calcite.plan.*;
import com.dremio.service.namespace.*;

public class FileVectorizedRulesFactory extends FileSystemRulesFactory
{
    public Set<RelOptRule> getRules(final OptimizerRulesContext optimizerContext, final PlannerPhase phase, final SourceType sourceType) {
        if (phase == PlannerPhase.LOGICAL && optimizerContext.getPlannerSettings().getOptions().getOption(FileFilterOptions.ENABLE_PARQUET_FILTER_PUSHDOWN)) {
            final ImmutableSet.Builder<RelOptRule> builder = (ImmutableSet.Builder<RelOptRule>)ImmutableSet.builder();
            builder.addAll((Iterable)super.getRules(optimizerContext, phase, sourceType));
            builder.add((Object)new FileParquetFilterPushDownRule(sourceType));
            return (Set<RelOptRule>)builder.build();
        }
        return (Set<RelOptRule>)super.getRules(optimizerContext, phase, sourceType);
    }
    
    private static class FileParquetFilterPushDownRule extends ParquetFilterPushDownRule<FilesystemScanDrel>
    {
        public FileParquetFilterPushDownRule(final SourceType sourceType) {
            super(sourceType, FilesystemScanDrel.class);
        }
        
        @Override
        public boolean matches(final RelOptRuleCall call) {
            final FilesystemScanDrel scan = (FilesystemScanDrel)call.rel(1);
            return scan.getFilter() == null && DatasetHelper.hasParquetDataFiles(scan.getTableMetadata().getFormatSettings());
        }
    }
}
