package com.dremio.extra.exec.store.dfs.parquet;

import org.apache.parquet.column.*;
import org.apache.parquet.hadoop.metadata.*;
import com.dremio.sabot.exec.context.*;
import org.apache.parquet.compression.*;
import java.util.*;
import org.apache.arrow.vector.*;
import com.dremio.exec.store.*;
import com.dremio.exec.store.parquet.*;
import com.google.common.collect.*;

public class VectorizedReaderFactory implements ParquetReaderFactory
{
    private static final Set<Encoding> VECTORIZE_ENCODINGS;
    
    public boolean isSupported(final ColumnChunkMetaData chunk) {
        if (!ParquetVectorizedReader.checkType(chunk)) {
            return false;
        }
        final Set<Encoding> observed = (Set<Encoding>)chunk.getEncodings();
        return !observed.isEmpty() && observed.size() <= VectorizedReaderFactory.VECTORIZE_ENCODINGS.size() && VectorizedReaderFactory.VECTORIZE_ENCODINGS.containsAll(observed);
    }
    
    public RecordReader newReader(final OperatorContext context, final ParquetScanProjectedColumns projectedColumns, final String path, final CompressionCodecFactory codecFactory, final List<ParquetFilterCondition> conditions, final ParquetFilterCreator filterCreator, final ParquetDictionaryConvertor dictionaryConvertor, final boolean enableDetailedTracing, final MutableParquetMetadata footer, final int rowGroupIndex, final SimpleIntVector deltas, final SchemaDerivationHelper schemaHelper, final InputStreamProvider inputStreamProvider) {
        return (RecordReader)new ParquetVectorizedReader(context, projectedColumns, path, codecFactory, conditions, filterCreator, dictionaryConvertor, enableDetailedTracing, footer, rowGroupIndex, deltas, schemaHelper, inputStreamProvider);
    }
    
    public ParquetFilterCreator newFilterCreator(final ParquetReaderFactory.ManagedSchemaType managedSchemaType, final ManagedSchema schema) {
        if (managedSchemaType == ParquetReaderFactory.ManagedSchemaType.HIVE) {
            return new HiveParquetFilterCreator(schema);
        }
        if (managedSchemaType == ParquetReaderFactory.ManagedSchemaType.ICEBERG) {
            return new IcebergParquetFilterCreator();
        }
        return ParquetFilterCreator.DEFAULT;
    }
    
    public ParquetDictionaryConvertor newDictionaryConvertor(final ParquetReaderFactory.ManagedSchemaType managedSchemaType, final ManagedSchema schema) {
        if (managedSchemaType == ParquetReaderFactory.ManagedSchemaType.HIVE) {
            return (ParquetDictionaryConvertor)new HiveFixedLenDictionaryConvertor(schema);
        }
        return ParquetDictionaryConvertor.DEFAULT;
    }
    
    static {
        VECTORIZE_ENCODINGS = (Set)ImmutableSet.of((Object)Encoding.BIT_PACKED, (Object)Encoding.PLAIN, (Object)Encoding.RLE, (Object)Encoding.PLAIN_DICTIONARY);
    }
}
