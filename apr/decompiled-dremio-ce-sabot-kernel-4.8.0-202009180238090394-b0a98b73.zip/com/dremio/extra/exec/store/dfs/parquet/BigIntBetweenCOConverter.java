package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

public class BigIntBetweenCOConverter extends BigIntBetweenConverter
{
    @Override
    ParquetFilter getFilterStartLessThanMinInt(final Long rangeEnd) {
        return (ParquetFilter)new IntLtFilter((int)(Object)rangeEnd);
    }
    
    @Override
    ParquetFilter getFilterEndGreaterThanMaxInt(final Long rangeStart) {
        return (ParquetFilter)new IntGteFilter((int)(Object)rangeStart);
    }
    
    @Override
    ParquetFilter getFilterBothInRange(final Long rangeStart, final Long rangeEnd) {
        return (ParquetFilter)new IntBetweenCOFilter((int)(Object)rangeStart, (int)(Object)rangeEnd);
    }
    
    @Override
    Long getStartValue(final ParquetFilter parquetFilter) {
        return ((BigIntBetweenCOFilter)parquetFilter).getStart();
    }
    
    @Override
    Long getEndValue(final ParquetFilter parquetFilter) {
        return ((BigIntBetweenCOFilter)parquetFilter).getEnd();
    }
}
