package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.parquet.reader.*;

class VarCharGtFilterConverter extends HiveVarCharFilterConverter
{
    VarCharGtFilterConverter(final ManagedSchema managedSchema) {
        super(managedSchema);
    }
    
    public ParquetFilter convertIfNecessary(final ParquetFilter originalFilter, final int fieldLen) {
        final ComparableBinary value = ((VarCharGtFilter)originalFilter).getValue();
        if (this.length(value) >= fieldLen) {
            final ComparableBinary truncatedVal = this.trimToFieldSize(value, fieldLen);
            try {
                return (ParquetFilter)new VarCharGteFilter(this.getNextLexicalValue(truncatedVal));
            }
            catch (MaxLengthReachedException e) {
                return (ParquetFilter)new VarCharNoneFilter(value);
            }
        }
        return originalFilter;
    }
}
