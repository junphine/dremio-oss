package com.dremio.extra.exec.store.dfs.parquet;

import org.apache.arrow.memory.*;
import java.util.*;
import com.dremio.exec.store.parquet.*;
import io.netty.util.internal.*;
import org.apache.arrow.util.*;

public class HiveFixedLenDictionaryConvertor implements ParquetDictionaryConvertor
{
    private static final long UTF8_MASK = -9187201950435737472L;
    private final ManagedSchema schema;
    
    public HiveFixedLenDictionaryConvertor(final ManagedSchema schema) {
        this.schema = schema;
    }
    
    public void convertDictionaryBuffer(final ArrowBuf dictionaryBuffer, final int dictionarySize, final Optional<String> colName) {
        if (!colName.isPresent() || this.schema.isNotValidFixedLenTextField((String)colName.get())) {
            return;
        }
        final int fieldLength = this.schema.getField((String)colName.get()).get().getLength();
        int offset = 0;
        for (int i = 0; i < dictionarySize; ++i) {
            final int length = dictionaryBuffer.getInt((long)offset);
            if (length > fieldLength) {
                final int dataStart = offset + 4;
                final int dataEnd = dataStart + length;
                final int fieldByteLen = this.getLenOfFirstNChars(dictionaryBuffer, dataStart, dataEnd, fieldLength);
                dictionaryBuffer.setInt((long)offset, fieldByteLen);
            }
            offset += length + 4;
        }
    }
    
    private int getLenOfFirstNChars(final ArrowBuf buf, final int start, final int end, int nVal) {
        int byteLen;
        int charStart;
        for (byteLen = 0, charStart = start; nVal >= 8 && end - charStart >= 8; nVal -= 8, byteLen += 8, charStart += 8) {
            final long longRepOf8Bytes = PlatformDependent.getLong(buf.memoryAddress() + charStart);
            if (!this.isAllUtf8(longRepOf8Bytes)) {
                break;
            }
        }
        while (nVal-- > 0 && charStart < end) {
            final int thisCharLen = getUTF8CharLen(buf.getByte((long)charStart));
            byteLen += thisCharLen;
            charStart += thisCharLen;
        }
        return byteLen;
    }
    
    @VisibleForTesting
    boolean isAllUtf8(final long longRepOf8Bytes) {
        return 0x0L == (longRepOf8Bytes & 0x8080808080808080L);
    }
    
    private static int getUTF8CharLen(final byte b) {
        final int byte1 = b & 0xFF;
        if (byte1 < 128) {
            return 1;
        }
        if (byte1 >= 240) {
            return 4;
        }
        if (byte1 >= 224) {
            return 3;
        }
        if (byte1 >= 192) {
            return 2;
        }
        throw new RuntimeException("Encountered invalid UTF-8 first byte");
    }
}
