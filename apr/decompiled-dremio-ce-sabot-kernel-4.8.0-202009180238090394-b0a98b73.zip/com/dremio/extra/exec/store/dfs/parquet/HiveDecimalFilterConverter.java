package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.*;
import java.math.*;
import com.dremio.parquet.reader.filter.*;

abstract class HiveDecimalFilterConverter
{
    private static final BigInteger FIVE;
    private static final BigInteger TEN;
    
    abstract ParquetFilter transformFilterFromLowerScaleToHigherScale(final ParquetFilter p0, final int p1, final int p2, final int p3, final int p4);
    
    abstract ParquetFilter transformFilterFromHigherScaleToLowerScale(final ParquetFilter p0, final int p1, final int p2, final int p3, final int p4);
    
    final ParquetFilter transformFilter(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        if (tableScale >= fileScale) {
            return this.transformFilterFromLowerScaleToHigherScale(parquetFilter, tablePrecision, tableScale, filePrecision, fileScale);
        }
        return this.transformFilterFromHigherScaleToLowerScale(parquetFilter, tablePrecision, tableScale, filePrecision, fileScale);
    }
    
    final ComparableDecimal truncateLower(final ComparableDecimal value, final int scale) {
        if (value.getScale() <= scale) {
            return value;
        }
        final BigInteger unscaledInt = value.toBigDecimal().setScale(scale, 3).unscaledValue();
        return new ComparableDecimal(unscaledInt.toByteArray(), scale);
    }
    
    final BigDecimal plusHalf(final ComparableDecimal number, final int scale) {
        BigInteger extendedValue = number.toBigDecimal().unscaledValue();
        for (int i = number.getScale(); i < scale; ++i) {
            extendedValue = extendedValue.multiply(HiveDecimalFilterConverter.TEN);
        }
        return this.calculateUpperBound(extendedValue, scale);
    }
    
    final BigDecimal minusHalf(final ComparableDecimal number, final int scale) {
        BigInteger extendedValue = number.toBigDecimal().unscaledValue();
        for (int i = number.getScale(); i < scale; ++i) {
            extendedValue = extendedValue.multiply(HiveDecimalFilterConverter.TEN);
        }
        return this.calculateLowerBound(extendedValue, scale);
    }
    
    final boolean greaterThanOrEqualToZero(final ComparableDecimal decimal) {
        return decimal.toBigDecimal().signum() >= 0;
    }
    
    private BigDecimal calculateUpperBound(final BigInteger extendedScaleValue, final int scale) {
        return new BigDecimal(extendedScaleValue.add(HiveDecimalFilterConverter.FIVE), scale);
    }
    
    private BigDecimal calculateLowerBound(final BigInteger extendedScaleValue, final int scale) {
        return new BigDecimal(extendedScaleValue.subtract(HiveDecimalFilterConverter.FIVE), scale);
    }
    
    final boolean decimalCanScaleTo(final BigDecimal decimal, final int scale) {
        final int diffScale = scale - decimal.scale();
        return diffScale < 0 || decimal.precision() + diffScale <= 38;
    }
    
    final ParquetFilter getBetweenCCFilter(final BigDecimal start, final BigDecimal end) {
        final ComparableDecimal rangeStart = new ComparableDecimal(start.unscaledValue().toByteArray(), start.scale());
        final ComparableDecimal rangeEnd = new ComparableDecimal(end.unscaledValue().toByteArray(), start.scale());
        return (ParquetFilter)new DecimalBetweenCCFilter(rangeStart, rangeEnd);
    }
    
    final ParquetFilter getGteFilter(final BigDecimal value) {
        final ComparableDecimal rangeStart = new ComparableDecimal(value.unscaledValue().toByteArray(), value.scale());
        return (ParquetFilter)new DecimalGteFilter(rangeStart);
    }
    
    final ParquetFilter getLteFilter(final BigDecimal value) {
        final ComparableDecimal rangeStart = new ComparableDecimal(value.unscaledValue().toByteArray(), value.scale());
        return (ParquetFilter)new DecimalLteFilter(rangeStart);
    }
    
    final ParquetFilter getLtFilter(final BigDecimal value) {
        final ComparableDecimal rangeStart = new ComparableDecimal(value.unscaledValue().toByteArray(), value.scale());
        return (ParquetFilter)new DecimalLtFilter(rangeStart);
    }
    
    final ParquetFilter getAllFilter(final ComparableDecimal value) {
        return (ParquetFilter)new DecimalAllFilter(value);
    }
    
    final ParquetFilter getNoneFilter(final ComparableDecimal value) {
        return (ParquetFilter)new DecimalNoneFilter(value);
    }
    
    static {
        FIVE = new BigInteger("5");
        TEN = new BigInteger("10");
    }
}
