package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;

abstract class BigIntBetweenConverter extends BigIntFilterConverter
{
    @Override
    ParquetFilter getParquetFilter(final ParquetFilter parquetFilter) {
        final Long rangeStart = this.getStartValue(parquetFilter);
        final Long rangeEnd = this.getEndValue(parquetFilter);
        final ParquetFilter filter = this.getFilterForOutOfRangeValues(rangeStart, rangeEnd);
        return (filter != null) ? filter : this.getFilterBothInRange(rangeStart, rangeEnd);
    }
    
    ParquetFilter getFilterForOutOfRangeValues(final Long rangeStart, final Long rangeEnd) {
        if (this.isLesserThanIntMin(rangeStart) && this.isGreaterThanIntMax(rangeEnd)) {
            return this.getAllFilter();
        }
        if (this.isGreaterThanIntMax(rangeStart) || this.isLesserThanIntMin(rangeEnd)) {
            return this.getNoneFilter();
        }
        if (this.isLesserThanIntMin(rangeStart)) {
            return this.getFilterStartLessThanMinInt(rangeEnd);
        }
        if (this.isGreaterThanIntMax(rangeEnd)) {
            return this.getFilterEndGreaterThanMaxInt(rangeStart);
        }
        return null;
    }
    
    abstract ParquetFilter getFilterStartLessThanMinInt(final Long p0);
    
    abstract ParquetFilter getFilterEndGreaterThanMaxInt(final Long p0);
    
    abstract ParquetFilter getFilterBothInRange(final Long p0, final Long p1);
    
    abstract Long getStartValue(final ParquetFilter p0);
    
    abstract Long getEndValue(final ParquetFilter p0);
}
