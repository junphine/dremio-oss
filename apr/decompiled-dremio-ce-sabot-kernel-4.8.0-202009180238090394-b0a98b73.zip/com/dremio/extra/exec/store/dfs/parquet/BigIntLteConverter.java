package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

public class BigIntLteConverter extends BigIntFilterConverter
{
    @Override
    ParquetFilter getParquetFilter(final ParquetFilter parquetFilter) {
        final BigIntLteFilter filter = (BigIntLteFilter)parquetFilter;
        final Long number = filter.getValue();
        if (this.isGreaterThanIntMax(number)) {
            return this.getAllFilter();
        }
        if (this.isLesserThanIntMin(number)) {
            return this.getNoneFilter();
        }
        return (ParquetFilter)new IntLteFilter((int)(Object)number);
    }
}
