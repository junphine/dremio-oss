package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.parquet.reader.*;

class VarCharLteFilterConverter extends HiveVarCharFilterConverter
{
    VarCharLteFilterConverter(final ManagedSchema managedSchema) {
        super(managedSchema);
    }
    
    public ParquetFilter convertIfNecessary(final ParquetFilter originalFilter, final int fieldLen) {
        final ComparableBinary value = ((VarCharLteFilter)originalFilter).getValue();
        if (this.length(value) >= fieldLen) {
            final ComparableBinary truncatedVal = this.trimToFieldSize(value, fieldLen);
            try {
                return (ParquetFilter)new VarCharLtFilter(this.getNextLexicalValue(truncatedVal));
            }
            catch (MaxLengthReachedException e) {
                return (ParquetFilter)new VarCharAllFilter(value);
            }
        }
        return originalFilter;
    }
}
