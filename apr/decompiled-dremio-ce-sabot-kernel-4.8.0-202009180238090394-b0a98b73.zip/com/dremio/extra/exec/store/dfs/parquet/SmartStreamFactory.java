package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.sabot.exec.context.*;
import java.util.function.*;
import java.util.*;
import com.dremio.exec.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.io.*;
import com.dremio.parquet.pages.async.*;
import com.dremio.options.*;
import com.dremio.io.file.*;
import java.io.*;

@Options
public class SmartStreamFactory implements InputStreamProviderFactory
{
    public static final TypeValidators.PositiveLongValidator CHUNK_SIZE;
    public static final TypeValidators.PositiveLongValidator CHUNK_COUNT_TARGET;
    public static final TypeValidators.PositiveLongValidator INITIAL_FOOTER_READ;
    public static final TypeValidators.PositiveLongValidator MIN_GAP;
    public static final TypeValidators.BooleanValidator ENABLE_READER_PATH_ALWAYS;
    public static final TypeValidators.BooleanValidator ENABLE_ASYNC_DEBUG_LOGGING;
    public static final TypeValidators.PositiveLongValidator READ_TIMEOUT;
    
    public InputStreamProvider create(final FileSystem fs, final OperatorContext context, final Path path, final long fileLength, final long splitSize, final ParquetScanProjectedColumns projectedColumns, final MutableParquetMetadata footerIfKnown, final Function<MutableParquetMetadata, Integer> rowGroupIndexProvider, final BiConsumer<Path, MutableParquetMetadata> depletionListener, final boolean readFullFile, final List<String> dataset, final long mTime, final boolean boost) throws IOException {
        final boolean shouldUseAsync = fs.supportsAsync();
        final OptionManager options = context.getOptions();
        if (!options.getOption(SmartStreamFactory.ENABLE_READER_PATH_ALWAYS) && !shouldUseAsync) {
            return InputStreamProviderFactory.DEFAULT.create(fs, context, path, fileLength, splitSize, projectedColumns, footerIfKnown, (Function)rowGroupIndexProvider, (BiConsumer)depletionListener, readFullFile, (List)dataset, mTime, false);
        }
        BoostedFileSystem boostedFileSystem = null;
        AsyncByteReader.FileKey fileKey = null;
        AsyncByteReader reader;
        boolean recordWaitTimes;
        if (shouldUseAsync) {
            fileKey = AsyncByteReader.FileKey.of(path, Long.toString(mTime), AsyncByteReader.FileKey.FileType.PARQUET, (List)dataset);
            reader = fs.getAsyncByteReader(fileKey);
            recordWaitTimes = true;
            boostedFileSystem = ((fs.supportsBoosting() && options.getOption(ExecConstants.ENABLE_BOOSTING) && boost) ? fs.getBoostedFilesystem() : null);
        }
        else {
            reader = (AsyncByteReader)new SeekableAsyncByteReader(Streams.wrap(fs.open(path)));
            recordWaitTimes = false;
        }
        if (options.getOption((TypeValidators.LongValidator)SmartStreamFactory.READ_TIMEOUT) != Long.MAX_VALUE) {
            reader = (AsyncByteReader)new AsyncByteReaderWithTimeout(reader, options.getOption((TypeValidators.LongValidator)SmartStreamFactory.READ_TIMEOUT));
        }
        final RowGroupReader rgReader = new RowGroupReader(new StreamInfo(path, context.getFragmentHandle(), context.getStats().getOperatorId()), (int)options.getOption((TypeValidators.LongValidator)SmartStreamFactory.CHUNK_SIZE), (int)options.getOption((TypeValidators.LongValidator)SmartStreamFactory.MIN_GAP), (int)options.getOption((TypeValidators.LongValidator)SmartStreamFactory.CHUNK_COUNT_TARGET), fileLength, options.getOption(ExecConstants.PARQUET_MAX_FOOTER_LEN_VALIDATOR), (int)options.getOption((TypeValidators.LongValidator)SmartStreamFactory.INITIAL_FOOTER_READ), reader, fileKey, boostedFileSystem, context.getAllocator(), context.getStats(), footerIfKnown, (BiConsumer)depletionListener, recordWaitTimes, options.getOption(SmartStreamFactory.ENABLE_ASYNC_DEBUG_LOGGING));
        try {
            rgReader.initialize((Function)rowGroupIndexProvider, projectedColumns);
        }
        catch (Exception e) {
            rgReader.close();
            throw e;
        }
        return (InputStreamProvider)rgReader;
    }
    
    static {
        CHUNK_SIZE = new TypeValidators.PositiveLongValidator("store.parquet.chunk_size", Long.MAX_VALUE, 1048576L);
        CHUNK_COUNT_TARGET = new TypeValidators.PositiveLongValidator("store.parquet.target_chunk_count", Long.MAX_VALUE, 1L);
        INITIAL_FOOTER_READ = new TypeValidators.PositiveLongValidator("store.parquet.initial_footer_read", Long.MAX_VALUE, 524288L);
        MIN_GAP = new TypeValidators.PositiveLongValidator("store.parquet.min_gap_division", Long.MAX_VALUE, 524288L);
        ENABLE_READER_PATH_ALWAYS = new TypeValidators.BooleanValidator("store.parquet.test.byte_reader_path", false);
        ENABLE_ASYNC_DEBUG_LOGGING = new TypeValidators.BooleanValidator("store.parquet.async.debug", false);
        READ_TIMEOUT = new TypeValidators.PositiveLongValidator("store.parquet.async.request.timeout_millis", Long.MAX_VALUE, 300000L);
    }
}
