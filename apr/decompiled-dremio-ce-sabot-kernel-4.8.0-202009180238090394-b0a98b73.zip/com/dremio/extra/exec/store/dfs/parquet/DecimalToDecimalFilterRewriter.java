package com.dremio.extra.exec.store.dfs.parquet;

import java.util.*;
import com.google.common.collect.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.common.expression.*;
import org.apache.parquet.format.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;

public class DecimalToDecimalFilterRewriter implements FilterRewriter
{
    private final Map<Class<?>, HiveDecimalFilterConverter> decimalFiltersMap;
    private int tableColumnScale;
    private int tableColumnPrecision;
    private int fileColumnScale;
    private int fileColumnPrecision;
    
    DecimalToDecimalFilterRewriter() {
        (this.decimalFiltersMap = (Map<Class<?>, HiveDecimalFilterConverter>)Maps.newHashMap()).put(DecimalEqFilter.class, new DecimalEqConverter());
        this.decimalFiltersMap.put(DecimalGteFilter.class, new DecimalGteConverter());
        this.decimalFiltersMap.put(DecimalGtFilter.class, new DecimalGtConverter());
        this.decimalFiltersMap.put(DecimalLteFilter.class, new DecimalLteConverter());
        this.decimalFiltersMap.put(DecimalLtFilter.class, new DecimalLtConverter());
        this.decimalFiltersMap.put(DecimalBetweenCCFilter.class, new DecimalBetweenCCConverter());
        this.decimalFiltersMap.put(DecimalBetweenCOFilter.class, new DecimalBetweenCOConverter());
        this.decimalFiltersMap.put(DecimalBetweenOOFilter.class, new DecimalBetweenOOConverter());
        this.decimalFiltersMap.put(DecimalBetweenOCFilter.class, new DecimalBetweenOCConverter());
    }
    
    @Override
    public boolean canConvert(final ParquetFilterCondition filterCondition, final CompleteType filterTableColumnType, final SchemaElement filterColumnFileSchemaType) {
        if (this.decimalFiltersMap.get(filterCondition.getFilter().getClass()) == null) {
            return false;
        }
        if (!filterTableColumnType.isDecimal() || !filterColumnFileSchemaType.getLogicalType().isSetDECIMAL()) {
            return false;
        }
        this.tableColumnScale = filterTableColumnType.getScale();
        this.tableColumnPrecision = filterTableColumnType.getPrecision();
        this.fileColumnScale = filterColumnFileSchemaType.getScale();
        this.fileColumnPrecision = filterColumnFileSchemaType.getPrecision();
        return this.tableColumnScale != this.fileColumnScale || this.tableColumnPrecision < this.fileColumnPrecision;
    }
    
    @Override
    public ParquetFilterIface convertIfNecessary(final ParquetFilterCondition filterCondition, final SchemaDerivationHelper schemaHelper, final String filteredColumn, final SchemaElement filterColumnFileSchemaType) {
        final ParquetFilter filter = (ParquetFilter)filterCondition.getFilter();
        final HiveDecimalFilterConverter filterConverter = this.decimalFiltersMap.get(filter.getClass());
        return (ParquetFilterIface)filterConverter.transformFilter(filter, this.tableColumnPrecision, this.tableColumnScale, this.fileColumnPrecision, this.fileColumnScale);
    }
}
