package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.common.expression.*;
import org.apache.parquet.format.*;
import com.dremio.exec.store.parquet.*;

interface FilterRewriter
{
    boolean canConvert(final ParquetFilterCondition p0, final CompleteType p1, final SchemaElement p2);
    
    ParquetFilterIface convertIfNecessary(final ParquetFilterCondition p0, final SchemaDerivationHelper p1, final String p2, final SchemaElement p3);
}
