package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.*;
import java.math.*;
import com.dremio.parquet.reader.filter.*;

abstract class DecimalBetweenConverter extends HiveDecimalFilterConverter
{
    abstract ComparableDecimal getRangeStart(final ParquetFilter p0);
    
    abstract ComparableDecimal getRangeEnd(final ParquetFilter p0);
    
    abstract BigDecimal getNewStart(final ParquetFilter p0, final int p1);
    
    abstract BigDecimal getNewEnd(final ParquetFilter p0, final int p1);
    
    @Override
    final ParquetFilter transformFilterFromLowerScaleToHigherScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final ComparableDecimal rangeStart = this.getRangeStart(parquetFilter);
        final ComparableDecimal rangeEnd = this.getRangeEnd(parquetFilter);
        final ComparableDecimal truncatedStart = this.truncateLower(rangeStart, fileScale);
        final ComparableDecimal truncatedEnd = this.truncateLower(rangeEnd, fileScale);
        return (ParquetFilter)new DecimalBetweenCCFilter(truncatedStart, truncatedEnd);
    }
    
    @Override
    final ParquetFilter transformFilterFromHigherScaleToLowerScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final int newScale = tableScale + 1;
        final BigDecimal nS = this.getNewStart(parquetFilter, newScale);
        final BigDecimal nE = this.getNewEnd(parquetFilter, newScale);
        final boolean startCanScale = this.decimalCanScaleTo(nS, fileScale);
        final boolean endCanScale = this.decimalCanScaleTo(nE, fileScale);
        if (startCanScale && endCanScale) {
            return this.getBetweenCCFilter(nS, nE);
        }
        if (startCanScale && !endCanScale) {
            return this.getGteFilter(nS);
        }
        if (!startCanScale && endCanScale) {
            return this.getLteFilter(nE);
        }
        return this.getAllFilter(this.getRangeStart(parquetFilter));
    }
}
