package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

public class BigIntGteConverter extends BigIntFilterConverter
{
    @Override
    ParquetFilter getParquetFilter(final ParquetFilter parquetFilter) {
        final BigIntGteFilter filter = (BigIntGteFilter)parquetFilter;
        final Long number = filter.getValue();
        if (this.isGreaterThanIntMax(number)) {
            return this.getNoneFilter();
        }
        if (this.isLesserThanIntMin(number)) {
            return this.getAllFilter();
        }
        return (ParquetFilter)new IntGteFilter((int)(Object)number);
    }
}
