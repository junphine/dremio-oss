package com.dremio.extra.exec.store.dfs.parquet;

import com.google.common.collect.*;
import org.apache.parquet.format.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.common.expression.*;
import java.util.*;

public class HiveParquetFilterCreator extends ParquetFilterCreator
{
    private final List<FilterRewriter> filterRewriterList;
    
    public HiveParquetFilterCreator(final ManagedSchema managedSchema) {
        (this.filterRewriterList = (List<FilterRewriter>)Lists.newArrayList()).add(new BigIntToIntFilterRewriter());
        this.filterRewriterList.add(new DoubleToFloatFilterRewriter());
        this.filterRewriterList.add(new VarCharToVarCharFilterRewriter(managedSchema));
        this.filterRewriterList.add(new DecimalToDecimalFilterRewriter());
    }
    
    public ParquetFilterIface getParquetFilter(final ParquetFilterCondition filterCondition, final SchemaDerivationHelper schemaHelper, final String filteredColumn, final SchemaElement filterColumnFileSchemaType) {
        final CompleteType filterTableColumnType = schemaHelper.getType(filteredColumn);
        for (final FilterRewriter converter : this.filterRewriterList) {
            if (converter.canConvert(filterCondition, filterTableColumnType, filterColumnFileSchemaType)) {
                return converter.convertIfNecessary(filterCondition, schemaHelper, filteredColumn, filterColumnFileSchemaType);
            }
        }
        return super.getParquetFilter(filterCondition, schemaHelper, filteredColumn, filterColumnFileSchemaType);
    }
    
    public boolean filterMayChange() {
        return true;
    }
}
