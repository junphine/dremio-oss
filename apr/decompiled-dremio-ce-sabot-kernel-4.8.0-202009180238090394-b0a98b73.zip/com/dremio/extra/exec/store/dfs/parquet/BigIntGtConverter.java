package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;

public class BigIntGtConverter extends BigIntFilterConverter
{
    @Override
    ParquetFilter getParquetFilter(final ParquetFilter parquetFilter) {
        final BigIntGtFilter filter = (BigIntGtFilter)parquetFilter;
        final Long number = filter.getValue();
        if (this.isGreaterThanIntMax(number)) {
            return this.getNoneFilter();
        }
        if (this.isLesserThanIntMin(number)) {
            return this.getAllFilter();
        }
        return (ParquetFilter)new IntGtFilter((int)(Object)number);
    }
}
