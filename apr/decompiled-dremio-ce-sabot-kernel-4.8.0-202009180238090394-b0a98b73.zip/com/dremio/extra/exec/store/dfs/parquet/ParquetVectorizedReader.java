package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.io.file.*;
import org.apache.parquet.compression.*;
import com.dremio.parquet.reader.column.generics.*;
import com.google.common.base.*;
import com.dremio.common.map.*;
import org.apache.parquet.hadoop.metadata.*;
import com.dremio.parquet.reader.column.*;
import com.dremio.common.expression.*;
import org.apache.arrow.vector.complex.*;
import org.apache.parquet.format.*;
import com.dremio.parquet.pages.*;
import com.dremio.sabot.op.scan.*;
import com.dremio.sabot.exec.context.*;
import com.dremio.parquet.reader.*;
import com.dremio.common.exceptions.*;
import java.io.*;
import org.apache.arrow.vector.types.pojo.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.metadata.*;
import java.util.*;
import com.dremio.exec.*;
import org.apache.parquet.schema.*;
import org.apache.arrow.vector.*;
import org.apache.arrow.memory.*;
import com.dremio.common.*;
import org.slf4j.*;

public class ParquetVectorizedReader extends AbstractParquetReader
{
    private static final Logger logger;
    private final Path path;
    private final CompressionCodecFactory codecFactory;
    private final List<ParquetFilterCondition> conditions;
    private final ParquetFilterCreator filterCreator;
    private final ParquetDictionaryConvertor dictionaryConvertor;
    private ParquetFilter convertedParquetFilter;
    private ParquetScanProjectedColumns projectedColumns;
    private Reader rgReader;
    private long totalRecords;
    private final MutableParquetMetadata footer;
    private final boolean enableDetailedTracing;
    private final int rowGroupIndex;
    private Stopwatch timer;
    private ParquetFilter filter;
    private ReaderFactory pageReaderFactory;
    private final InputStreamProvider inputStreamProvider;
    private final SchemaDerivationHelper schemaHelper;
    private final Metrics metrics;
    
    public ParquetVectorizedReader(final OperatorContext context, final ParquetScanProjectedColumns projectedColumns, final String path, final CompressionCodecFactory codecFactory, final List<ParquetFilterCondition> conditions, final ParquetFilterCreator filterCreator, final ParquetDictionaryConvertor dictionaryConvertor, final boolean enableDetailedTracing, final MutableParquetMetadata footer, final int rowGroupIndex, final SimpleIntVector deltas, final SchemaDerivationHelper schemaHelper, final InputStreamProvider inputStreamProvider) {
        super(context, projectedColumns.getBatchSchemaProjectedColumns(), deltas);
        this.convertedParquetFilter = null;
        this.timer = Stopwatch.createUnstarted();
        this.projectedColumns = projectedColumns;
        this.path = Path.of(path);
        this.codecFactory = codecFactory;
        this.conditions = conditions;
        this.filterCreator = filterCreator;
        this.dictionaryConvertor = dictionaryConvertor;
        this.footer = footer;
        this.rowGroupIndex = rowGroupIndex;
        this.enableDetailedTracing = enableDetailedTracing;
        this.inputStreamProvider = inputStreamProvider;
        this.schemaHelper = schemaHelper;
        this.metrics = new Metrics();
    }
    
    public void setup(final OutputMutator output) throws ExecutionSetupException {
        Preconditions.checkArgument(this.conditions == null || this.conditions.isEmpty() || this.conditions.size() == 1, (Object)"Only support a single condition currently.");
        try {
            final BlockMetaData block = this.footer.getBlocks().get(this.rowGroupIndex);
            Preconditions.checkArgument(block != null, (Object)"Parquet footer does not contain information for the row group");
            final ParquetColumnResolver columnResolver = this.projectedColumns.getColumnResolver(this.footer.getFileMetaData().getSchema());
            final Map<String, ColumnChunkMetaData> fields = (Map<String, ColumnChunkMetaData>)CaseInsensitiveMap.newHashMap();
            for (final ColumnChunkMetaData c2 : block.getColumns()) {
                if (!checkType(c2)) {
                    continue;
                }
                fields.put(c2.getPath().iterator().next(), c2);
            }
            final Map<String, OriginalType> originalTypeMap = this.getOriginalColumnTypes();
            final ColumnReaderFactory readerFactory = new ColumnReaderFactory(this.numRowsPerBatch, this.schemaHelper.getDateCorruptionStatus().behavior, this.enableDetailedTracing, this.varValueSizeLimit);
            final ParquetFilterCondition condition = (this.conditions != null && !this.conditions.isEmpty()) ? this.conditions.get(0) : null;
            final String filteredColumn = (condition != null) ? condition.getPath().getAsNamePart().getName() : null;
            OutputColumn filtered = null;
            final List<OutputColumn> columns = new ArrayList<OutputColumn>();
            final Set<ColumnChunkMetaData> chunks = new HashSet<ColumnChunkMetaData>();
            for (final SchemaPath schemaPath : this.getResolvedColumns(block.getColumns(), columnResolver)) {
                if (!schemaPath.isSimplePath()) {
                    throw UserException.dataReadError().message("Attempted to read column that wasn't simple.", new Object[0]).build(ParquetVectorizedReader.logger);
                }
                final String name = schemaPath.getAsNamePart().getName();
                final ColumnChunkMetaData chunk = fields.get(name);
                if (chunk == null) {
                    throw UserException.dataReadError().message("Attempted to read column that wasn't available.", new Object[0]).build(ParquetVectorizedReader.logger);
                }
                chunks.add(chunk);
                final String schemaName = columnResolver.getBatchSchemaColumnName(name);
                Preconditions.checkState(schemaName != null, (Object)String.format("Parquet column name, '%s' not found in schema", name));
                final SchemaPath projectedPath = SchemaPath.getSimplePath(schemaName);
                final Field columnField = ParquetTypeHelper.createField(projectedPath, chunk.getPrimitiveType(), (OriginalType)originalTypeMap.get(name), this.schemaHelper);
                final CompleteType type = CompleteType.fromField(columnField);
                ValueVector vector = output.getVector(schemaName);
                if (vector == null || !(vector instanceof UnionVector)) {
                    vector = output.addField(columnField, type.getValueVectorClass());
                }
                final FullColumnDescriptor descriptor = new FullColumnDescriptor(type, (FieldRepetitionType)null, new String[] { chunk.getPath().iterator().next() });
                final OutputColumn column = new OutputColumn(descriptor, vector);
                if (schemaName.equalsIgnoreCase(filteredColumn)) {
                    filtered = column;
                }
                else {
                    columns.add(column);
                }
            }
            if (output.getSchemaChanged()) {
                ParquetVectorizedReader.logger.info("Detected schema change. Not initializing further readers.");
                return;
            }
            final FSPageReader pageReader = new FSPageReader(this.context.getAllocator(), this.metrics, this.codecFactory, this.inputStreamProvider);
            final RowGroupMetadata rowGroup = RowGroups.getRowGroupMetadataFor(this.path, this.footer, this.schemaHelper, (Set)chunks, this.rowGroupIndex);
            final boolean filterColAbsentInParquet = filteredColumn != null && filtered == null;
            if (filterColAbsentInParquet) {
                this.deltas = null;
                this.pageReaderFactory = (ReaderFactory)new SkipAllReaderFactory();
                this.rgReader = this.pageReaderFactory.newRowGroupReader(rowGroup);
            }
            else if (filtered != null) {
                final Optional<FullColumnDescriptor> columnDescriptor = (Optional<FullColumnDescriptor>)rowGroup.getColumns().stream().filter(c -> c.getSchemaElement().getName().equalsIgnoreCase(columnResolver.getParquetColumnName(filteredColumn))).findAny();
                ParquetFilterIface parquetFilter = condition.getFilter();
                if (columnDescriptor.isPresent()) {
                    final ParquetFilterIface filterIface = this.filterCreator.getParquetFilter(condition, this.schemaHelper, filteredColumn, columnDescriptor.get().getSchemaElement());
                    if (filterIface != condition.getFilter()) {
                        parquetFilter = filterIface;
                        this.convertedParquetFilter = (ParquetFilter)parquetFilter;
                        condition.setFilterModifiedForPushdown(true);
                    }
                }
                this.filter = ColumnReaderFactory.convertIfNecessary(((ParquetFilter)parquetFilter).withAllocator(this.context.getAllocator()), this.schemaHelper.getDateCorruptionStatus().behavior, rowGroup.getColumnChunk(filtered.getPath()).isTimeStamp96());
                if (this.shouldRowGroupBePruned(rowGroup, filtered)) {
                    this.deltas = null;
                    this.context.getStats().addLongStat((MetricDef)ScanOperator.Metric.NUM_ROW_GROUPS_PRUNED, 1L);
                    this.pageReaderFactory = (ReaderFactory)new SkipAllReaderFactory();
                    this.rgReader = this.pageReaderFactory.newRowGroupReader(rowGroup);
                }
                else {
                    final FilteringReader reader = new FilteringReader(this.context, (PageReader)pageReader, this.inputStreamProvider, readerFactory, this.filter, filtered, (List)columns, this.dictionaryConvertor, this.metrics, this.deltas);
                    this.pageReaderFactory = (ReaderFactory)reader;
                    this.rgReader = (Reader)reader.newRowGroupReader(rowGroup);
                }
            }
            else {
                this.deltas = null;
                final SimpleReader reader2 = new SimpleReader(this.context, (PageReader)pageReader, this.inputStreamProvider, readerFactory, (List)columns, this.dictionaryConvertor, this.metrics);
                this.pageReaderFactory = (ReaderFactory)reader2;
                this.rgReader = (Reader)reader2.newRowGroupReader(rowGroup);
            }
        }
        catch (IOException ex) {
            throw new ExecutionSetupException((Throwable)ex);
        }
    }
    
    private boolean shouldRowGroupBePruned(final RowGroupMetadata rowGroupMetadata, final OutputColumn filtered) {
        final Stats stats = rowGroupMetadata.getColumnChunk(filtered.getPath()).getColumnStats();
        return stats != null && stats.getStatistics() != null && stats.getStatistics().hasNonNullValue() && !this.filter.mayMatch(stats);
    }
    
    private Collection<SchemaPath> getResolvedColumns(final List<ColumnChunkMetaData> metadata, final ParquetColumnResolver columnResolver) {
        if (!this.context.getOptions().getOption(ExecConstants.PARQUET_COLUMN_ORDERING)) {
            return (Collection<SchemaPath>)columnResolver.getProjectedParquetColumns();
        }
        final Set<SchemaPath> selectedColumns = new HashSet<SchemaPath>(columnResolver.getProjectedParquetColumns());
        final List<SchemaPath> schemaPaths = new ArrayList<SchemaPath>();
        for (final ColumnChunkMetaData c : metadata) {
            final SchemaPath p = SchemaPath.getSimplePath((String)c.getPath().iterator().next());
            if (selectedColumns.contains(p)) {
                schemaPaths.add(p);
            }
        }
        return schemaPaths;
    }
    
    public Map<String, OriginalType> getOriginalColumnTypes() {
        final Map<String, OriginalType> originalTypeMap = (Map<String, OriginalType>)CaseInsensitiveMap.newHashMap();
        for (final Type parquetField : this.footer.getFileMetaData().getSchema().getFields()) {
            originalTypeMap.put(parquetField.getName(), parquetField.getOriginalType());
        }
        return originalTypeMap;
    }
    
    public static boolean checkType(final ColumnChunkMetaData c) {
        final PrimitiveType.PrimitiveTypeName n = c.getType();
        if (n == null) {
            return false;
        }
        if (c.getPath().size() > 1) {
            return false;
        }
        switch (n) {
            case BINARY:
            case BOOLEAN:
            case DOUBLE:
            case FLOAT:
            case INT32:
            case INT64:
            case INT96: {
                return true;
            }
            default: {
                return true;
            }
        }
    }
    
    public void allocate(final Map<String, ValueVector> vectorMap) throws OutOfMemoryException {
        for (final ValueVector v : vectorMap.values()) {
            if (v instanceof FixedWidthVector) {
                ((FixedWidthVector)v).allocateNew(this.context.getTargetBatchSize());
            }
            else {
                v.allocateNew();
            }
        }
    }
    
    public int next() {
        try {
            this.timer.start();
            final int records = this.rgReader.eval();
            this.timer.stop();
            this.totalRecords += records;
            return records;
        }
        catch (Exception e) {
            throw UserException.dataReadError((Throwable)e).message("Failed to read from parquet file.", new Object[0]).addContext("File path", this.path.toString()).addContext("Rowgroup index", (long)this.rowGroupIndex).build(ParquetVectorizedReader.logger);
        }
    }
    
    public List<SchemaPath> getColumnsToBoost() {
        return (List<SchemaPath>)this.rgReader.getColumnsToBoost();
    }
    
    public void close() throws Exception {
        AutoCloseables.close(new AutoCloseable[] { this.rgReader, this.filter, this.pageReaderFactory, this.convertedParquetFilter });
        this.context.getStats().addLongStat((MetricDef)ScanOperator.Metric.PARQUET_BYTES_READ, this.metrics.getTotalPageSizeRead());
        this.filter = null;
        this.convertedParquetFilter = null;
    }
    
    public boolean supportsSkipAllQuery() {
        return true;
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)ParquetVectorizedReader.class);
    }
}
