package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.*;
import com.dremio.parquet.reader.filter.*;

abstract class AbstractVarCharBetweenFilterConverter extends HiveVarCharFilterConverter
{
    public AbstractVarCharBetweenFilterConverter(final ManagedSchema managedSchema) {
        super(managedSchema);
    }
    
    protected abstract ComparableBinary getStart(final ParquetFilter p0);
    
    protected abstract ComparableBinary getEnd(final ParquetFilter p0);
    
    protected abstract boolean isResetStartRequired(final ComparableBinary p0, final int p1);
    
    protected abstract boolean isResetEndRequired(final ComparableBinary p0, final int p1);
    
    public ParquetFilter convertIfNecessary(final ParquetFilter filter, final int fieldLen) {
        ComparableBinary start = this.getStart(filter);
        ComparableBinary end = this.getEnd(filter);
        boolean isAnyValChanged = false;
        if (this.isResetStartRequired(start, fieldLen)) {
            try {
                start = this.getNextLexicalValue(this.trimToFieldSize(start, fieldLen));
                isAnyValChanged = true;
            }
            catch (MaxLengthReachedException e) {
                return (ParquetFilter)new VarCharNoneFilter(start);
            }
        }
        if (this.isResetEndRequired(end, fieldLen)) {
            try {
                end = this.getNextLexicalValue(this.trimToFieldSize(end, fieldLen));
                isAnyValChanged = true;
            }
            catch (MaxLengthReachedException e) {
                return (ParquetFilter)new VarCharGteFilter(start);
            }
        }
        return (ParquetFilter)(isAnyValChanged ? new VarCharBetweenCOFilter(start, end) : filter);
    }
}
