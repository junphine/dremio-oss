package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.*;
import com.dremio.parquet.reader.filter.*;

class VarCharBetweenCOFilterConverter extends AbstractVarCharBetweenFilterConverter
{
    VarCharBetweenCOFilterConverter(final ManagedSchema managedSchema) {
        super(managedSchema);
    }
    
    @Override
    protected ComparableBinary getStart(final ParquetFilter filter) {
        return ((VarCharBetweenCOFilter)filter).getStart();
    }
    
    @Override
    protected ComparableBinary getEnd(final ParquetFilter filter) {
        return ((VarCharBetweenCOFilter)filter).getEnd();
    }
    
    @Override
    protected boolean isResetStartRequired(final ComparableBinary start, final int fieldLen) {
        return this.length(start) > fieldLen;
    }
    
    @Override
    protected boolean isResetEndRequired(final ComparableBinary end, final int fieldLen) {
        return this.length(end) > fieldLen;
    }
}
