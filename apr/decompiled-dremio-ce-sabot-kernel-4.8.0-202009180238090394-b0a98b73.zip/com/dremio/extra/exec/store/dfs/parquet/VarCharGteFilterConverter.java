package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.parquet.reader.*;

class VarCharGteFilterConverter extends HiveVarCharFilterConverter
{
    VarCharGteFilterConverter(final ManagedSchema managedSchema) {
        super(managedSchema);
    }
    
    public ParquetFilter convertIfNecessary(final ParquetFilter originalFilter, final int fieldLen) {
        final ComparableBinary value = ((VarCharGteFilter)originalFilter).getValue();
        if (this.length(value) > fieldLen) {
            try {
                return (ParquetFilter)new VarCharGteFilter(this.getNextLexicalValue(this.trimToFieldSize(value, fieldLen)));
            }
            catch (MaxLengthReachedException e) {
                return (ParquetFilter)new VarCharNoneFilter(value);
            }
        }
        return originalFilter;
    }
}
