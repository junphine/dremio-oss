package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.parquet.reader.*;
import java.math.*;

class DecimalLtConverter extends HiveDecimalFilterConverter
{
    @Override
    ParquetFilter transformFilterFromLowerScaleToHigherScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final DecimalLtFilter filter = (DecimalLtFilter)parquetFilter;
        final ComparableDecimal truncatedValue = this.truncateLower(filter.getValue(), fileScale);
        return (ParquetFilter)new DecimalLteFilter(truncatedValue);
    }
    
    @Override
    ParquetFilter transformFilterFromHigherScaleToLowerScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final DecimalLtFilter filter = (DecimalLtFilter)parquetFilter;
        final int newScale = tableScale + 1;
        final ComparableDecimal value = filter.getValue();
        final BigDecimal minusHalf = this.minusHalf(value, newScale);
        if (this.decimalCanScaleTo(minusHalf, fileScale)) {
            return this.getLteFilter(minusHalf);
        }
        if (this.greaterThanOrEqualToZero(value)) {
            return this.getAllFilter(value);
        }
        return this.getNoneFilter(value);
    }
}
