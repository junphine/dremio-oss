package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.exec.store.parquet.*;
import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.parquet.reader.*;

class VarCharEqFilterConverter extends HiveVarCharFilterConverter
{
    VarCharEqFilterConverter(final ManagedSchema managedSchema) {
        super(managedSchema);
    }
    
    public ParquetFilter convertIfNecessary(final ParquetFilter originalFilter, final int fieldLen) {
        final ComparableBinary value = ((VarCharEqFilter)originalFilter).getValue();
        final int valLen = this.length(value);
        if (valLen == fieldLen) {
            try {
                return (ParquetFilter)new VarCharBetweenCOFilter(value, this.getNextLexicalValue(value));
            }
            catch (MaxLengthReachedException e) {
                return (ParquetFilter)new VarCharGteFilter(value);
            }
        }
        if (valLen > fieldLen) {
            return (ParquetFilter)new VarCharNoneFilter(value);
        }
        return originalFilter;
    }
}
