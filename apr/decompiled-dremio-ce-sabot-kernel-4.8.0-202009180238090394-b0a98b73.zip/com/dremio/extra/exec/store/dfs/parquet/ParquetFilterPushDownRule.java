package com.dremio.extra.exec.store.dfs.parquet;

import com.github.slugify.*;
import com.dremio.exec.catalog.*;
import com.dremio.exec.catalog.conf.*;
import org.apache.calcite.plan.*;
import org.apache.calcite.rel.core.*;
import com.dremio.exec.planner.logical.partition.*;
import org.apache.calcite.rel.type.*;
import com.dremio.exec.planner.physical.*;
import com.google.common.base.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.exec.planner.logical.*;
import org.apache.calcite.sql.fun.*;
import org.apache.calcite.sql.*;
import com.dremio.exec.store.dfs.*;
import com.dremio.exec.store.parquet.*;
import com.dremio.exec.store.*;
import org.apache.calcite.rel.*;
import org.apache.arrow.vector.types.pojo.*;
import com.dremio.parquet.reader.column.generics.*;
import org.apache.calcite.sql.type.*;
import com.dremio.exec.record.*;
import com.google.common.collect.*;
import java.math.*;
import org.apache.calcite.util.*;
import java.nio.charset.*;
import org.apache.arrow.vector.*;
import org.apache.calcite.rex.*;
import org.apache.arrow.util.*;
import com.dremio.parquet.reader.*;
import java.util.*;
import com.dremio.common.expression.*;
import org.slf4j.*;
import com.dremio.common.types.*;

public abstract class ParquetFilterPushDownRule<T extends ScanRelBase> extends RelOptRule
{
    private static final Logger logger;
    private static final Slugify SLUGIFY;
    
    public ParquetFilterPushDownRule(final StoragePluginId pluginId, final Class<T> clazz) {
        super(RelOptHelper.some((Class)FilterRel.class, RelOptHelper.any((Class)clazz), new RelOptRuleOperand[0]), pluginId.getType().value() + "Parquet.PushFilterIntoScan." + ParquetFilterPushDownRule.SLUGIFY.slugify(pluginId.getName()) + "." + UUID.randomUUID().toString());
    }
    
    public ParquetFilterPushDownRule(final SourceType pluginType, final Class<T> clazz) {
        super(RelOptHelper.some((Class)FilterRel.class, RelOptHelper.any((Class)clazz), new RelOptRuleOperand[0]), pluginType.value() + "Parquet.PushFilterIntoScan");
    }
    
    public abstract boolean matches(final RelOptRuleCall p0);
    
    public void onMatch(final RelOptRuleCall call) {
        final Filter filter = (Filter)call.rel(0);
        final T scan = (T)call.rel(1);
        final RexBuilder builder = filter.getCluster().getRexBuilder();
        final FindSimpleFilters.StateHolder holder = (FindSimpleFilters.StateHolder)filter.getCondition().accept((RexVisitor)new FindSimpleFilters(builder, false));
        if (!holder.hasConditions()) {
            return;
        }
        final Map<String, Field> schema = this.getFieldMap(((ScanRelBase)scan).getBatchSchema());
        final ImmutableList<RexCall> conditions = (ImmutableList<RexCall>)holder.getConditions();
        final RelDataType incomingRowType = ((ScanRelBase)scan).getRowType();
        final List<RexCall> unSupportedDecimalFilters = (List<RexCall>)Lists.newArrayList();
        final List<ParquetFilterCondition.FilterProperties> filters = (List<ParquetFilterCondition.FilterProperties>)FluentIterable.from((Iterable)conditions).filter(condition -> this.filterDecimalScaleIncompatible(condition, unSupportedDecimalFilters)).transform((Function)new Function<RexCall, ParquetFilterCondition.FilterProperties>() {
            public ParquetFilterCondition.FilterProperties apply(final RexCall input) {
                return new ParquetFilterCondition.FilterProperties(input, incomingRowType);
            }
        }).toList();
        final ArrayListMultimap<String, ParquetFilterCondition.FilterProperties> map = (ArrayListMultimap<String, ParquetFilterCondition.FilterProperties>)ArrayListMultimap.create();
        for (final ParquetFilterCondition.FilterProperties p : filters) {
            map.put((Object)p.getField(), (Object)p);
        }
        List<String> sortKeys = (List<String>)((ScanRelBase)scan).getTableMetadata().getReadDefinition().getSortColumnsList();
        if (sortKeys == null) {
            sortKeys = (List<String>)ImmutableList.of();
        }
        final Map<String, Integer> sortKeyIndex = new HashMap<String, Integer>();
        for (int i = 0; i < sortKeys.size(); ++i) {
            sortKeyIndex.put(sortKeys.get(i).toLowerCase(), i);
        }
        final Set<String> addedColumns = new HashSet<String>();
        final List<String> orderedList = new ArrayList<String>();
        final List<RexCall> unusedConditions = new ArrayList<RexCall>();
        for (final String sortKey : sortKeys) {
            if (map.containsKey((Object)sortKey) && schema.containsKey(sortKey)) {
                addedColumns.add(sortKey);
                orderedList.add(sortKey);
            }
        }
        for (final String key : map.keySet()) {
            if (!addedColumns.contains(key)) {
                if (schema.containsKey(key)) {
                    orderedList.add(key);
                }
                else {
                    for (final ParquetFilterCondition.FilterProperties p2 : map.get((Object)key)) {
                        unusedConditions.add(p2.getNode());
                    }
                }
            }
        }
        List<String> partitionColumns = (List<String>)((ScanRelBase)scan).getTableMetadata().getReadDefinition().getPartitionColumnsList();
        if (partitionColumns == null) {
            partitionColumns = (List<String>)ImmutableList.of();
        }
        ParquetFilterCondition condition = null;
        final PlannerSettings settings = (PlannerSettings)call.getPlanner().getContext();
        final ParseContext parseContext = new ParseContext(settings);
        for (final String key2 : orderedList) {
            final List<ParquetFilterCondition.FilterProperties> props = (List<ParquetFilterCondition.FilterProperties>)map.get((Object)key2);
            if (condition != null || partitionColumns.contains(key2)) {
                for (final ParquetFilterCondition.FilterProperties p3 : props) {
                    unusedConditions.add(p3.getNode());
                }
            }
            else {
                final int sortIndex = (int)Optional.fromNullable((Object)sortKeyIndex.get(key2.toLowerCase())).or((Object)(-1));
                try {
                    if (props.size() == 1) {
                        final ParquetFilterCondition.FilterProperties c1 = props.get(0);
                        final VecH c1o = this.vec(schema, c1);
                        final ParquetFilter pf = Filters.generateFilter(c1o.value, c1.getOpName(), c1o.vectorClass);
                        condition = new ParquetFilterCondition(SchemaPath.getSimplePath(c1.getField()), (ParquetFilterIface)pf, RexToExpr.toExpr(parseContext, incomingRowType, builder, (RexNode)c1.getNode()), sortIndex);
                    }
                    else {
                        final ParquetFilterCondition.FilterProperties c1 = props.get(0);
                        final ParquetFilterCondition.FilterProperties c2 = props.get(1);
                        final VecH c1o2 = this.vec(schema, c1);
                        final VecH c2o = this.vec(schema, c2);
                        final LogicalExpression compound = RexToExpr.toExpr(parseContext, incomingRowType, builder, builder.makeCall((SqlOperator)SqlStdOperatorTable.AND, (List)ImmutableList.of((Object)c1.getNode(), (Object)c2.getNode())));
                        if (c1.getRangeType() == ParquetFilterCondition.RangeType.LOWER_RANGE && c2.getRangeType() == ParquetFilterCondition.RangeType.UPPER_RANGE && c1o2.vectorClass == c2o.vectorClass) {
                            final ParquetFilter pf2 = Filters.generateBetween(c1o2.value, c2o.value, c1.isOpen(), c2.isOpen(), c1o2.vectorClass);
                            condition = new ParquetFilterCondition(SchemaPath.getSimplePath(c1.getField()), (ParquetFilterIface)pf2, compound, sortIndex);
                        }
                        else if (c2.getRangeType() == ParquetFilterCondition.RangeType.LOWER_RANGE && c1.getRangeType() == ParquetFilterCondition.RangeType.UPPER_RANGE && c1o2.vectorClass == c2o.vectorClass) {
                            final ParquetFilter pf2 = Filters.generateBetween(c2o.value, c1o2.value, c2.isOpen(), c1.isOpen(), c1o2.vectorClass);
                            condition = new ParquetFilterCondition(SchemaPath.getSimplePath(c1.getField()), (ParquetFilterIface)pf2, compound, sortIndex);
                        }
                        else {
                            final ParquetFilter pf2 = Filters.generateFilter(c1o2.value, c1.getOpName(), c1o2.vectorClass);
                            condition = new ParquetFilterCondition(SchemaPath.getSimplePath(c1.getField()), (ParquetFilterIface)pf2, RexToExpr.toExpr(parseContext, incomingRowType, builder, (RexNode)c1.getNode()), sortIndex);
                            unusedConditions.add(c2.getNode());
                            for (int j = 2; j < props.size(); ++j) {
                                unusedConditions.add(props.get(j).getNode());
                            }
                        }
                    }
                }
                catch (Exception ex) {
                    ParquetFilterPushDownRule.logger.warn("Failure converting condition. {}", (Object)props, (Object)ex);
                    for (final ParquetFilterCondition.FilterProperties p4 : props) {
                        unusedConditions.add(p4.getNode());
                    }
                }
            }
        }
        if (condition == null) {
            return;
        }
        RelNode newScan;
        try {
            newScan = (RelNode)((FilterableScan)scan).applyFilter((ScanFilter)new ParquetScanFilter((List)Collections.singletonList(condition)));
        }
        catch (Exception e) {
            ParquetFilterPushDownRule.logger.warn("Failed to create new scan with filter", (Throwable)e);
            return;
        }
        unusedConditions.addAll(unSupportedDecimalFilters);
        if (unusedConditions.isEmpty()) {
            if (holder.hasRemainingExpression()) {
                call.transformTo((RelNode)filter.copy(filter.getTraitSet(), newScan, holder.getNode()));
            }
            else {
                call.transformTo(newScan);
            }
        }
        else {
            final ImmutableList.Builder<RexNode> newList = (ImmutableList.Builder<RexNode>)ImmutableList.builder();
            if (holder.hasRemainingExpression()) {
                newList.add((Object)holder.getNode());
            }
            newList.addAll((Iterable)unusedConditions);
            final List<RexNode> builtList = (List<RexNode>)newList.build();
            RexNode newCondition;
            if (builtList.size() == 1) {
                newCondition = builtList.get(0);
            }
            else {
                newCondition = builder.makeCall((SqlOperator)SqlStdOperatorTable.AND, (List)builtList);
            }
            call.transformTo((RelNode)filter.copy(filter.getTraitSet(), newScan, newCondition));
        }
    }
    
    private boolean filterDecimalScaleIncompatible(final RexCall condition, final List<RexCall> unSupportedDecimalFilters) {
        final List<RexNode> nodes = (List<RexNode>)condition.getOperands();
        if (!nodes.get(0).getType().getSqlTypeName().equals((Object)SqlTypeName.DECIMAL)) {
            return true;
        }
        int scaleOfInput;
        int scaleOfLiteral;
        if (nodes.get(0) instanceof RexInputRef) {
            scaleOfInput = nodes.get(0).getType().getScale();
            scaleOfLiteral = nodes.get(1).getType().getScale();
        }
        else {
            scaleOfLiteral = nodes.get(0).getType().getScale();
            scaleOfInput = nodes.get(1).getType().getScale();
        }
        final boolean vectorScaleGreaterThanEqualToLiteral = scaleOfInput >= scaleOfLiteral;
        if (!vectorScaleGreaterThanEqualToLiteral) {
            unSupportedDecimalFilters.add(condition);
        }
        return vectorScaleGreaterThanEqualToLiteral;
    }
    
    private Map<String, Field> getFieldMap(final BatchSchema schema) {
        final ImmutableMap.Builder<String, Field> map = (ImmutableMap.Builder<String, Field>)ImmutableMap.builder();
        for (final Field f : schema.getFields()) {
            if (this.allowPushdown(f)) {
                map.put((Object)f.getName(), (Object)f);
            }
        }
        return (Map<String, Field>)map.build();
    }
    
    private boolean allowPushdown(final Field f) {
        final CompleteType ct = CompleteType.fromField(f);
        switch (ct.toMinorType()) {
            case BIGINT:
            case DATE:
            case VARCHAR:
            case FLOAT4:
            case FLOAT8:
            case INT:
            case TIME:
            case TIMESTAMP:
            case DECIMAL: {
                return true;
            }
            default: {
                return false;
            }
        }
    }
    
    @VisibleForTesting
    protected VecH vec(final Map<String, Field> fieldMap, final ParquetFilterCondition.FilterProperties props) {
        final Field f = fieldMap.get(props.getField());
        final RexLiteral literal = props.getLiteral();
        final CompleteType ct = CompleteType.fromField(f);
        switch (ct.toMinorType()) {
            case BIGINT: {
                return new VecH(((BigDecimal)literal.getValue()).setScale(0, 4).longValue(), BigIntVector.class);
            }
            case DATE: {
                return new VecH(getMillisDateColumn(literal), DateMilliVector.class);
            }
            case VARCHAR: {
                return new VecH(new ComparableBinary(((NlsString)literal.getValue()).getValue().getBytes(StandardCharsets.UTF_8)), VarCharVector.class);
            }
            case FLOAT4: {
                return new VecH(((BigDecimal)literal.getValue()).floatValue(), Float4Vector.class);
            }
            case FLOAT8: {
                return new VecH(((BigDecimal)literal.getValue()).doubleValue(), Float8Vector.class);
            }
            case INT: {
                return new VecH(((BigDecimal)literal.getValue()).setScale(0, 4).intValue(), IntVector.class);
            }
            case TIME: {
                return new VecH(getMillisTimeColumn(literal), TimeMilliVector.class);
            }
            case TIMESTAMP: {
                return new VecH(getMillisTimeStampColumn(literal), TimeStampMilliVector.class);
            }
            case DECIMAL: {
                return new VecH(this.getDecimalValue(literal), DecimalVector.class);
            }
            default: {
                throw new UnsupportedOperationException();
            }
        }
    }
    
    private ComparableDecimal getDecimalValue(final RexLiteral literal) {
        final BigDecimal decimal = (BigDecimal)literal.getValue();
        final byte[] decimalInBytes = decimal.unscaledValue().toByteArray();
        return new ComparableDecimal(decimalInBytes, decimal.scale());
    }
    
    private static long getMillisDateColumn(final RexLiteral literal) {
        switch (literal.getTypeName()) {
            case DATE:
            case TIMESTAMP: {
                return ((GregorianCalendar)literal.getValue()).getTimeInMillis();
            }
            case CHAR:
            case VARCHAR: {
                return ValueExpressions.getDate(((NlsString)literal.getValue()).getValue());
            }
            default: {
                throw new UnsupportedOperationException("Comparision between literal of type " + literal.getTypeName() + " and date column not supported");
            }
        }
    }
    
    private static long getMillisTimeStampColumn(final RexLiteral literal) {
        switch (literal.getTypeName()) {
            case DATE:
            case TIMESTAMP: {
                return ((GregorianCalendar)literal.getValue()).getTimeInMillis();
            }
            case CHAR:
            case VARCHAR: {
                return ValueExpressions.getTimeStamp(((NlsString)literal.getValue()).getValue());
            }
            default: {
                throw new UnsupportedOperationException("Comparision between literal of type " + literal.getTypeName() + " and time column not supported");
            }
        }
    }
    
    private static int getMillisTimeColumn(final RexLiteral literal) {
        switch (literal.getTypeName()) {
            case TIME: {
                return (int)((GregorianCalendar)literal.getValue()).getTimeInMillis();
            }
            case CHAR:
            case VARCHAR: {
                return ValueExpressions.getTime(((NlsString)literal.getValue()).getValue());
            }
            default: {
                throw new UnsupportedOperationException("Comparision between literal of type " + literal.getTypeName() + " and timestamp column not supported");
            }
        }
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)ParquetFilterPushDownRule.class);
        SLUGIFY = new Slugify();
    }
    
    @VisibleForTesting
    static class VecH
    {
        private Object value;
        private Class<?> vectorClass;
        
        public VecH(final Object value, final Class<?> vectorClass) {
            this.value = value;
            this.vectorClass = vectorClass;
        }
        
        @VisibleForTesting
        Object getValue() {
            return this.value;
        }
    }
}
