package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;

public class DefaultVarCharFilterConverter implements ParquetVarCharFilterConverter
{
    @Override
    public ParquetFilter convertIfNecessary(final ParquetFilter originalFilter, final String filteredColumn) {
        return originalFilter;
    }
}
