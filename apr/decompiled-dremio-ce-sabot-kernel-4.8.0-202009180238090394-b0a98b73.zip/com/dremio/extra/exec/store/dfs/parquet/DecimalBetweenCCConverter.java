package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.*;
import com.dremio.parquet.reader.filter.*;
import java.math.*;

class DecimalBetweenCCConverter extends DecimalBetweenConverter
{
    @Override
    ComparableDecimal getRangeStart(final ParquetFilter parquetFilter) {
        final DecimalBetweenCCFilter filter = (DecimalBetweenCCFilter)parquetFilter;
        return filter.rangeStart;
    }
    
    @Override
    ComparableDecimal getRangeEnd(final ParquetFilter parquetFilter) {
        final DecimalBetweenCCFilter filter = (DecimalBetweenCCFilter)parquetFilter;
        return filter.rangeEnd;
    }
    
    @Override
    BigDecimal getNewStart(final ParquetFilter parquetFilter, final int scale) {
        final DecimalBetweenCCFilter filter = (DecimalBetweenCCFilter)parquetFilter;
        return this.minusHalf(filter.rangeStart, scale);
    }
    
    @Override
    BigDecimal getNewEnd(final ParquetFilter parquetFilter, final int scale) {
        final DecimalBetweenCCFilter filter = (DecimalBetweenCCFilter)parquetFilter;
        return this.plusHalf(filter.rangeEnd, scale);
    }
}
