package com.dremio.extra.exec.store.dfs.parquet;

import com.dremio.parquet.reader.column.generics.*;
import com.dremio.parquet.reader.filter.*;
import com.dremio.parquet.reader.*;
import java.math.*;

class DecimalLteConverter extends HiveDecimalFilterConverter
{
    @Override
    ParquetFilter transformFilterFromLowerScaleToHigherScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final DecimalLteFilter filter = (DecimalLteFilter)parquetFilter;
        final ComparableDecimal truncatedValue = this.truncateLower(filter.getValue(), fileScale);
        return (ParquetFilter)new DecimalLteFilter(truncatedValue);
    }
    
    @Override
    ParquetFilter transformFilterFromHigherScaleToLowerScale(final ParquetFilter parquetFilter, final int tablePrecision, final int tableScale, final int filePrecision, final int fileScale) {
        final DecimalLteFilter filter = (DecimalLteFilter)parquetFilter;
        final int newScale = tableScale + 1;
        final ComparableDecimal value = filter.getValue();
        final BigDecimal plusHalf = this.plusHalf(value, newScale);
        if (this.decimalCanScaleTo(plusHalf, fileScale)) {
            return this.getLteFilter(plusHalf);
        }
        if (this.greaterThanOrEqualToZero(value)) {
            return this.getAllFilter(value);
        }
        return this.getNoneFilter(value);
    }
}
