/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.drill.exec.store.rest;

import com.dremio.common.JSONOptions;
import com.dremio.common.expression.SchemaPath;
import com.dremio.connector.ConnectorException;
import com.dremio.connector.metadata.DatasetHandle;
import com.dremio.connector.metadata.DatasetMetadata;
import com.dremio.connector.metadata.EntityPath;
import com.dremio.connector.metadata.GetDatasetOption;
import com.dremio.connector.metadata.GetMetadataOption;
import com.dremio.connector.metadata.ListPartitionChunkOption;
import com.dremio.connector.metadata.PartitionChunkListing;
import com.dremio.exec.physical.base.AbstractGroupScan;
import com.dremio.exec.planner.logical.ViewTable;
import com.dremio.exec.server.SabotContext;
import com.dremio.exec.store.SchemaConfig;
import com.dremio.exec.store.StoragePlugin;
import com.dremio.exec.store.StoragePluginRulesFactory;
import com.dremio.exec.store.dfs.FileSystemPlugin;
import com.dremio.service.namespace.NamespaceKey;
import com.dremio.service.namespace.SourceState;
import com.dremio.service.namespace.capabilities.SourceCapabilities;
import com.dremio.service.namespace.dataset.proto.DatasetConfig;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableSet;
import org.apache.calcite.plan.RelOptRule;
import org.apache.calcite.schema.SchemaPlus;

import org.apache.drill.exec.store.rest.query.RestPushFilterIntoScan;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * @author Oleg Zinoviev
 * @since 15.06.2017.
 */
@SuppressWarnings("FieldCanBeLocal")
public class RestStoragePlugin implements StoragePlugin {

    private final RestSchemaFactory schemaFactory;
    private final RestStoragePluginConfig config;

    public RestStoragePlugin(RestStoragePluginConfig config, SabotContext context, String name) {
        //super(context, name);
        this.schemaFactory = new RestSchemaFactory(name, this);
        this.config = config;
    }

    @Override
    public RestStoragePluginConfig getConfig() {
        return config;
    }

    public String getRequestParameters() {
        return String.format("$__%s_param", getName());
    }

    @Override
    public void registerSchemas(SchemaConfig schemaConfig, SchemaPlus schemaPlus) {
        schemaFactory.registerSchemas(schemaConfig, schemaPlus);
    }

    @Override
    public AbstractGroupScan getPhysicalScan(String userName, JSONOptions selection, List<SchemaPath> columns) throws IOException {
        RestScanSpec scanSpec = selection.getListWith(new ObjectMapper(), new TypeReference<RestScanSpec>() {
        });
        return new RestGroupScan(userName, this, scanSpec, columns, scanSpec.getParameters() != null);
    }

    @SuppressWarnings("deprecation")
    @Override
    public Set<? extends RelOptRule> getPhysicalOptimizerRules(OptimizerRulesContext optimizerRulesContext) {
        return ImmutableSet.of(RestPushFilterIntoScan.FILTER_ON_SCAN, RestPushFilterIntoScan.FILTER_ON_PROJECT);
    }

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Optional<DatasetHandle> getDatasetHandle(EntityPath datasetPath, GetDatasetOption... options)
			throws ConnectorException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PartitionChunkListing listPartitionChunks(DatasetHandle datasetHandle, ListPartitionChunkOption... options)
			throws ConnectorException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DatasetMetadata getDatasetMetadata(DatasetHandle datasetHandle, PartitionChunkListing chunkListing,
			GetMetadataOption... options) throws ConnectorException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean containerExists(EntityPath containerPath) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean hasAccessPermission(String user, NamespaceKey key, DatasetConfig datasetConfig) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public SourceState getState() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SourceCapabilities getSourceCapabilities() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ViewTable getView(List<String> tableSchemaPath, SchemaConfig schemaConfig) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<? extends StoragePluginRulesFactory> getRulesFactoryClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void start() throws IOException {
		// TODO Auto-generated method stub
		
	}

}