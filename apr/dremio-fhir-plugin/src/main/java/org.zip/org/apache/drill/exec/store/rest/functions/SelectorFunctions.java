/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.drill.exec.store.rest.functions;

import org.apache.arrow.memory.ArrowBuf;
import org.apache.arrow.vector.complex.writer.BaseWriter;
import org.apache.arrow.vector.holders.*;

import com.dremio.exec.expr.SimpleFunction;
import com.dremio.exec.expr.annotations.FunctionTemplate;
import com.dremio.exec.expr.annotations.*;


import javax.inject.Inject;

/**
 * @author Oleg Zinoviev
 * @since 21.06.2017.
 */
@SuppressWarnings({"unused", "Duplicates"})
public class SelectorFunctions {
    private SelectorFunctions() {
    }

    @FunctionTemplate(name = "selector",
            scope = FunctionTemplate.FunctionScope.SIMPLE,
            nulls = FunctionTemplate.NullHandling.INTERNAL
           )
    public static class NullableSelectorFunc implements SimpleFunction {
        @Param
        VarCharHolder type;

        @Param
        NullableVarCharHolder source;

        @Param
        VarCharHolder selector;

        @Output
        BaseWriter.ComplexWriter output;

        @Inject
        ArrowBuf buffer;

        @Override
        public void setup() {
        }

        @Override
        public void eval() {
            BaseWriter.ListWriter listWriter = output.rootAsList();
            listWriter.startList();
            listWriter.varChar();
            for (byte[] bytes : org.apache.drill.exec.store.rest.functions.SelectorFunctionsBody.select(type, source, selector)) {
                buffer = buffer.reallocIfNeeded(bytes.length);
                buffer.setBytes(0, bytes);
                listWriter.varChar().writeVarChar(0, bytes.length, buffer);
            }
            listWriter.endList();
        }
    }

    @FunctionTemplate(name = "selector",
            scope = FunctionTemplate.FunctionScope.SIMPLE,
            nulls = FunctionTemplate.NullHandling.INTERNAL
            )
    public static class SelectorFunc implements SimpleFunction {
        @Param
        VarCharHolder type;

        @Param
        VarCharHolder source;

        @Param
        VarCharHolder selector;

        @Output
        BaseWriter.ComplexWriter output;

        @Inject
        ArrowBuf buffer;

        @Override
        public void setup() {
        }

        @Override
        public void eval() {
            BaseWriter.ListWriter listWriter = output.rootAsList();
            listWriter.startList();
            listWriter.varChar();
            for (byte[] bytes : org.apache.drill.exec.store.rest.functions.SelectorFunctionsBody.select(type, source, selector)) {
                buffer = buffer.reallocIfNeeded(bytes.length);
                buffer.setBytes(0, bytes);
                listWriter.varChar().writeVarChar(0, bytes.length, buffer);
            }
            listWriter.endList();
        }
    }
}
