/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.drill.exec.store.rest;

import com.dremio.common.logical.StoragePluginConfigBase;
import com.dremio.exec.catalog.StoragePluginId;
import com.dremio.exec.catalog.conf.ConnectionConf;
import com.dremio.exec.server.SabotContext;
import com.fasterxml.jackson.annotation.*;

import org.apache.drill.exec.store.rest.config.QueryConfig;
import org.apache.drill.exec.store.rest.config.RuntimeConfigBuilder;
import org.apache.drill.exec.store.rest.config.RuntimeQueryConfig;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

import javax.inject.Provider;

/**
 * @author Oleg Zinoviev
 * @since 15.06.2017.
 */
@JsonTypeName(RestStoragePluginConfig.NAME)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RestStoragePluginConfig extends ConnectionConf<RestStoragePluginConfig, RestStoragePlugin> {

    static final String NAME = "rest";
    private final String url;
    private final Map<String, String> headers;
    private final Map<String, Object> config;
    private final Map<String, QueryConfig> queries;

    @JsonCreator
    public RestStoragePluginConfig(@JsonProperty(value = "url") String url,
                                   @JsonProperty(value = "headers") Map<String, String> headers,
                                   @JsonProperty(value = "queries") Map<String, QueryConfig> queries,
                                   @JsonProperty(value = "config") Map<String, Object> config) {
        this.url = url;
        this.headers = headers == null ? Collections.emptyMap() : headers;
        this.config = config == null ? Collections.emptyMap() : config;
        this.queries = queries == null ? Collections.emptyMap() : queries;
    }

    @JsonProperty
    public String getUrl() {
        return url;
    }

    @JsonProperty
    public Map<String, String> getHeaders() {
        return headers;
    }

    @JsonProperty
    public Map<String, QueryConfig> getQueries() {
        return queries;
    }

    @JsonIgnore
    RuntimeQueryConfig getRuntimeConfig(String query) {
        return new RuntimeConfigBuilder()
                .withQuery(query)
                .withRootConfig(this)
                .build();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RestStoragePluginConfig that = (RestStoragePluginConfig) o;
        return Objects.equals(url, that.url)
                && Objects.equals(config, that.config)
                && Objects.equals(headers, that.headers)
                && Objects.equals(queries, that.queries);
    }

    

	@Override
	public RestStoragePlugin newPlugin(SabotContext context, String name, Provider<StoragePluginId> pluginIdProvider) {
		// TODO Auto-generated method stub
		return new RestStoragePlugin(this, context, name);
	}
}
